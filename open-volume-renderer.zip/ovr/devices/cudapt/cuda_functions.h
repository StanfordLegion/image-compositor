#pragma once

#include "ovr/common/cuda_buffer.h"
#include "ovr/common/math.h"

#include "ovr/devices/optix7/volume.h"

namespace ovr {
namespace cudapt {

using optix7::Array1DFloat4Optix7;
using optix7::Array1DScalarOptix7;
using optix7::Array3DScalarOptix7;
using optix7::ArrayOptix7;

using DeviceVolume = optix7::DeviceStructuredRegularVolume;

struct LightSource;
struct AmbientLight;
struct DirectionalLight;
struct LightSourceCollection;
struct LaunchParams;

class PathTracingRenderer;

struct Ray {
  vec3f org{};
  vec3f dir{};
  float tnear{};
  float tfar{};
};

struct PathTracingPayload {
  float alpha = 0.f;
  vec3f color = 0.f;
  void* rng = nullptr;
  int32_t scatter_index = 0;
};

struct LightSource
{
  enum LightType {
    AMBIENT_LIGHT,
    DIRECTIONAL_LIGHT,
    POINT_LIGHT,
    RECTANGLE_LIGHT,
    INFINITE_AREA_LIGHT
  } type;

  LightSource(LightType t) : type(t) {}

  __device__ vec3f GetIntensity(
    const DeviceVolume& self,
    const LaunchParams& params,
    const affine3f& wto,
    char* cast_rng,
    Ray ray /* world space ray */) const;

  __device__ float GetLightPDF() const;
};

struct AmbientLight : public LightSource
{
  vec3f intensity{ 0.f };

  AmbientLight() : LightSource(AMBIENT_LIGHT) {}

  inline __device__ vec3f GetIntensity(
    const DeviceVolume& self,
    const LaunchParams& params,
    const affine3f& wto,
    char* cast_rng,
    Ray ray /* world space ray */
  ) const;

  inline __device__ float GetLightPDF() const;
};

struct DirectionalLight : public LightSource
{
  vec3f light_pos{ 0.f, -10.f, 0.f };
  vec3f intensity{ 10.f, 10.f, 10.f };
  
  DirectionalLight() : LightSource(DIRECTIONAL_LIGHT) {}
  
  inline __device__ vec3f GetIntensity(
    const DeviceVolume& self,
    const LaunchParams& params,
    const affine3f& wto,
    char* cast_rng,
    Ray ray /* world space ray */
  ) const;

  inline __device__ float GetLightPDF() const;
};

struct PointLight : public LightSource
{
  vec3f light_pos{ 500.f, 500.f, -500.f };
  vec3f intensity{ 400000.f, 400000.f, 400000.f };
  
  PointLight() : LightSource(POINT_LIGHT) {}

  inline __device__ vec3f GetIntensity(
    const DeviceVolume& self,
    const LaunchParams& params,
    const affine3f& wto,
    char* cast_rng,
    Ray ray /* world space ray */
  ) const;

  inline __device__ float GetLightPDF() const;
};

struct RectangleLight : public LightSource
{ 
  double length = 5.f;
  double width = 5.f;
  vec3f light_pos{ -100.f, 0.f, -100.f };
  vec3f intensity{ 1.f, 1.f, 1.f };
  vec3f lookat{100.f, 0.f, -100.f };

  RectangleLight() : LightSource(RECTANGLE_LIGHT) {}
  
  inline __device__ vec3f GetIntensity(
    const DeviceVolume& self,
    const LaunchParams& params,
    const affine3f& wto,
    char* cast_rng,
    Ray ray /* world space ray */
  ) const;

  inline __device__ float GetLightPDF() const;
};

struct InfiniteAreaLight : public LightSource
{
  double radius = 20000.f;
  vec3f light_pos{ 0.f, 0.f, 0.f };
  vec3f intensity{ 1.f, 1.f, 1.f };

  InfiniteAreaLight() : LightSource(INFINITE_AREA_LIGHT) {}
  
  inline __device__ vec3f GetIntensity(
    const DeviceVolume& self,
    const LaunchParams& params,
    const affine3f& wto,
    char* cast_rng,
    Ray ray /* world space ray */
  ) const;

  inline __device__ float GetLightPDF() const;
};

struct LightSourceCollection {
  
  std::vector<AmbientLight> ambient_light_sources;
  CUDABuffer ambientLightSourceBuffer;

  std::vector<DirectionalLight> directional_light_sources;
  CUDABuffer directionalLightSourceBuffer;

  std::vector<PointLight> point_light_sources;
  CUDABuffer pointLightSourceBuffer;

  std::vector<RectangleLight> rectangle_light_sources;
  CUDABuffer rectangleLightSourceBuffer;

  std::vector<InfiniteAreaLight> infi_area_light_sources;
  CUDABuffer infiniteAreaLightSourceBuffer;

  std::vector<void*> light_devicepPtr_hostArr;
  CUDABuffer light_devicepPtr_device_buffer;

  void upload_light() {

    ambientLightSourceBuffer.alloc_and_upload(ambient_light_sources);
    directionalLightSourceBuffer.alloc_and_upload(directional_light_sources);
    pointLightSourceBuffer.alloc_and_upload(point_light_sources);
    rectangleLightSourceBuffer.alloc_and_upload(rectangle_light_sources);
    infiniteAreaLightSourceBuffer.alloc_and_upload(infi_area_light_sources);

    light_devicepPtr_hostArr.resize(ambient_light_sources.size() +
                                    directional_light_sources.size() +
                                    point_light_sources.size() +
                                    rectangle_light_sources.size() +
                                    infi_area_light_sources.size());

    auto current_location = 0;

    for (int i = 0; i < ambient_light_sources.size(); i++){
      light_devicepPtr_hostArr[i] = (char*)ambientLightSourceBuffer.d_pointer() + i * sizeof(AmbientLight);
    }
    current_location = ambient_light_sources.size();

    for (int i = 0; i < directional_light_sources.size(); i++){
      light_devicepPtr_hostArr[current_location + i] = (char*)directionalLightSourceBuffer.d_pointer() + i * sizeof(DirectionalLight);
    }
    current_location += directional_light_sources.size();

    for (int i = 0; i < point_light_sources.size(); i++){
      light_devicepPtr_hostArr[current_location + i] = (char*)pointLightSourceBuffer.d_pointer() + i * sizeof(PointLight);
    }
    current_location += point_light_sources.size();

    for (int i = 0; i < rectangle_light_sources.size(); i++){
      light_devicepPtr_hostArr[current_location + i] = (char*)rectangleLightSourceBuffer.d_pointer() + i * sizeof(RectangleLight);
    }
    current_location += rectangle_light_sources.size();

    for (int i = 0; i < infi_area_light_sources.size(); i++){
      light_devicepPtr_hostArr[current_location + i] = (char*)infiniteAreaLightSourceBuffer.d_pointer() + i * sizeof(InfiniteAreaLight);
    }
    current_location += infi_area_light_sources.size();

    light_devicepPtr_device_buffer.alloc_and_upload(light_devicepPtr_hostArr);
  
  }
};

struct LaunchParams { // shared global data
  struct DeviceFrameBuffer {
    vec4f* rgba;
    vec2i size;
  } frame;
  vec4f* frame_accum_rgba;
  int32_t frame_index{ 0 };

  struct DeviceCamera {
    vec3f position;
    vec3f direction;
    vec3f horizontal;
    vec3f vertical;
  } camera;

  affine3f transform;

  int32_t sample_per_pixel{ 1 };
  int32_t max_num_scatters{ 20 };

  vec3f* albedo_accumulation{ nullptr };

  // LightSource simple_light_source;

  int light_on = 1; // 1 = directional light; 2 = rectangle light; 3 = point light, 4 = ambient light;
  
  int light_size = 0;
  LightSource** light_source_ptr{ nullptr };
};

void
do_path_tracing(cudaStream_t stream, void* launch_params_ptr, void* volume_ptr, int2 fbsize);

class PathTracingRenderer {
public:
  void render(cudaStream_t stream, LaunchParams& params, void* volume, bool reset_accumulation);

private:
  CUDABuffer params_buffer;
  CUDABuffer albedo_accumulation_buffer;

  CUDABuffer light_source_buffer;
};

inline void
PathTracingRenderer::render(cudaStream_t stream, LaunchParams& params, void* volume, bool reset_accumulation)
{
  albedo_accumulation_buffer.resize(params.frame.size.long_product() * sizeof(vec3f) /*, stream*/);
  if (reset_accumulation) {
    albedo_accumulation_buffer.nullify(stream);
  }
  params.albedo_accumulation = (vec3f*)albedo_accumulation_buffer.d_pointer();

  params_buffer.resize(sizeof(params));
  params_buffer.upload_async(&params, 1, stream);
  
  do_path_tracing(stream, (void*)params_buffer.d_pointer(), volume, (const int2&)params.frame.size);

  
}

} // namespace cudapt
} // namespace ovr
