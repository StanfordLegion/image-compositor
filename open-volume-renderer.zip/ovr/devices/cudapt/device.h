#pragma once
#ifndef OVR_CUDAPT_DEVICE_H
#define OVR_CUDAPT_DEVICE_H

#include "ovr/renderer.h"
#include <memory>

namespace ovr::cudapt {

class DeviceCudapt : public MainRenderer {
public:
  ~DeviceCudapt() override;
  DeviceCudapt();
  DeviceCudapt(const DeviceCudapt& other) = delete;
  DeviceCudapt(DeviceCudapt&& other) = delete;
  DeviceCudapt& operator=(const DeviceCudapt& other) = delete;
  DeviceCudapt& operator=(DeviceCudapt&& other) = delete;

  /*! constructor - performs all setup, including initializing ospray, creates scene graph, etc. */
  void init(int argc, const char** argv) override;

  /* load light from usda file */
  void load_and_update_light_from_usda(std::string usd_file);

  /*! render one frame */
  void swap() override;
  void commit() override;
  void render() override;
  void mapframe(FrameBufferData* fb) override;

private:
  struct Impl;
  std::unique_ptr<Impl> pimpl; // pointer to the internal implementation
};

} // namespace ovr::cudapt

#endif // OVR_CUDAPT_DEVICE_H
