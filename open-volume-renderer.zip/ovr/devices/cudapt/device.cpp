#include "device.h"
#include "cuda_functions.h"

#include <string>
#include <thread>

namespace ovr::cudapt {

using HostVolume = optix7::StructuredRegularVolume;

using FrameBuffer = optix7::DoubleBufferObject<vec4f>;

using optix7::CreateArray1DFloat4Optix7;
using optix7::CreateArray1DScalarOptix7;

// ------------------------------------------------------------------
// ------------------------------------------------------------------

struct DeviceCudapt::Impl {
  DeviceCudapt* parent{ nullptr };

  int buffer_index = 0;

  FrameBuffer framebuffer;
  cudaStream_t framebuffer_stream{};
  bool framebuffer_size_updated{ false };
  bool framebuffer_reset{ false };

  HostVolume volume;
  bool volumes_changed{ true };

  LaunchParams params;

  PathTracingRenderer renderer;

  LightSourceCollection hostLightSources;

public:
  ~Impl() {}

  Impl() {}

  void init(int argc, const char** argv, DeviceCudapt* p)
  {
    if (parent)
      throw std::runtime_error("[cudapt] device already initialized!");
    parent = p;

    framebuffer.create();

    const auto& scene = parent->current_scene;
    assert(scene.instances.size() == 1 && "[cudapt] only accept one instance");
    assert(scene.instances[0].models.size() == 1 && "[cudapt] only accept one model");
    assert(scene.instances[0].models[0].type == scene::Model::VOLUMETRIC_MODEL && "[cudapt] only accept volume");
    assert(scene.instances[0].models[0].volume_model.volume.type == scene::Volume::STRUCTURED_REGULAR_VOLUME &&
           "[cudapt] only accept structured regular volume");

    auto& st = scene.instances[0].models[0].volume_model.transfer_function;
    auto& sv = scene.instances[0].models[0].volume_model.volume.structured_regular;

    vec3f scale = sv.grid_spacing * vec3f(sv.data->dims);
    vec3f translate = sv.grid_origin;

    volume.matrix = affine3f::translate(translate) * affine3f::scale(scale);
    volume.load_from_array3d_scalar(sv.data);
    volume.set_sampling_rate(scene.volume_sampling_rate);
    volume.set_transfer_function(CreateArray1DFloat4Optix7(st.color), CreateArray1DScalarOptix7(st.opacity));
    volume.set_value_range(st.value_range.x, st.value_range.y);
    volume.get_sbt_pointer(/*stream=*/0);

    load_and_update_light_from_usda(scene);
  }

  void load_and_update_light_from_usda(const Scene &scene){

    for (auto& current_light : scene.lights) {

      if (current_light.type == scene::Light::AMBIENT) {
      
        AmbientLight create_ambient_light;
        create_ambient_light.intensity = current_light.intensity * current_light.color;
        hostLightSources.ambient_light_sources.push_back(create_ambient_light);


      } else if (current_light.type == scene::Light::DIRECTIONAL) {

        DirectionalLight create_directional_light;
        create_directional_light.intensity = current_light.intensity * current_light.color;
        create_directional_light.light_pos = -current_light.directional.direction;
        hostLightSources.directional_light_sources.push_back(create_directional_light);

      }
      else throw std::runtime_error("CUDA: unknown light type");
    }
    
    // AmbientLight first_ambient_light;
    // DirectionalLight first_directional_light;
    // PointLight first_point_light;
    // RectangleLight first_rectangle_light;
    // InfiniteAreaLight first_infi_area_light;

    // hostLightSources.ambient_light_sources.push_back(first_ambient_light);
    // hostLightSources.directional_light_sources.push_back(first_directional_light);
    // hostLightSources.point_light_sources.push_back(first_point_light);
    // hostLightSources.rectangle_light_sources.push_back(first_rectangle_light);
    // hostLightSources.infi_area_light_sources.push_back(first_infi_area_light);

    hostLightSources.upload_light();
    params.light_size = hostLightSources.light_devicepPtr_hostArr.size();
    params.light_source_ptr = (LightSource**)hostLightSources.light_devicepPtr_device_buffer.d_pointer();
  }

  void swap()
  {
    buffer_index = (buffer_index + 1) % 2;
  }

  void commit()
  {
    if (parent->params.fbsize.update()) {
      CUDA_SYNC_CHECK(); /* stio all async rendering */
      params.frame.size = parent->params.fbsize.ref();
      framebuffer.resize(parent->params.fbsize.ref());
      framebuffer_size_updated = true;
      framebuffer_reset = true;
    }

    /* commit other data */
    if (parent->params.camera.update() || framebuffer_size_updated) {
      Camera camera = parent->params.camera.ref();

      /* the factor '2.f' here might be unnecessary, but I want to match ospray's implementation */
      const float fovy = camera.perspective.fovy;
      const float t = 2.f /* (note above) */ * tan(fovy * 0.5f * M_PI / 180.f);
      const float aspect = params.frame.size.x / float(params.frame.size.y);

      params.camera.position = camera.from;
      params.camera.direction = normalize(camera.at - camera.from);
      params.camera.horizontal = t * aspect * normalize(cross(params.camera.direction, camera.up));
      params.camera.vertical = cross(params.camera.horizontal, params.camera.direction) / aspect;

      framebuffer_reset = true;
    }

    if (parent->params.tfn.update()) {
      const auto& tfn = parent->params.tfn.ref();
      volume.set_transfer_function(tfn.tfn_colors, tfn.tfn_alphas, tfn.tfn_value_range);
      volumes_changed = true;
      framebuffer_reset = true;
    }

    if (parent->params.sample_per_pixel.update()) {
      params.sample_per_pixel = parent->params.sample_per_pixel.ref();
      framebuffer_reset = true;
    }
  }

  void render()
  {
    framebuffer_size_updated = false;
    if (framebuffer_reset) {
      framebuffer.reset();
    }

    if (volumes_changed) {
      volume.commit(framebuffer_stream);
      volumes_changed = false;
    }

    params.frame.rgba = (vec4f*)framebuffer.device_pointer(/*layout=*/0);
    params.frame_index = framebuffer_reset ? 1 : params.frame_index + 1;
    params.transform = volume.matrix;
    if (params.frame.size.x <= 0 || params.frame.size.y <= 0)
      return;

    renderer.render(framebuffer_stream, params, volume.get_sbt_pointer(framebuffer_stream), framebuffer_reset);

    /* post rendering */
    parent->variance = 0.f; /* TODO compute real variance */
    framebuffer_reset = false;
  }

  void mapframe(FrameBufferData* fb)
  {
    const size_t num_bytes = framebuffer.size().long_product();
    fb->rgba->set_data(framebuffer.device_pointer(0), num_bytes * sizeof(vec4f), CrossDeviceBuffer::DEVICE_CUDA);
  }
};

DeviceCudapt::~DeviceCudapt()
{
  pimpl.reset();
}

DeviceCudapt::DeviceCudapt() : MainRenderer(), pimpl(new Impl()) {}

void
DeviceCudapt::init(int argc, const char** argv)
{
  pimpl->init(argc, argv, this);
  commit();
}

void
DeviceCudapt::swap()
{
  pimpl->swap();
}

void
DeviceCudapt::commit()
{
  pimpl->commit();
}

void
DeviceCudapt::render()
{
  pimpl->render();
}

void
DeviceCudapt::mapframe(FrameBufferData* fb)
{
  return pimpl->mapframe(fb);
}

} // namespace ovr::cudapt
