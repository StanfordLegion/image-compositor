//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#pragma once
#ifndef OVR_OPTIX7_PARAMS_H
#define OVR_OPTIX7_PARAMS_H

#include "optix7_common.h"
#include "volume.h"

#include "ovr/scene.h"

#if defined(__cplusplus)
#include <array>
#include <cstring>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#endif // defined(__cplusplus)

namespace ovr {
namespace optix7 {

#define OVR_OPTIX7_MASKING_VIA_STREAM_COMPACTION
// #define OVR_OPTIX7_MASKING_VIA_DIRECT_SAMPLING

#define OVR_OPTIX7_MASKING_NOISE_STBN
// #define OVR_OPTIX7_MASKING_NOISE_BLUE
// #define OVR_OPTIX7_MASKING_NOISE_UNIFORM

// #define OVR_OPTIX7_JITTER_RAYS

// ------------------------------------------------------------------
//
// Shared Definitions
//
// ------------------------------------------------------------------

// for this simple example, we have a single ray type
enum RayType { RAYMARCHING_RAY_TYPE = 0, PATHTRACING_RAY_TYPE, SHADOW_RAY_TYPE, RAY_TYPE_COUNT };

#define VISIBILITY_VOLUME   1 << 0
#define VISIBILITY_GEOMETRY 1 << 1

struct ShadowPayload {
  /* shadow intensity */
  float alpha = 0.f; 

  /* by ray marching */
  void* rng = nullptr;
  float t_max = 0.f;
};

struct RayMarchingPayload {
  /* radiance output */
  float alpha = 0.f;
  vec3f color = 0.f;
  vec3f gradient = 0.f;
  vec2f optical_flow = 0.f;

  /* by ray marching */
  void* rng = nullptr;
  float t_max = 0.f;

  inline __device__ void reset()
  {
    alpha = 0.f;
    color = 0.f;
    gradient = 0.f;
    optical_flow = 0.f;
  }
};

struct PathTracingPayload {
  /* radiance output */
  float alpha = 0.f;
  vec3f color = 0.f;
  // vec3f gradient = 0.f;
  // vec2f optical_flow = 0.f;

  /* by path tracing */
  void* rng = nullptr;
  int32_t scatter_index = 0;
  const affine3f* wto = nullptr; /* world to object transform */
};

struct LaunchParams { // shared global data
  struct DeviceFrameBuffer {
    vec4f* rgba;
    vec3f* grad;
    vec2i size;
  } frame;
  vec4f* frame_accum_rgba;
  vec3f* frame_accum_grad;
  int32_t frame_index{ 0 };

  struct DeviceCamera {
    vec3f position;
    vec3f direction;
    vec3f horizontal;
    vec3f vertical;
  } camera, last_camera;

  OptixTraversableHandle traversable{};

  bool enable_path_tracing{ false };
  bool enable_sparse_sampling{ false };
  bool enable_frame_accumulation{ false };

  vec3f light_directional_pos{ -907.108f, 2205.875f, -400.0267f };
  float light_ambient_intensity{ 1.f };

  float base_noise{ 0.1f };
  vec2f focus_center{ 0.5f, 0.5f };
  float focus_scale{ 0.2f };

  int32_t max_num_scatters{ 24 };
  int32_t sample_per_pixel{ 1 };

  struct {
#ifdef OVR_OPTIX7_MASKING_VIA_DIRECT_SAMPLING
    const int downsample_factor = 4;
    float* dist_uniform{ nullptr };
    float* dist_logistic{ nullptr };
#endif
#ifdef OVR_OPTIX7_MASKING_VIA_STREAM_COMPACTION
    int32_t* xs_and_ys{ nullptr };
#endif
  } sparse_sampling;
};

#define float_large std::numeric_limits<float>::max()
#define float_small std::numeric_limits<float>::min()

// ------------------------------------------------------------------
//
//
//
// ------------------------------------------------------------------

#if defined(__cplusplus)
using FrameBuffer = DoubleBufferObject<vec4f, vec3f>;
#endif // define(__cplusplus)

} // namespace optix7
} // namespace ovr
#endif // OVR_OPTIX7_PARAMS_H
