//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#pragma once
#ifndef OVR_OPTIX7_VOLUME_H
#define OVR_OPTIX7_VOLUME_H

#include "array.h"
#include "optix7_common.h"

#include <array>
#include <vector>

namespace ovr {
namespace optix7 {

// ------------------------------------------------------------------
// Volume Definition
// ------------------------------------------------------------------

struct DeviceStructuredRegularVolume {
  Array3DScalarOptix7 volume;
  Array1DFloat4Optix7 colors;
  Array1DScalarOptix7 alphas;
  // float alpha_adjustment;
  float base;
  float step;
};

// ------------------------------------------------------------------
//
// Host Functions
//
// ------------------------------------------------------------------
#if defined(__cplusplus)

struct InstantiableGeometry {
  affine3f matrix;

  /*! compute 3x4 transformation matrix */
  void transform(float transform[12]) const;
};

struct AabbGeometry {
private:
  // the AABBs for procedural geometries
  OptixAabb aabb{ 0.f, 0.f, 0.f, 1.f, 1.f, 1.f };
  CUDABuffer aabbBuffer;
  CUDABuffer asBuffer; // buffer that keeps the (final, compacted) accel structure

public:
  OptixTraversableHandle buildas(OptixDeviceContext optixContext, cudaStream_t stream = 0);
};

struct StructuredRegularVolume
  : protected HasSbtEquivalent<DeviceStructuredRegularVolume>
  , public AabbGeometry
  , public InstantiableGeometry {
public:
  std::vector<vec4f> tfn_colors_data;
  std::vector<float> tfn_alphas_data;
  vec2f original_value_range;

  float base = 1.f;
  float rate = 1.f;

  void commit(cudaStream_t stream);
  void* get_sbt_pointer(cudaStream_t stream);

  void load_from_array3d_scalar(array_3d_scalar_t array, float value_min = 1, float valuue_max = -1);

  void set_transfer_function(Array1DFloat4Optix7 c, Array1DScalarOptix7 a);
  void set_transfer_function(array_1d_float4_t c, array_1d_scalar_t a, vec2f r);
  void set_transfer_function(const std::vector<float>& c, const std::vector<float>& o, const vec2f& r);
  void set_value_range(float data_value_min, float data_value_max);
  void set_sampling_rate(float r, float b = 0.f);
};

#endif // #if defined(__cplusplus)

} // namespace optix7
} // namespace ovr
#endif // OVR_OPTIX7_VOLUME_H
