//. ======================================================================== //
//. Copyright 2018-2022 Qi Wu                                                //
//.                                                                          //
//. Licensed under MIT                                                       //
//. ======================================================================== //
#pragma once

#include "ovr/common/math.h"

// the output pointer should be pre-allocated

namespace ovr {

#ifdef OVR_ENABLE_CUDA_DEVICES
int64_t
generate_sparse_sampling_mask_d(int32_t* d_output, int frame_index,
                                const vec2i& fbsize,
                                const vec2f& focus_center,
                                float focus_scale,
                                float base_noise);
#endif

int64_t
generate_sparse_sampling_mask_h(int32_t* h_output, int frame_index,
                                const vec2i& fbsize,
                                const vec2f& focus_center,
                                float focus_scale,
                                float base_noise);

}
