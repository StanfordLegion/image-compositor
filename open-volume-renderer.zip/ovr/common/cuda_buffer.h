//. ======================================================================== //
//. Copyright 2018-2022 Qi Wu                                                //
//.                                                                          //
//. Licensed under MIT                                                       //
//. ======================================================================== //

#pragma once
#ifndef OVR_COMMON_CUDA_BUFFER_H
#define OVR_COMMON_CUDA_BUFFER_H

// ------------------------------------------------------------------
// Host Functions
// ------------------------------------------------------------------
#ifdef __cplusplus

#include <cuda.h>
#include <cuda_runtime.h>

#include <cassert>
#include <cstring>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

// #ifndef MAX
// #define MAX(a, b) ((a > b) ? a : b)
// #endif
// #ifndef MIN
// #define MIN(a, b) ((a < b) ? a : b)
// #endif

// ------------------------------------------------------------------
// CUDA Related Macro
// ------------------------------------------------------------------

#define CUDA_CHECK(call)                                                                       \
  do {                                                                                         \
    cudaError_t error = call;                                                                  \
    if (error != cudaSuccess) {                                                                \
      const char* msg = cudaGetErrorString(error);                                             \
      fprintf(stderr, "CUDA error (%s: line %d): %s\n", __FILE__, __LINE__, msg);              \
      throw std::runtime_error(std::string("CUDA error: " #call " failed with error ") + msg); \
    }                                                                                          \
  } while (0)

#define CUDA_CHECK_NOEXCEPT(call) \
  do {                            \
    call;                         \
  } while (0)

#define CUDA_SYNC_CHECK()                                                                             \
  do {                                                                                                \
    cudaDeviceSynchronize();                                                                          \
    cudaError_t error = cudaGetLastError();                                                           \
    if (error != cudaSuccess) {                                                                       \
      const char* msg = cudaGetErrorString(error);                                                    \
      fprintf(stderr, "CUDA sync error (%s: line %d): %s\n", __FILE__, __LINE__, msg);                \
      throw std::runtime_error(std::string("CUDA cudaDeviceSynchronize() failed with error ") + msg); \
    }                                                                                                 \
  } while (0)

#define CUDA_SYNC_CHECK_NOEXCEPT() \
  do {                             \
    cudaDeviceSynchronize();       \
  } while (0)

#define OPTIX_CHECK(call)                                                                      \
  do {                                                                                         \
    OptixResult res = call;                                                                    \
    if (res != OPTIX_SUCCESS) {                                                                \
      fprintf(stderr, "OptiX call (%s) failed with %d (line %d)\n", #call, res, __LINE__);     \
      throw std::runtime_error(std::string("OptiX call (") + #call + std::string(") failed")); \
    }                                                                                          \
  } while (0)

#define OPTIX_CHECK_NOEXCEPT(call) \
  do {                             \
    OptixResult res = call;        \
  } while (0)

// ------------------------------------------------------------------
// CUDA Buffer
// ------------------------------------------------------------------

/*! simple wrapper for creating, and managing a device-side CUDA buffer */
struct CUDABuffer {
  // cleanup
  ~CUDABuffer()
  {
    // free();
  }

	CUDABuffer() {}

	CUDABuffer& operator=(CUDABuffer&& other) {
		std::swap(owned, other.owned);
		std::swap(sizeInBytes, other.sizeInBytes);
    std::swap(d_ptr, other.d_ptr);
		return *this;
	}

	CUDABuffer(CUDABuffer&& other) {
		*this = std::move(other);
	}

	CUDABuffer(const CUDABuffer &other) : owned{false}, sizeInBytes{other.sizeInBytes}, d_ptr{other.d_ptr} {}

  // access raw pointer
  inline const CUdeviceptr& d_pointer() const
  {
    return (const CUdeviceptr&)d_ptr;
  }

  // re-size buffer to given number of bytes
  void resize(size_t size)
  {
    if (size == sizeInBytes) return;
    if (d_ptr) free();
    alloc(size);
  }

  // allocate to given number of bytes
  void alloc(size_t size)
  {
    assert(d_ptr == nullptr);
    this->sizeInBytes = size;
    CUDA_CHECK(cudaMalloc((void**)&d_ptr, sizeInBytes));
    owned = true;
  }

  // free allocated memory
  void free()
  {
    if (d_ptr && owned) CUDA_CHECK(cudaFree(d_ptr));
    d_ptr = nullptr;
    sizeInBytes = 0;
    owned = false;
  }

  void nullify(cudaStream_t stream)
  {
    if (d_ptr) CUDA_CHECK(cudaMemsetAsync((void*)d_ptr, 0, sizeInBytes, stream));
  }

  template<typename T> void alloc_and_upload(const std::vector<T>& vt)
  {
    resize(vt.size() * sizeof(T));
    upload((const T*)vt.data(), vt.size());
  }

  template<typename T> void alloc_and_upload(const T* ptr, size_t size)
  {
    resize(size * sizeof(T));
    upload((const T*)ptr, size);
  }

  template<typename T>
  void upload(const T* t, size_t count)
  {
    assert(d_ptr != nullptr);
    assert(sizeInBytes == count * sizeof(T));
    CUDA_CHECK(cudaMemcpy(d_ptr, (void*)t, count * sizeof(T), cudaMemcpyHostToDevice));
  }

  template<typename T>
  void download(T* t, size_t count)
  {
    assert(d_ptr != nullptr);
    assert(sizeInBytes == count * sizeof(T));
    CUDA_CHECK(cudaMemcpy((void*)t, d_ptr, count * sizeof(T), cudaMemcpyDeviceToHost));
  }

  template<typename T>
  void alloc_and_upload_async(const std::vector<T>& vt, cudaStream_t stream)
  {
    resize(vt.size() * sizeof(T));
    upload_async((const T*)vt.data(), vt.size(), stream);
  }

  template<typename T>
  void alloc_and_upload_async(const T* ptr, size_t size, cudaStream_t stream)
  {
    resize(size * sizeof(T));
    upload_async((const T*)ptr, size, stream);
  }

  template<typename T>
  void upload_async(const T* t, size_t count, cudaStream_t stream)
  {
    assert(d_ptr != nullptr);
    assert(sizeInBytes == count * sizeof(T));
    CUDA_CHECK(cudaMemcpyAsync(d_ptr, (void*)t, count * sizeof(T), cudaMemcpyHostToDevice, stream));
  }

  template<typename T>
  void download_async(T* t, size_t count, cudaStream_t stream)
  {
    assert(d_ptr != nullptr);
    assert(sizeInBytes == count * sizeof(T));
    CUDA_CHECK(cudaMemcpyAsync((void*)t, d_ptr, count * sizeof(T), cudaMemcpyDeviceToHost, stream));
  }

  bool owned = false;
  size_t sizeInBytes = 0;
  void* d_ptr = nullptr;
};

#endif // __cplusplus
#endif // OVR_COMMON_CUDA_BUFFER_H
