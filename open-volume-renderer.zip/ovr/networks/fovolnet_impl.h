//. ======================================================================== //
//. Copyright 2019-2020 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#pragma once

#include "ovr/common/cross_device_buffer.h"
#include "ovr/common/math.h"
#include "ovr/renderer.h"

#pragma warning(disable: 4624)

#include <memory>
#include <vector>
#include <string>

using namespace ovr::math;

namespace ovr {

struct FoVolNetImpl {
    public:
        int height{ 0 }, width{ 0 };
        std::vector<vec3f> buf;

    public:
        virtual void initialize(const std::string& model) = 0;
        virtual void process(MainRenderer::FrameBufferData* fb) = 0;
        virtual void map(std::shared_ptr<CrossDeviceBuffer>& ptr) const = 0;
        virtual void resize(int width, int height) = 0;
};

}