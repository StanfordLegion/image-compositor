//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu & David Bauer                                  //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "fovolnet_impl_torch.h"

using namespace ovr::math;

namespace ovr {

torch::Tensor
FoVolNetImplTorch::float4_to_tensor(void* rgba, int64_t w, int64_t h)
{
  try {
    auto opts = torch::TensorOptions().dtype(torch::kFloat32).device(torch::Device(torch::kCUDA, 0));
    torch::Tensor out = torch::from_blob(rgba, { 1, h, w, 4 }, opts).permute({ 0, 3, 1, 2 });
    out = out.index({at::indexing::Slice(0,1), at::indexing::Slice(0,3), "..."}) * out.index({at::indexing::Slice(0,1), 3, "..."});
    return out;
  }
  CATCH_TORCH_ERROR;
}

torch::Tensor
FoVolNetImplTorch::float3_to_tensor(void* grad, int64_t w, int64_t h)
{
  try {
    auto opts = torch::TensorOptions().dtype(torch::kFloat32).device(torch::Device(torch::kCUDA, 0));
    return torch::from_blob(grad, { 1, h, w, 3 }, opts).permute({ 0, 3, 1, 2 });
  }
  CATCH_TORCH_ERROR;
}

void
FoVolNetImplTorch::initialize(const std::string& model)
{
    std::cout << "[fovolnet] loading model " << model << std::endl;
    load_module(model);
}

void
FoVolNetImplTorch::load_module(const std::string& filename)
{
    try {
      module = torch::jit::load(filename, torch::kCPU);
    }
    catch (const torch::Error& e) {
      std::cerr << "[fovolnet] error loading the model" << std::endl << e.what() << std::endl;
      throw std::runtime_error("error loading the model");
    }

    try {
      module.to(device, dtype);
      module.eval();
    }
    CATCH_TORCH_ERROR;
}


void 
FoVolNetImplTorch::forward(torch::Tensor& input)
{
    torch::NoGradGuard no_grad;

    try {
        auto _output = module.forward({ input, recurrent }).toTuple(); /* ~30ms */

        output = (*_output)
                    .elements()[0]
                    .toTensor()
                    .index(/* first image of the batch */ { 0 })
                    .permute({ 1, 2, 0 })
                    .to(torch::kFloat32)
                    .contiguous();

        // recurrent = (*_output).elements()[1].toTensor();
        recurrent = (*_output).elements()[1].toTensorList();
    }
    CATCH_TORCH_ERROR;
}


void
FoVolNetImplTorch::process(ovr::MainRenderer::FrameBufferData* fb)
{
    const size_t num_bytes = (size_t)width * height * sizeof(vec3f);

    // auto start = std::chrono::high_resolution_clock::now();

    auto rgba = float4_to_tensor(fb->rgba->to_cuda()->data(), width, height).nan_to_num().to(dtype);
    // auto grad = float3_to_tensor(fb->grad->to_cuda()->data(), width, height).nan_to_num();

    // torch::Tensor input;
    // try {
    //   input = torch::cat({ rgba, grad }, 1);
    // }
    // CATCH_TORCH_ERROR;

    forward(rgba);

    // CUDA_CHECK(cudaMemcpyAsync((void*)buf.data(), output.data_ptr(), num_bytes, cudaMemcpyDeviceToHost, 0));
    CUDA_CHECK(cudaMemcpy((void*)buf.data(), output.data_ptr(), num_bytes, cudaMemcpyDeviceToHost));

    // auto end = std::chrono::high_resolution_clock::now();
    // auto diff = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    // std::cout << "FoVolNet total time = " << diff.count() << "\t\n";
    // std::cout.flush();
}

void
FoVolNetImplTorch::map(std::shared_ptr<CrossDeviceBuffer>& ptr) const 
{
    const size_t num_bytes = (size_t)width * height * sizeof(vec3f);
    ptr->set_data((void*)buf.data(), num_bytes, CrossDeviceBuffer::DEVICE_CPU);
}

void
FoVolNetImplTorch::resize(int w, int h)
{
    width = w;
    height = h;

    try {
        recurrent = torch::nullopt;

        // TODO resizing does not work //
        for (auto layers : module.children()) {
        if (layers.hasattr("reset_parameters")) {
            layers.get_method("reset_parameters")({});
        }
        }
    }
    CATCH_TORCH_ERROR;

    buf.resize((size_t)width * height * sizeof(vec3f));
}

}