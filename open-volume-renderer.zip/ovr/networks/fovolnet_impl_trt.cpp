#include "fovolnet_impl_trt.h"

#include <ovr/common/cuda_buffer.h>

#include <fstream>

#pragma warning(push)
#pragma warning(disable : 4624) /* MSVC */

using namespace ovr::math;

namespace ovr {

torch::Tensor
FoVolNetImplTRT::float4_to_tensor(void* rgba, int64_t w, int64_t h)
{
  try {
    auto opts = torch::TensorOptions().dtype(torch::kFloat32).device(torch::Device(torch::kCUDA, 0));
    torch::Tensor out = torch::from_blob(rgba, { 1, h, w, 4 }, opts).permute({ 0, 3, 1, 2 });
    out = out.index({at::indexing::Slice(0,1), at::indexing::Slice(0,3), "..."}) * out.index({at::indexing::Slice(0,1), 3, "..."});
    return out;
  }
  CATCH_TORCH_ERROR;
}

torch::Tensor
FoVolNetImplTRT::float3_to_tensor(void* rgb, int64_t w, int64_t h)
{
  try {
    auto opts = torch::TensorOptions().dtype(torch::kFloat32).device(torch::Device(torch::kCUDA, 0));
    return torch::from_blob(rgb, { 1, 3, h, w }, opts).permute({ 0, 2, 3, 1 });
  }
  CATCH_TORCH_ERROR;
}

size_t 
FoVolNetImplTRT::get_size_by_dim(const nvinfer1::Dims& dims, bool is_input)
{
    size_t size = 1;
    std::cout << "[fovolnet] " << (is_input ? "in_dim " : "out_dim ");
    for (size_t i = 0; i < dims.nbDims; ++i)
    {
        std::cout << dims.d[i] << " ";
        size *= dims.d[i];
    }
    std::cout << std::endl;
    return size;
}


void
FoVolNetImplTRT::initialize(const std::string& model)
{
    std::cout << "[fovolnet] loading model " << model << std::endl;
    load_module(model);


    context.reset(engine->createExecutionContext());

    io_binding_sizes.resize(engine->getNbBindings());
    io_buffers.resize(engine->getNbBindings()); // buffers for input and output data


    for (size_t i = 0; i < engine->getNbBindings(); ++i)
    {
        io_binding_sizes[i] = get_size_by_dim(engine->getBindingDimensions(i), engine->bindingIsInput(i)) * sizeof(float);
        CUDA_CHECK(cudaMalloc(&io_buffers[i], io_binding_sizes[i]));
        if (engine->bindingIsInput(i))
        {
            n_in_bindings++;
        }
        else
        {
            n_out_bindings++;
        }
    }

    std::cout << "[fovolnet] Allocated " << io_buffers.size() << " io buffers" << std::endl;
    std::cout << "[fovolnet] Found " << n_in_bindings << " inputs" << std::endl;
    std::cout << "[fovolnet] Found " << n_out_bindings << " outputs" << std::endl;
}

void
FoVolNetImplTRT::load_module(const std::string& filename)
{
    std::ifstream engineFile(filename, std::ios::binary);
    if (!engineFile.good()) {
        std::cerr << "Error opening engine file: " << filename << std::endl;
        throw std::runtime_error("error loading the model");
    }
    engineFile.seekg(0, std::ifstream::end);
    int64_t fsize = engineFile.tellg();
    engineFile.seekg(0, std::ifstream::beg);

    std::vector<char> engineData(fsize);
    engineFile.read(engineData.data(), fsize);
    if (!engineFile.good()) {
        std::cerr << "Error opening engine file: " << filename << std::endl;
        throw std::runtime_error("error loading the model");
    }

    TRTUniquePtr<nvinfer1::IRuntime> runtime{nvinfer1::createInferRuntime(logger)};
    
    // TODO: Enable in the future
    // if (DLACore != -1)
    // {
    //     runtime->setDLACore(DLACore);
    // }

    //runtime->setErrorRecorder(&gRecorder);
    engine.reset(runtime->deserializeCudaEngine(engineData.data(), fsize, nullptr));
}

void
FoVolNetImplTRT::process(MainRenderer::FrameBufferData* fb)
{
    auto rgb = float4_to_tensor(fb->rgba->to_cuda()->data(), width, height).nan_to_num().contiguous();
    CUDA_CHECK(cudaMemcpy((void*)io_buffers.front(), rgb.data_ptr(), io_binding_sizes.front(), cudaMemcpyDeviceToDevice));

    //context->enqueue(1, io_buffers.data(), 0, nullptr);
    context->execute(1, io_buffers.data());
    CUDA_CHECK(cudaDeviceSynchronize());


    // CUDA_CHECK(cudaMemcpy((void*)io_buffers[1], io_buffers.back(), io_binding_sizes[1], cudaMemcpyDeviceToDevice));
    // for (int i = 2; i < n_in_bindings; i++)
    // {
    //     CUDA_CHECK(cudaMemcpy((void*)io_buffers[i], io_buffers[i+n_in_bindings-1], io_binding_sizes[i], cudaMemcpyDeviceToDevice));
    // }
    for (int i = 1; i < n_in_bindings; i++)
    {
        CUDA_CHECK(cudaMemcpy((void*)io_buffers[i], io_buffers[i+n_in_bindings], io_binding_sizes[i], cudaMemcpyDeviceToDevice));
    }

    auto out = float3_to_tensor((void*)io_buffers.back(), width, height).contiguous();
    CUDA_CHECK(cudaMemcpy((void*)buf.data(), out.data_ptr(), io_binding_sizes.back(), cudaMemcpyDeviceToHost));
}

void
FoVolNetImplTRT::map(std::shared_ptr<CrossDeviceBuffer>& ptr) const
{
    ptr->set_data((void*)buf.data(), io_binding_sizes.back(), CrossDeviceBuffer::DEVICE_CPU);
}

void
FoVolNetImplTRT::resize(int w, int h)
{
    width = w;
    height = h;

    buf.resize((size_t)width * height * sizeof(vec3f));
}

}

#pragma warning(pop)
