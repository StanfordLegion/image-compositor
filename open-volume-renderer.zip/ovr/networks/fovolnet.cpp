//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "fovolnet.h"
#include "fovolnet_impl_torch.h"
#include "fovolnet_impl_trt.h"

#include "ovr/common/cuda_buffer.h"
#include "ovr/common/math.h"

#pragma warning(push)
#pragma warning(disable : 4624) /* MSVC */

#include <torch/script.h>
#include <torch/torch.h>
#include <torch/types.h>

#include <chrono>
#include <string>

namespace ovr {

FoVolNet::~FoVolNet()
{
  pimpl.reset();
}

FoVolNet::FoVolNet() : inference_time(0.0) {}

FoVolNet::FoVolNet(FoVolNet&& other) noexcept = default;

FoVolNet&
FoVolNet::operator=(FoVolNet&& other) noexcept = default;

void
FoVolNet::initialize(int ac, const char** av)
{
  if (ac < 3) {
    pimpl.reset(new FoVolNetImplTorch());
    pimpl->initialize("model.pt");
  } else {
    std::string filename(av[2]);
    std::string ext = filename.substr(filename.find_last_of(".") + 1);
    if (ext == "pt") {
      pimpl.reset(new FoVolNetImplTorch());
    } else if (ext == "trt") {
      pimpl.reset(new FoVolNetImplTRT());
    } else {
      throw std::runtime_error("unsupported model type '." + ext + "'");
    }
    pimpl->initialize(filename);
  }
  
}

void
FoVolNet::process(ovr::MainRenderer::FrameBufferData* fb)
{
  auto start = std::chrono::high_resolution_clock::now();
  pimpl->process(fb);
  CUDA_CHECK(cudaDeviceSynchronize());
  auto end = std::chrono::high_resolution_clock::now();
  auto diff = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
  std::cout << "[fovolnet] inference time = " << diff.count() << "ms\r" << std::flush;
  inference_time += diff.count();
}

void
FoVolNet::map(std::shared_ptr<CrossDeviceBuffer>& output) const
{
  pimpl->map(output);
}

void
FoVolNet::resize(int width, int height)
{
  pimpl->resize(width, height);
}

} // namespace ovr

#pragma warning(pop)
