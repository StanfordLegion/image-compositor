//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#pragma once

#include "fovolnet_impl.h"

#include "ovr/common/cross_device_buffer.h"
#include "ovr/common/math.h"
#include "ovr/renderer.h"

#include <memory>
#include <vector>

namespace ovr {

struct FoVolNet {
  double inference_time;

  ~FoVolNet();
  FoVolNet();
  FoVolNet(const FoVolNet& other) = delete;
  FoVolNet(FoVolNet&& other) noexcept;
  FoVolNet& operator=(const FoVolNet& other) = delete;
  FoVolNet& operator=(FoVolNet&& other) noexcept;

  void initialize(int ac, const char** av);
  void process(MainRenderer::FrameBufferData* fb);
  void map(std::shared_ptr<CrossDeviceBuffer>& output) const;
  void resize(int width, int height);

private:
  std::unique_ptr<FoVolNetImpl> pimpl; // pointer to the internal implementation
};

} // namespace ovr
