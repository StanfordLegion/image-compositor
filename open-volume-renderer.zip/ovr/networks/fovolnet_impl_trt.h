//. ======================================================================== //
//. Copyright 2019-2020 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#pragma once

#include "fovolnet_impl.h"
#include <NvInfer.h>
#include <NvOnnxParser.h>

#include <torch/torch.h>
#include <torch/types.h>

#define CATCH_TORCH_ERROR                                              \
  catch (const torch::Error& e)                                        \
  {                                                                    \
    std::cerr << "Torch error: " << e.what() << std::endl;             \
    throw std::runtime_error(std::string("Torch error: ") + e.what()); \
  }                                                                    \
  catch (const std::exception& e)                                      \
  {                                                                    \
    std::cerr << "Other error: " << e.what() << std::endl;             \
    throw std::runtime_error(std::string("Other error: ") + e.what()); \
  }

namespace ovr {

class TRTLogger : public nvinfer1::ILogger           
{
    void log(Severity severity, const char* msg) noexcept override
    {
        // suppress info-level messages
        if (severity <= Severity::kWARNING)
            std::cout << msg << std::endl;
    }
};

struct TRTDestroy
{
    template< class T >
    void operator()(T* obj) const
    {
        if (obj)
        {
            obj->destroy();
        }
    }
};

template< class T >
using TRTUniquePtr = std::unique_ptr< T, TRTDestroy >;

struct FoVolNetImplTRT : public FoVolNetImpl {
    public:
        TRTLogger logger;
        TRTUniquePtr<nvinfer1::ICudaEngine> engine {nullptr};
        TRTUniquePtr<nvinfer1::IExecutionContext> context {nullptr};

        int n_in_bindings = 0, n_out_bindings = 0;
        std::vector<size_t> io_binding_sizes;
        std::vector<void*> io_buffers;

    public:
        FoVolNetImplTRT()
        {
        };

        size_t get_size_by_dim(const nvinfer1::Dims& dims, bool is_input);

        void initialize(const std::string& model);

        void load_module(const std::string& filename);

        void process(MainRenderer::FrameBufferData* fb);

        void map(std::shared_ptr<CrossDeviceBuffer>& ptr) const;

        void resize(int w, int h);

        // TODO: This can be optimized away; we only use this for channel permutation
        torch::Tensor float4_to_tensor(void* rgba, int64_t w, int64_t h);

        torch::Tensor float3_to_tensor(void* grad, int64_t w, int64_t h);
};

}