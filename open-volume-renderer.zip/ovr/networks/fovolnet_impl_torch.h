//. ======================================================================== //
//. Copyright 2019-2020 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#pragma once

#include "fovolnet_impl.h"

#include <torch/script.h>
#include <torch/torch.h>
#include <torch/types.h>

#define CATCH_TORCH_ERROR                                              \
  catch (const torch::Error& e)                                        \
  {                                                                    \
    std::cerr << "Torch error: " << e.what() << std::endl;             \
    throw std::runtime_error(std::string("Torch error: ") + e.what()); \
  }                                                                    \
  catch (const std::exception& e)                                      \
  {                                                                    \
    std::cerr << "Other error: " << e.what() << std::endl;             \
    throw std::runtime_error(std::string("Other error: ") + e.what()); \
  }

namespace ovr {

struct FoVolNetImplTorch : public FoVolNetImpl {
    public:
        const torch::Device device;
        const torch::ScalarType dtype;
        const torch::TensorOptions opts;

        torch::jit::Module module;

        // torch::Tensor recurrent;
        torch::optional<torch::List<torch::Tensor>> recurrent;

        torch::Tensor output; // use member variable to avoid data being deleted


    public:
        FoVolNetImplTorch()
            : device(torch::cuda::is_available() ? torch::Device(torch::kCUDA, 0) : torch::Device(torch::kCPU))
            , dtype(torch::kFloat16)
            , opts(torch::TensorOptions().dtype(dtype).device(device))
        {
        };

  void initialize(const std::string& model);

  void load_module(const std::string& filename);

  void forward(torch::Tensor& input);

  void process(MainRenderer::FrameBufferData* fb);

  void map(std::shared_ptr<CrossDeviceBuffer>& ptr) const;

  void resize(int w, int h);

  torch::Tensor float4_to_tensor(void* rgba, int64_t w, int64_t h);

  torch::Tensor float3_to_tensor(void* grad, int64_t w, int64_t h);
};

}