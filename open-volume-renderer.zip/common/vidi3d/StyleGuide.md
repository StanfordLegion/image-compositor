# VIDi 3D Style Guide

## Header Files

### The #define Guard
All header files should have `#define` guards to prevent multiple inclusion. The format of the symbol name should be `V3D_<PATH>_<FILE>_H_`.
```cpp
// src/Renderer/VolumeRenderer.h
#ifndef V3D_RENDERER_VOLUMERENDERER_H_
#define V3D_RENDERER_VOLUMERENDERER_H_
...
#endif // V3D_RENDERER_VOLUMERENDERER_H_
```

### Order of Includes (not decided yet)
1. Related header.
2. C system files (if there is any).
3. C++ system files.
4. Other libraries' .h files (OpenGL, Qt, etc.).
5. V3D project's .h files.

```cpp
// VolumeRenderer.cpp

#include "Renderer/VolumeRenderer.h"

#include <iostream>  // within each section, ordered alphabetically
#include <map>
#include <vector>

#include <QString>   // other libraries' headers

#include "Renderer/Volume.h"
```

## Classes

### Copyable and Movable Types (not decided yet)
For types that are not copyable/movable, explicitly disable copy/move constructor and assignment operator using `= delete` in the `public:` section.

### Use of const
Declare member functions as `const` whenever it makes sence.

## Functions

### Parameter Ordering
When defining a function, parameter order is: inputs, then outputs.

### Reference and Pointer Arguments
Add `const` for input reference and pointer parameters. For input parameters, references are preferable. For output parameters, use pointers. Never use non-const reference parameters except when required by convention, e.g., `swap()`.

## Other C++ Features

### Smart Pointers
Use smart pointers whenever appropriate. Avoid naked `new`'s and `delete`'s.

### 0 and nullptr/NULL
Use `0` for integers, `0.0` for doubles, `0.0f` for floats, `nullptr` (instead of `NULL` or `0`) for pointers, and `'\0'` for chars.

### Integer Types
Use types defined in `<cstdint>` (`int16_t`, `uint32_t`, `int64_t`, etc.) for data structures that you want to make sure they are in certain sizes. Use normal types (`short`, `int`, `unsigned char`, etc.) otherwise.

## Naming

### Folder Names
Use **UpperCamelCase** for the names of the folders under `src/`.
```
src/Renderer
```

### File Names
Use **UpperCamelCase** for file names.
```
MyVolumeRenderer.cpp
```

### Type Names
Use **UpperCamelCase** for the names of all types, including classes, structs, type aliases, enums, and type template parameters.
```cpp
class VolumeRenderer { ...
struct LightParams { ...
typedef unordered_map<string, Property *> PropertiesMap;
enum LightType { ...
```

### Interface Names (not decided yet)
Interface names begin with `I` prefix.
```cpp
class IData { ...
```

### Variable Names
Use **lowerCamelCase** for variable names.
```cpp
string lowerCamelCase;
int tableSize;
```

### Class Data Members
Put an **underscore** at the beginning of the names for class data members
```cpp
Class Volume {
    string _underscoreAtBeginning;
    int _size;
};
```

### Constant Names
Use **UPPERCASE** with **underscores** for macro names.
```cpp
const int DAYS_IN_A_WEEK = 7;
```

### Function Names
Use **lowerCamelCase** for function names.
```cpp
void myPowerfulFunction();
void openFileOrDie();
```

### Getters and Setters
```cpp
class Foo {
    ...
    int xyz() const;
    void setXyz(int value);
};
```

### Namespace Names
Put everything under `v3d` namespace.
```cpp
namespace v3d {
...
} // namespace v3d
```

### Enumerator Names
The same as constant names.
```cpp
enum LightType {
    DIRECTIONAL_LIGHT,
    POINT_LIGHT,
    SPOT_LIGHT
};
```

### Macro Names
Use **UPPERCASE** with **underscores** for macro names.
```cpp
#define ROUND(x) ...
#define PI_ROUNDED 3.0
```

### Exceptions to Naming Rules
* Vectors and matrices (vec3, vec4, mat4, etc.)

## Comments

### Comments for Doxygen (Not discussed yet)
Write comments for Doxygen for everything exposed as part of API.

### TODO Comments
Use `TODO` (all uppercase) comments for code that is temporary, a short-term solution, or good-enough but not perfect. Include an identifier (e.g. your name) so that other people know who is responsible for the issue.
```cpp
// TODO(KLM): please rewrite this
```

### Deprecation Comments
Mark deprecated interface points with `DEPRECATED` comments.

## Formatting

### Spaces vs. Tabs
Use only spaces, and indent **4 spaces** at a time. Do not use tabs in the code.

### Function Declarations and Definitions
Return type on the same line as function name, parameters on the same line if they fit. Wrap parameter lists if they are too long.
```cpp
ReturnType ClassName::functionName(Type parName1, Type parName2) {
    doSomething();
    ...
}
```
If there is too much text to fit on one line:
```cpp
ReturnType ClassName::reallyLongFunctionName(Type parName1, Type parName2,
                                             Type parName3) {
    doSomething();
    ...
}
```
or if you cannot fit even the first parameter:
```cpp
ReturnType LongClassName::reallyReallyReallyLongFunctionName(
        Type parName1,  // 8 space indent
        Type parName2,
        Type parName3) {
    doSomething();  // 4 space indent
    ...
}
```

### Conditionals
Prefer no spaces inside parentheses. The `if` and `else` keywords belong on separate lines.
```cpp
if (condition) {  // no spaces inside parentheses
    ...  // 4 space indent.
} else if (...) {  // The else goes on the same line as the closing brace.
    ...
} else {
    ...
}
```

### Loops and Switch Statements
`case` blocks in switch statements can have curly braces or not, depending on your preference. If you do include curly braces they should be placed as shown below.
```cpp
switch (var) {
    case 0: {  // 4 space indent
        ...    // 8 space indent
        break;
    }
    case 1: {
        ...
        break;
    }
    default: {
        assert(false);  // if the default case should never execute
    }
}
```
Braces are optional for single-statement loops.
```cpp
for (int i = 0; i < someNumber; ++i)
    printf("I love you\n");

for (int i = 0; i < someNumber; ++i) {
    printf("I take it back\n");
}
```
Empty loop bodies should use `{}` or `continue`, but not a single semicolon.

### Pointer and Reference Expressions
Space follows `*` or `&`.
```cpp
// These are fine, space following.
char* c;    // but remember to do "char* c, *d, *e, ...;"!
const string& str;
```

### Preprocessor Directives
The hash mark that starts a preprocessor directive should always be at the beginning of the line.
```cpp
    if (lopsidedScore) {
#if DISASTER_PENDING      // Correct -- Starts at beginning of line
        dropEverything();
# if NOTIFY               // 1 space for each level in nested if-endif
        notifyClient();
# endif
#endif
        backToNormal();
    }
```

### Class Format
Sections in public, protected and private order. `public:`, `protected:`, and `private:` keywords have no indent.
```cpp
class MyRenderer : public VolumeRenderer {
public:      // no indent
    MyRenderer();  // Regular 4 space indent.
    explicit MyRenderer(int var);
    ~MyRenderer() {}

    void someFunction();
    void someFunctionThatDoesNothing() {
    }

    void setSomeVar(int var) { _someVar = var; }
    int someVar() const { return _someVar; }

private:
    bool someInternalFunction();

    int _someVar;
    int _someOtherVar;
};
```

### Constructor Initializer Lists
Constructor initializer lists can be all on one line or with subsequent lines indented four spaces.
```cpp
// When everything fits on one line:
MyRenderer::MyRenderer(int var) : _someVar(var) {
    doSomething();
}

// If the signature and initializer list are not all on one line,
// you must wrap before the colon and indent 4 spaces:
MyRenderer::MyRenderer(int var)
    : _someVar(var), _someOtherVar(var + 1) {
    doSomething();
}

// When the list spans multiple lines, put each member on its own line
// and align them:
MyRenderer::MyRenderer(int var)
    : _someVar(var)             // 4 space indent
    , _someOtherVar(var + 1) {  // put comma in front of the variable name
    doSomething();
}
```

### Namespace Formatting
Namespaces do not add an extra level of indentation.

### Horizontal Whitespace
General:
```cpp
void f(bool b) {  // Open braces should always have a space before them.
    ...
int i = 0;  // Semicolons have no space before them.
// Spaces inside braces for braced-init-list are optional.  If you use them,
// put them on both sides!
int x[] = { 0 };
int x[] = {0};

// Spaces around the colon in inheritance and initializer lists.
class Foo : public Bar {
public:
    // For inline function implementations, put spaces between the braces
    // and the implementation itself.
    Foo(int b) : Bar(), _baz(b) {}  // No spaces inside empty braces.
    void reset() { _baz = 0; }  // Spaces separating braces from implementation.
    ...
```

Loops and Conditionals:
```cpp
if (b) {          // Space after the keyword in conditions and loops.
} else {          // Spaces around else.
}
while (test) {}   // There is no space inside parentheses.
switch (i) {
for (int i = 0; i < 5; ++i) {
// For loops always have a space after the semicolon.
// Space before the semicolon only happens in the following case.
for ( ; i < 5; ++i) {
    ...

// Range-based for loops always have a space before and after the colon.
for (auto x : counts) {
    ...
}
switch (i) {
    case 1:         // No space before colon in a switch case.
        ...
    case 2: break;  // Use a space after a colon if there's code after it.
```

Operators:
```cpp
// Assignment operators always have spaces around them.
x = 0;

// Other binary operators usually have spaces around them, but it's
// OK to remove spaces around factors.  Parentheses should have no
// internal padding.
v = w * x + y / z;
v = w*x + y/z;
v = w * (x + z);

// No spaces separating unary operators and their arguments.
x = -5;
++x;
if (x && !y)
    ...
```

Templates and Casts:
```cpp
// No spaces inside the angle brackets (< and >), before
// <, or between >( in a cast
vector<string> x;
y = static_cast<char*>(x);

set<list<string>> x;        // Permitted in C++11 code.
set<list<string> > x;       // C++03 required a space in > >.

// You may optionally use symmetric spacing in < <.
set< list<string> > x;
```

### Vertical Whitespace
Put at least one blank line between functions.
