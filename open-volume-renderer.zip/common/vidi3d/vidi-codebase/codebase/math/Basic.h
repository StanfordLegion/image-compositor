//
// Created by qadwu on 6/1/19.
//

#ifndef VIDICODEBASE_MATH_BASIC_H
#define VIDICODEBASE_MATH_BASIC_H

#include <vidi_base_export.h>

#endif // VIDICODEBASE_MATH_BASIC_H
