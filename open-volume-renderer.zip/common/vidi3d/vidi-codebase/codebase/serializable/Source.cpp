//
// Created by Qi Wu on 2019-06-26.
//

#include "TraitSerializable.h"
#include "TraitToString.h"

namespace vidi {
/**
 * @brief The ViDi data serialization system
 */
namespace serializable {
}
} // namespace vidi
