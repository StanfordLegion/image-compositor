#ifndef V3D_RENDERER_ENTRYEXITRENDERERGL_H_
#define V3D_RENDERER_ENTRYEXITRENDERERGL_H_

#include <memory>

#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/ModelGL.h"


namespace v3d {

class EntryExitRendererGL {
public:
    EntryExitRendererGL();

    void render();

    // input
    void setModelViewProjectionMatrix(const mat4& mvpMatrix) { _mvpMatrix = mvpMatrix; }
    void setGeometry(ModelGL* geometry)                      { _geometry = geometry; }

    void setMaximumDepthTexture(GLTexture2D* tex)            { _maxDepthTex = tex; }

    // output
    void setEntryBuffer(GLFramebufferObject* entryFbo) { _entryFbo = entryFbo; }
    void setExitBuffer(GLFramebufferObject* exitFbo)   { _exitFbo = exitFbo; }

private:
    std::unique_ptr<GLShaderProgram> _entryShader;
    std::unique_ptr<GLShaderProgram> _exitShader;

    mat4 _mvpMatrix;
    ModelGL* _geometry;

    GLTexture2D* _maxDepthTex;

    GLFramebufferObject* _entryFbo;
    GLFramebufferObject* _exitFbo;
};

} // namespace v3d

#endif // V3D_RENDERER_ENTRYEXITRENDERERGL_H_
