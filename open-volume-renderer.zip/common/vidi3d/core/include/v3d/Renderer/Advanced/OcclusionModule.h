#ifndef V3D_RENDERER_OCCLUSIONMODULE_H_
#define V3D_RENDERER_OCCLUSIONMODULE_H_
#ifdef V3D_USE_OPENGL_4_3

#include "v3d/Util/GLConfig.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/Matrix.h"

namespace v3d {

class OcclusionModule {
  public:
    OcclusionModule();

    // input
    void setTransferFunctionTexture(GLTexture1D* tfTex)	          { _tfTex = tfTex; }
    void setDataTexture(GLTexture3D* dataTex) 	                  { _dataTex = dataTex; }
    void setOcclusionTexture(std::shared_ptr<GLTexture3D> occTex) { _occTex = occTex; }
    void setCoordMapping(const vec3& scale, const vec3& bias) {
        _coordScale = scale;
        _coordBias = bias;
    }
    void setCoordBounds(const vec3& lower, const vec3& upper) {
        _boundsLower = lower;
        _boundsUpper = upper;
    }
    void setScalarMapping(float scale, float bias) {
        _scalarScale = scale;
        _scalarBias = bias;
    }
    void setAOParams(const float AORes, const int AOSteps) {
        _AOSampleRes = AORes;
        _AOSampleSteps = AOSteps;
    }
    void setDataSize(const ivec3& size);

    // output
    void genTexture();
    std::shared_ptr<GLTexture3D> getOcclusionTexture() { return _occTex; }

  protected:
    void createShader();

  private:
    std::unique_ptr<GLShaderProgram> _shader;
    std::shared_ptr<GLTexture3D> _occTex;

    GLTexture1D* _tfTex;
    GLTexture3D* _dataTex;
    ivec3 _dataSize;
    vec3 _coordScale;
    vec3 _coordBias;
    vec3 _boundsLower = vec3(0,0,0);
    vec3 _boundsUpper = vec3(1,1,1);
    float _scalarScale;
    float _scalarBias;

    float _AOSampleRes;
    int _AOSampleSteps;
};


}

#endif // V3D_USE_OPENGL_4_3
#endif // V3D_RENDERER_SIMPLEEMPTYSPACESKIPPING_H_
