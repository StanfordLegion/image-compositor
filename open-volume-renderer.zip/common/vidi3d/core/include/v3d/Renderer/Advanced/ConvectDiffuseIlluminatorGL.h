#ifndef V3D_RENDERER_CONVECTDIFFUSEILLUMINATORGL_H_
#define V3D_RENDERER_CONVECTDIFFUSEILLUMINATORGL_H_

#include <memory>
#include <vector>

#include "v3d/Util/Box.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/LightSource.h"
#include "v3d/Util/Vector.h"


namespace v3d {

/**
 * @brief Yubo Zhang's Fast Global Illumination Algorithm.
 *
 * Uses convection-diffusion model to approximate light propagation and diffusion.
 */
class ConvectDiffuseIlluminatorGL {
public:
    ConvectDiffuseIlluminatorGL();

    void setDataTexture(GLTexture3D* tex);
    void setTransferFunctionTexture(GLTexture1D* tex);
    void setLightSources(const std::vector<LightSource>& lightSrcs);

    void setAbsorptionCoefficient(float absorbCoeff);
    void setScatteringCoefficient(float scatterCoeff);

    void setScalarMapping(float scale, float bias) { _scalarScale = scale; _scalarBias = bias; }
    void setUvwTransform(const vec3& scale, const vec3& translate) { _uvwScale = scale; _uvwTranslate = translate; }
    void setBoundingBox(const Box<float>& box)                     { _boundingBox = box; }
    void setDownsampling(bool enabled)             { _downsampling = enabled; }

    float absorptionCoefficient() const { return _absorbCoeff; }
    float scatteringCoefficient() const { return _scatterCoeff; }

    GLTexture3D* dataTexture() { return _dataTex; }

    std::shared_ptr<GLTexture3D> alphaTexture()          { return _alphaTex; }
    std::shared_ptr<GLTexture3D> lightTexture(int index) { return _lightTex[index]; }
    std::shared_ptr<GLTexture3D> colorTexture()          { return _colorTex; }
    std::shared_ptr<GLTexture3D> colorMSTexture()        { return _colorMSTex; }

    void update();

protected:
    void updateShaders();
    void prepareTextures();
    void updateAlpha();
    void updateLight(int index);        // convection
    void updateColor();                 // composition
    void updateColorMS();               // diffusion

private:
    std::unique_ptr<GLShaderProgram> _updateAlphaShader;
    std::unique_ptr<GLShaderProgram> _initLightDirShader;
    std::unique_ptr<GLShaderProgram> _updateLightDirShader;
    std::unique_ptr<GLShaderProgram> _updateColorShader;
    std::unique_ptr<GLShaderProgram> _updateColorMSShader;

    std::shared_ptr<GLTexture3D> _alphaTex;
    std::shared_ptr<GLTexture3D> _colorTex;
    std::shared_ptr<GLTexture3D> _colorMSTex;

    std::vector<std::shared_ptr<GLTexture3D>> _lightTex;

    GLTexture3D* _dataTex;
    GLTexture1D* _tfTex;

//    ivec3 _dim;

    float _absorbCoeff;
    float _scatterCoeff;

    int _diffuseIterations;

    //std::vector<vv::Light> _lights;

//    vec2 _tfRange;

    float _scalarScale;
    float _scalarBias;

    // for clipping
    vec3 _uvwScale;
    vec3 _uvwTranslate;
    Box<float> _boundingBox;

//    int _lightCount;
    std::vector<LightSource> _lightSrcs;
//    std::vector<vv::vec4> _lightPos;
//    std::vector<vv::vec4> _lightColor;
//    std::vector<float> _lightIntensity;
//    std::vector<float> _lightRadius;

    bool _downsampling;

    // dirty flags
    bool _alphaFlag;
    std::vector<bool> _lightFlag;
    bool _colorFlag;
};

} // namespace v3d

#endif // V3D_RENDERER_CONVECTDIFFUSEILLUMINATORGL_H_
