#ifndef V3D_RENDERER_REGULARGRIDVOLUMEGL_H_
#define V3D_RENDERER_REGULARGRIDVOLUMEGL_H_

#include <memory>

#include "v3d/Data/RegularGridDataGL.h"
#include "v3d/Renderer/IRegularGridVolumeGL.h"
#include "v3d/Util/Box.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/Property.h"


namespace v3d {

class RegularGridVolumeGL : public IRegularGridVolumeGL {
public:
    RegularGridVolumeGL();
    virtual ~RegularGridVolumeGL() {}

    GLTexture3D* dataTexture() override;
    Box<float> textureBox()  const override { return _textureBox; }
    Box<float> boundingBox() const override { return _boundingBox; }
    Box<float> clippingBox() const override { return _clippingBox.value(); }

    vec3 gridSpacing() const override { return _data->spacing(); }

    std::shared_ptr<RegularGridDataGL> data()              { return _data; }
    void setData(std::shared_ptr<RegularGridDataGL> data_) { _data = data_; }
    void setTextureBox(const Box<float>& texBox)   { _textureBox = texBox; }
    void setBoundingBox(const Box<float>& volBox);
    void setClippingBox(const Box<float>& clipBox);

    bool isDataDirty() const override             { return _dataDirty; }
    void setDataDirty(bool dirty) override        { _dataDirty = dirty; }
    bool isClippingBoxDirty() const override      { return _clippingBox.isDirty(); }
    void setClippingBoxDirty(bool dirty) override { _clippingBox.setDirty(dirty); }

    Property<Box<float>>* clippingBoxProperty() { return &_clippingBox; }

    // data for the second dimension of 2D TF
    GLTexture3D* secondaryDataTexture() override { return _secondDataTex; }
    void setSecondaryDataTexture(GLTexture3D* tex) { _secondDataTex = tex; }

    std::shared_ptr<ILookupTable<vec4>> transferFunction() override { return _tf; }
    void setTransferFunction(std::shared_ptr<ILookupTable<vec4>> tf) { _tf = tf; }
    bool isTransferFunctionDirty() const override            { return _isTFDirty; }
    bool isTransferFunctionDirtyCoarse() const override      { return _isTFDirtyCoarse; }
    void setTransferFunctionDirty(bool dirty) override       { _isTFDirty = dirty; }
    void setTransferFunctionDirtyCoarse(bool dirty) override { _isTFDirtyCoarse = dirty; }

    std::shared_ptr<ILookupTable2D<vec4>> transferFunction2D() override    { return _tf2d; }
    void setTransferFunction2D(std::shared_ptr<ILookupTable2D<vec4>> tf2d) { _tf2d = tf2d; }
    bool isTransferFunction2DDirty() const override                        { return _tf2dDirty; }
    void setTransferFunction2DDirty(bool dirty) override                   { _tf2dDirty = dirty; }

    bool  isVisible() const override                   { return _visible.value(); }
    float sampleDistance() const override              { return _sampleDistance.value(); }
    InterpolationType interpolationType() const override { return InterpolationType(_interpolationType.value()); }
    dvec2 scalarMappingRange() const override          { return _scalarMappingRange.value(); }
    dvec2 secondaryScalarMappingRange() const override { return _secondaryScalarMappingRange.value(); }
    float opacityUnitDistance() const override         { return _opacityUnitDistance.value(); }
    TransferFunctionType tfType() const override { return TransferFunctionType(_tfType.value()); }

    float ambient() const override                     { return _ambient.value(); }
    float diffuse() const override                     { return _diffuse.value(); }
    float specular() const override                    { return _specular.value(); }
    float shininess() const override                   { return _shininess.value(); }

    bool isBoundingBoxVisible() const override         { return _boundingBoxVisible.value(); }
    std::array<bool, 6> areBoundingBoxFacesVisible() const override { return _boundingBoxFacesVisible.value(); }
    vec4 boundingBoxLineColor() const override         { return _boundingBoxLineColor.value(); }
    vec4 boundingBoxFillColor() const override         { return _boundingBoxFillColor.value(); }

    bool isXSliceVisible() const override              { return _xSliceVisible.value(); }
    bool isYSliceVisible() const override              { return _ySliceVisible.value(); }
    bool isZSliceVisible() const override              { return _zSliceVisible.value(); }
    float xSlicePosition() const override              { return _xSlicePosition.value(); }
    float ySlicePosition() const override              { return _ySlicePosition.value(); }
    float zSlicePosition() const override              { return _zSlicePosition.value(); }
    vec4 xSliceOverlayColor() const override           { return _xSliceOverlayColor.value(); }
    vec4 ySliceOverlayColor() const override           { return _ySliceOverlayColor.value(); }
    vec4 zSliceOverlayColor() const override           { return _zSliceOverlayColor.value(); }

    void setVisible(bool visible)                      { _visible.setValue(visible); }
    void setSampleDistance(float sampleDistance)       { _sampleDistance.setValue(sampleDistance); }
    void setInterpolationType(InterpolationType type)  { _interpolationType.setValue(int(type)); }
    void setScalarMappingRange(const dvec2& range)     { _scalarMappingRange.setValue(range); }
    void setSecondaryScalarMappingRange(const dvec2& range) { _secondaryScalarMappingRange.setValue(range); }
    void setOpacityUnitDistance(float opcUnitDistance) { _opacityUnitDistance.setValue(opcUnitDistance); }
    void setTFType(TransferFunctionType tfType)        { _tfType.setValue(tfType); }
    void setAmbient(float ambient)                     { _ambient.setValue(ambient); }
    void setDiffuse(float diffuse)                     { _diffuse.setValue(diffuse); }
    void setSpecular(float specular)                   { _specular.setValue(specular); }
    void setShininess(float shininess)                 { _shininess.setValue(shininess); }
    void setBoundingBoxVisible(bool visible)           { _boundingBoxVisible.setValue(visible); }
    void setBoundingBoxFacesVisible(const std::array<bool, 6>& visible) { _boundingBoxFacesVisible.setValue(visible); }
    void setBoundingBoxLineColor(const vec4& color)    { _boundingBoxLineColor.setValue(color); }
    void setBoundingBoxFillColor(const vec4& color)    { _boundingBoxFillColor.setValue(color); }
    void setXSliceVisible(bool visible)                { _xSliceVisible.setValue(visible); }
    void setYSliceVisible(bool visible)                { _ySliceVisible.setValue(visible); }
    void setZSliceVisible(bool visible)                { _zSliceVisible.setValue(visible); }
    void setXSlicePosition(float pos)                  { _xSlicePosition.setValue(pos); }
    void setYSlicePosition(float pos)                  { _ySlicePosition.setValue(pos); }
    void setZSlicePosition(float pos)                  { _zSlicePosition.setValue(pos); }
    void setXSliceOverlayColor(const vec4& color)      { _xSliceOverlayColor.setValue(color); }
    void setYSliceOverlayColor(const vec4& color)      { _ySliceOverlayColor.setValue(color); }
    void setZSliceOverlayColor(const vec4& color)      { _zSliceOverlayColor.setValue(color); }

    bool isVisibleDirty() const override               { return _visible.isDirty(); }
    bool isSampleDistanceDirty() const override        { return _sampleDistance.isDirty(); }
    bool isInterpolationTypeDirty() const override     { return _interpolationType.isDirty(); }
    bool isScalarMappingRangeDirty() const override    { return _scalarMappingRange.isDirty(); }
    bool isSecondaryScalarMappingRangeDirty() const override { return _secondaryScalarMappingRange.isDirty(); }
    bool isOpacityUnitDistanceDirty() const override   { return _opacityUnitDistance.isDirty(); }
    bool isTFTypeDirty() const override                { return _tfType.isDirty(); }
    bool isAmbientDirty() const override               { return _ambient.isDirty(); }
    bool isDiffuseDirty() const override               { return _diffuse.isDirty(); }
    bool isSpecularDirty() const override              { return _specular.isDirty(); }
    bool isShininessDirty() const override             { return _shininess.isDirty(); }
    bool isBoundingBoxVisibleDirty() const override    { return _boundingBoxVisible.isDirty(); }
    bool isBoundingBoxFacesVisibleDirty() const override { return _boundingBoxFacesVisible.isDirty(); }
    bool isBoundingBoxLineColorDirty() const override  { return _boundingBoxLineColor.isDirty(); }
    bool isBoundingBoxFillColorDirty() const override  { return _boundingBoxFillColor.isDirty(); }

    void setVisibleDirty(bool dirty) override             { _visible.setDirty(dirty); }
    void setSampleDistanceDirty(bool dirty) override      { _sampleDistance.setDirty(dirty); }
    void setInterpolationTypeDirty(bool dirty) override   { _interpolationType.setDirty(dirty); }
    void setScalarMappingRangeDirty(bool dirty) override  { _scalarMappingRange.setDirty(dirty); }
    void setSecondaryScalarMappingRangeDirty(bool dirty) override { _secondaryScalarMappingRange.setDirty(dirty); }
    void setOpacityUnitDistanceDirty(bool dirty) override { _opacityUnitDistance.setDirty(dirty); }
    void setTFTypeDirty(bool dirty) override              { _tfType.setDirty(dirty); }
    void setAmbientDirty(bool dirty) override             { _ambient.setDirty(dirty); }
    void setDiffuseDirty(bool dirty) override             { _diffuse.setDirty(dirty); }
    void setSpecularDirty(bool dirty) override            { _specular.setDirty(dirty); }
    void setShininessDirty(bool dirty) override           { _shininess.setDirty(dirty); }
    void setBoundingBoxVisibleDirty(bool dirty) override  { _boundingBoxVisible.setDirty(dirty); }
    void setBoundingBoxFacesVisibleDirty(bool dirty) override { _boundingBoxFacesVisible.setDirty(dirty); }
    void setBoundingBoxLineColorDirty(bool dirty) override { _boundingBoxLineColor.setDirty(dirty); }
    void setBoundingBoxFillColorDirty(bool dirty) override { _boundingBoxFillColor.setDirty(dirty); }

    void setAllDirty(bool dirty) override {
        _dataDirty = true;
        _isTFDirty = true;
        _isTFDirtyCoarse = true;
        _tf2dDirty = true;
        _visible.setDirty(dirty);
        _sampleDistance.setDirty(dirty);
        _interpolationType.setDirty(dirty);
        _scalarMappingRange.setDirty(dirty);
        _secondaryScalarMappingRange.setDirty(dirty);
        _opacityUnitDistance.setDirty(dirty);
        _tfType.setDirty(dirty);
        _ambient.setDirty(dirty);
        _diffuse.setDirty(dirty);
        _specular.setDirty(dirty);
        _shininess.setDirty(dirty);
        _boundingBoxVisible.setDirty(dirty);
        _boundingBoxFacesVisible.setDirty(dirty);
        _boundingBoxLineColor.setDirty(dirty);
        _boundingBoxFillColor.setDirty(dirty);
    }

    Property<bool>*  visibleProperty()             { return &_visible; }
    Property<float>* sampleDistanceProperty()      { return &_sampleDistance; }
    Property<int>*   interpolationTypeProperty()   { return &_interpolationType; }
    Property<dvec2>* scalarMappingRangeProperty()  { return &_scalarMappingRange; }
    Property<float>* opacityUnitDistanceProperty() { return &_opacityUnitDistance; }
    Property<int>*   tfTypeProperty()              { return &_tfType; }
    Property<float>* ambientProperty()             { return &_ambient; }
    Property<float>* diffuseProperty()             { return &_diffuse; }
    Property<float>* specularProperty()            { return &_specular; }
    Property<float>* shininessProperty()           { return &_shininess; }
    Property<bool>*  boundingBoxVisibleProperty()  { return &_boundingBoxVisible; }
    Property<std::array<bool, 6>>* boundingBoxFaceVisibleProperty() { return &_boundingBoxFacesVisible; }
    Property<vec4>*  boundingBoxLineColorProperty() { return &_boundingBoxLineColor; }
    Property<vec4>*  boundingBoxFillColorProperty() { return &_boundingBoxFillColor; }
    Property<bool>*  xSliceVisibleProperty()       { return &_xSliceVisible; }
    Property<bool>*  ySliceVisibleProperty()       { return &_ySliceVisible; }
    Property<bool>*  zSliceVisibleProperty()       { return &_zSliceVisible; }
    Property<float>* xSlicePositionProperty()      { return &_xSlicePosition; }
    Property<float>* ySlicePositionProperty()      { return &_ySlicePosition; }
    Property<float>* zSlicePositionProperty()      { return &_zSlicePosition; }
    Property<vec4>*  xSliceOverlayColorProperty()  { return &_xSliceOverlayColor; }
    Property<vec4>*  ySliceOverlayColorProperty()  { return &_ySliceOverlayColor; }
    Property<vec4>*  zSliceOverlayColorProperty()  { return &_zSliceOverlayColor; }

    void syncFrom(RegularGridVolumeGL& other);

private:
    std::shared_ptr<RegularGridDataGL> _data;
    bool _dataDirty;

    Box<float> _textureBox;     // defines the texture coordinate system
    Box<float> _boundingBox;

    Property<Box<float>> _clippingBox;

    GLTexture3D* _secondDataTex;

    std::shared_ptr<ILookupTable<vec4>> _tf;
    bool _isTFDirty;
    bool _isTFDirtyCoarse;

    std::shared_ptr<ILookupTable2D<vec4>> _tf2d;
    bool _tf2dDirty;

    Property<bool>  _visible;
    Property<float> _sampleDistance;
    Property<int>   _interpolationType;
    Property<dvec2> _scalarMappingRange;
    Property<dvec2> _secondaryScalarMappingRange;
    Property<float> _opacityUnitDistance;
    Property<bool>  _tf2dEnabled;
    Property<int>   _tfType;
    Property<float> _ambient;
    Property<float> _diffuse;
    Property<float> _specular;
    Property<float> _shininess;
    Property<bool>  _boundingBoxVisible;
    Property<std::array<bool, 6>> _boundingBoxFacesVisible;
    Property<vec4>  _boundingBoxLineColor;
    Property<vec4>  _boundingBoxFillColor;
    Property<bool>  _xSliceVisible;
    Property<bool>  _ySliceVisible;
    Property<bool>  _zSliceVisible;
    Property<float> _xSlicePosition;
    Property<float> _ySlicePosition;
    Property<float> _zSlicePosition;
    Property<vec4>  _xSliceOverlayColor;
    Property<vec4>  _ySliceOverlayColor;
    Property<vec4>  _zSliceOverlayColor;
};

} // namespace v3d

#endif // V3D_RENDERER_REGULARGRIDVOLUMEGL_H_
