#ifndef V3D_RENDERER_BOXRENDERERGL_H_
#define V3D_RENDERER_BOXRENDERERGL_H_

#include <array>
#include <memory>

#include "v3d/Renderer/SingleColorShaderGL.h"
#include "v3d/Util/BoxGL.h"
#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class BoxRendererGL {
public:
    BoxRendererGL();

    void setBox(BoxGL* box)                               { _box = box; }
    void setModelViewProjectionMatrix(const mat4& matrix) { _mvpMatrix = matrix; }
    void setModelViewMatrix(const mat4& matrix)           { _mvMatrix = matrix; }
    void setBorderColor(const vec4& color)                { _borderColor = color; }
    void setFillColor(const vec4& color)                  { _fillColor = color; }
    void setInOutFramebuffer(GLFramebufferObject* fbo)    { _fbo = fbo; }

    std::array<bool, 6> getFacesOrientation();

    void render(bool frontFaces = true, bool backFaces = true);
    void renderBoxFace(int faceId, const vec4& color);

private:
    std::unique_ptr<SingleColorShaderGL> _shader;

    BoxGL* _box;
    mat4 _mvpMatrix;
    mat4 _mvMatrix;
    vec4 _borderColor;
    vec4 _fillColor;

    GLFramebufferObject* _fbo;
};

} // namespace v3d

#endif // V3D_RENDERER_BOXRENDERERGL_H_
