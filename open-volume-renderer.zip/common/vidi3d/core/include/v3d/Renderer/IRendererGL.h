#ifndef V3D_RENDERER_IRENDERERGL_H_
#define V3D_RENDERER_IRENDERERGL_H_

#include "v3d/Util/GLConfig.h"
#include "v3d/Util/GLFramebufferObject.h"


namespace v3d {

class IRendererGL {
public:
    virtual void render() = 0;
    virtual void setFramebufferObject(std::shared_ptr<GLFramebufferObject> fbo) = 0;

    virtual int width() const = 0;
    virtual int height() const = 0;
    virtual void resize(int w, int h) = 0;
};

} // namespace v3d

#endif // V3D_RENDERER_IRENDERERGL_H_
