#ifndef V3D_RENDERER_SIMPLEREGULARGRIDPIPELINEGL_H_
#define V3D_RENDERER_SIMPLEREGULARGRIDPIPELINEGL_H_

#include <memory>

#include "v3d/Renderer/EntryExitRendererGL.h"
#include "v3d/Renderer/ISimpleRegularGridSceneGL.h"
#include "v3d/Renderer/SimpleRegularGridRayCasterGL.h"
#include "v3d/Renderer/VolumePipelineGL.h"
#include "v3d/Util/BoxGL.h"
#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLTexture.h"


namespace v3d {

// TODO: not tested yet after refactoring
class SimpleRegularGridPipelineGL : public VolumePipelineGL {
public:
    SimpleRegularGridPipelineGL();

    void resize(int w, int h) override;
    void render() override;

    void setScene(std::shared_ptr<ISimpleRegularGridSceneGL> scn);

protected:
    void checkFlags();
    ISimpleRegularGridSceneGL* scene() { return _scene.get(); }
    IRegularGridVolumeGL* volume() { return _scene->volume().get(); }

private:
    std::unique_ptr<EntryExitRendererGL> _entryExitRenderer;
    std::unique_ptr<SimpleRegularGridRayCasterGL> _rayCaster;
    std::unique_ptr<GLFramebufferObject> _entryFbo;
    std::unique_ptr<GLFramebufferObject> _exitFbo;
    std::unique_ptr<GLTexture2D> _entryTex;
    std::unique_ptr<GLTexture2D> _exitTex;
    std::unique_ptr<GLTexture2D> _entryDepthTex;
    std::unique_ptr<GLTexture2D> _exitDepthTex;
    std::unique_ptr<GLTexture1D> _tfTex;

    std::shared_ptr<ISimpleRegularGridSceneGL> _scene;

    std::shared_ptr<BoxGL> _boundingBox;            // TODO(Min): move this to GLRegularGridVolume?
};

} // namespace v3d

#endif // V3D_RENDERER_SIMPLEREGULARGRIDPIPELINEGL_H_
