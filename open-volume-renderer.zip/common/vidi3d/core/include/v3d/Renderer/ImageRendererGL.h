#ifndef V3D_RENDERER_IMAGERENDERERGL_H_
#define V3D_RENDERER_IMAGERENDERERGL_H_

#include <memory>

#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/QuadGL.h"


namespace v3d {

class ImageRendererGL {
public:
    ImageRendererGL();

    // image to blend
    void setTexture(GLTexture2D* tex) { _tex = tex; }

    // rendering target
    void setFramebuffer(GLFramebufferObject* fbo) { _fbo = fbo; }

    void render();

protected:
    void updateShader();

private:
    std::unique_ptr<GLShaderProgram> _shader;
    std::unique_ptr<QuadGL> _quad;

    GLTexture2D* _tex;

    GLFramebufferObject* _fbo;
};

} // namespace v3d

#endif // V3D_RENDERER_IMAGERENDERERGL_H_
