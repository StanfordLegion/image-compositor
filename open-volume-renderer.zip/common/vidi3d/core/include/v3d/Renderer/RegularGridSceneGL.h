#ifndef V3D_RENDERER_REGULARGRIDSCENEGL_H_
#define V3D_RENDERER_REGULARGRIDSCENEGL_H_

#include "v3d/Renderer/IRegularGridSceneGL.h"
#include "v3d/Util/Property.h"


namespace v3d {

class RegularGridSceneGL : public IRegularGridSceneGL {
public:
    RegularGridSceneGL()
        : _lightSource(std::make_shared<LightSource>())
        , _lightSourceDirty(true)
        , _backgroundColor(vec4(0.0f))
        , _tfPreIntegration(false)
        , _lighting(false)
        , _lightingSide(int(FRONT_SIDE))
        , _emptySpaceSkipping(false)
        , _ambientOcclusion(false)
        , _AOAsShadow(false)
        , _AOStrength(1.0f)
        , _AOSampleResolution(8.0f)
        , _AOLocalSampleSize(8)
        , _globalLighting(false)
        , _globalAmbient(vec4(0.0f)) {
    }
    virtual ~RegularGridSceneGL() {}

    std::shared_ptr<IRegularGridVolumeGL> volume() override             { return _volume; }
    std::shared_ptr<const IRegularGridVolumeGL> volume() const override { return _volume; }
    void setVolume(std::shared_ptr<IRegularGridVolumeGL> vol)           { _volume = vol; }

    std::shared_ptr<ICamera> camera() override                      { return _camera; }
    std::shared_ptr<const ICamera> camera() const override          { return _camera; }
    void setCamera(std::shared_ptr<ICamera> cam)                    { _camera = cam; }

    std::shared_ptr<LightSource> lightSource() override             { return _lightSource; }
    std::shared_ptr<const LightSource> lightSource() const override { return _lightSource; }
    void setLightSource(std::shared_ptr<LightSource> lightSrc)      { _lightSource = lightSrc; }
    bool isLightSourceDirty() const override                        { return _lightSourceDirty; }
    void setLightSourceDirty(bool dirty) override                   { _lightSourceDirty = dirty; }

    vec4 backgroundColor() const override                { return _backgroundColor.value(); }
    bool isTFPreIntegrationEnabled() const override      { return _tfPreIntegration.value(); }
    bool isLightingEnabled() const override              { return _lighting.value(); }
    LightingSide lightingSide() const override           { return LightingSide(_lightingSide.value()); }
    bool isEmptySpaceSkippingEnabled() const override    { return _emptySpaceSkipping.value(); }
    bool isAmbientOcclusionEnabled() const override      { return _ambientOcclusion.value(); }
    bool isAOAsShadowEnabled() const override            { return _AOAsShadow.value(); }
    float AOStrength() const override                    { return _AOStrength.value(); }
    float AOSampleResolution() const override            { return _AOSampleResolution.value(); }
    int   AOLocalSampleSize() const override             { return _AOLocalSampleSize.value(); }
    bool isGlobalLightingEnabled() const override        { return _globalLighting.value(); }
    vec4 globalAmbient() const override                  { return _globalAmbient.value(); }

    void setBackgroundColor(const vec4& color)           { _backgroundColor.setValue(color); }
    void setTFPreIntegration(bool enable)                { _tfPreIntegration.setValue(enable); }
    void setLighting(bool enable)                        { _lighting.setValue(enable); }
    void setLightingSide(LightingSide lightSide)         { _lightingSide.setValue(int(lightSide)); }
    void setEmptySpaceSkipping(bool enable)              { _emptySpaceSkipping.setValue(enable); }
    void setAmbientOcclusion(bool enable)                { _ambientOcclusion.setValue(enable); }
    void setAOAsShadow(bool enable)                      { _AOAsShadow.setValue(enable); }
    void setAOStrength(float strength)                   { _AOStrength.setValue(strength); }
    void setAOSampleResolution(float resolution)         { _AOSampleResolution.setValue(resolution); }
    void setAOLocalSampleSize(int sampleSize)            { _AOLocalSampleSize.setValue(sampleSize); }
    void setGlobalLighting(bool enabled)                 { _globalLighting.setValue(enabled); }
    void setGlobalAmbient(const vec4& color)             { _globalAmbient.setValue(color); }

    bool isBackgroundColorDirty() const override         { return _backgroundColor.isDirty(); }
    bool isTFPreIntegrationDirty() const override        { return _tfPreIntegration.isDirty(); }
    bool isLightingDirty() const override                { return _lighting.isDirty(); }
    bool isLightingSideDirty() const override            { return _lightingSide.isDirty(); }
    bool isEmptySpaceSkippingDirty() const override      { return _emptySpaceSkipping.isDirty(); }
    bool isAmbientOcclusionDirty() const override        { return _ambientOcclusion.isDirty(); }
    bool isAOAsShadowDirty() const override              { return _AOAsShadow.isDirty(); }
    bool isAOStrengthDirty() const override              { return _AOStrength.isDirty(); }
    bool isAOSampleResolutionDirty() const override      { return _AOSampleResolution.isDirty(); }
    bool isAOLocalSampleSizeDirty() const override       { return _AOLocalSampleSize.isDirty(); }
    bool isGlobalLightingDirty() const override          { return _globalLighting.isDirty(); }
    bool isGlobalAmbientDirty() const override           { return _globalAmbient.isDirty(); }

    void setBackgroundColorDirty(bool dirty) override    { _backgroundColor.setDirty(dirty); }
    void setTFPreIntegrationDirty(bool dirty) override   { _tfPreIntegration.setDirty(dirty); }
    void setLightingDirty(bool dirty) override           { _lighting.setDirty(dirty); }
    void setLightingSideDirty(bool dirty) override       { _lightingSide.setDirty(dirty); }
    void setEmptySpaceSkippingDirty(bool dirty) override { _emptySpaceSkipping.setDirty(dirty); }
    void setAmbientOcclusionDirty(bool dirty) override   { _ambientOcclusion.setDirty(dirty); }
    void setAOAsShadowDirty(bool dirty) override         { _AOAsShadow.setDirty(dirty); }
    void setAOStrengthDirty(bool dirty) override         { _AOStrength.setDirty(dirty); }
    void setAOSampleResolutionDirty(bool dirty) override { _AOSampleResolution.setDirty(dirty); }
    void setAOLocalSampleSizeDirty(bool dirty) override  { _AOLocalSampleSize.setDirty(dirty); }
    void setGlobalLightingDirty(bool dirty) override     { _globalLighting.setDirty(dirty); }
    void setGlobalAmbientDirty(bool dirty) override      { _globalAmbient.setDirty(dirty); }

    void setAllDirty(bool dirty) override {
        _volume->setAllDirty(dirty);
        _lightSourceDirty = true;
        _backgroundColor.setDirty(dirty);
        _tfPreIntegration.setDirty(dirty);
        _lighting.setDirty(dirty);
        _lightingSide.setDirty(dirty);
        _emptySpaceSkipping.setDirty(dirty);
        _ambientOcclusion.setDirty(dirty);
        _AOAsShadow.setDirty(dirty);
        _AOStrength.setDirty(dirty);
        _AOSampleResolution.setDirty(dirty);
        _AOLocalSampleSize.setDirty(dirty);
        _globalLighting.setDirty(dirty);
        _globalAmbient.setDirty(dirty);
    }

    Property<vec4>*  backgroundColorProperty()     { return &_backgroundColor; }
    Property<bool>*  tfPreIntegrationProperty()    { return &_tfPreIntegration; }
    Property<bool>*  lightingProperty()            { return &_lighting; }
    Property<int>*   lightingSideProperty()        { return &_lightingSide; }
    Property<bool>*  emptySpaceSkippingProperty()  { return &_emptySpaceSkipping; }
    Property<bool>*  ambientOcclusionProperty()    { return &_ambientOcclusion; }
    Property<bool>*  AOAsShadowProperty()          { return &_AOAsShadow; }
    Property<float>* AOStrengthProperty()          { return &_AOStrength; }
    Property<float>* AOSampleResolutionProperty()  { return &_AOSampleResolution; }
    Property<int>*   AOLocalSampleSizeProperty()   { return &_AOLocalSampleSize; }
    Property<bool>*  globalLightingProperty()      { return &_globalLighting; }
    Property<vec4>*  globalAmbientProperty()       { return &_globalAmbient; }

    void syncFrom(RegularGridSceneGL& other);

private:
    std::shared_ptr<IRegularGridVolumeGL> _volume;

    std::shared_ptr<ICamera> _camera;

    std::shared_ptr<LightSource> _lightSource;
    bool _lightSourceDirty;

    Property<vec4>  _backgroundColor;
    Property<bool>  _tfPreIntegration;
    Property<bool>  _lighting;
    Property<int>   _lightingSide;
    Property<bool>  _emptySpaceSkipping;
    Property<bool>  _ambientOcclusion;
    Property<bool>  _AOAsShadow;
    Property<float> _AOStrength;
    Property<float> _AOSampleResolution;
    Property<int>   _AOLocalSampleSize;
    Property<bool>  _globalLighting;
    Property<vec4>  _globalAmbient;
};

inline void RegularGridSceneGL::syncFrom(RegularGridSceneGL& other) {
    setBackgroundColor(other.backgroundColor());
    setTFPreIntegration(other.isTFPreIntegrationEnabled());
    setLighting(other.isLightingEnabled());
    setEmptySpaceSkipping(other.isEmptySpaceSkippingEnabled());
    setAmbientOcclusion(other.isAmbientOcclusionEnabled());
    setAOAsShadow(other.isAOAsShadowEnabled());
    setAOStrength(other.AOStrength());
    setAOSampleResolution(other.AOSampleResolution());
    setAOLocalSampleSize(other.AOLocalSampleSize());
    setGlobalLighting(other.isGlobalLightingEnabled());
    setGlobalAmbient(other.globalAmbient());
}

} // namespace v3d

#endif // V3D_RENDERER_REGULARGRIDSCENEGL_H_
