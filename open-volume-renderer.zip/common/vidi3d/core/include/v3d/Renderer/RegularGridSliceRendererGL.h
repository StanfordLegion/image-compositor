#ifndef V3D_RENDERER_REGULARGRIDSLICERENDERERGL_H_
#define V3D_RENDERER_REGULARGRIDSLICERENDERERGL_H_

#include <memory>

#include "v3d/Renderer/SingleColorShaderGL.h"
#include "v3d/Util/GLBuffer.h"
#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/QuadGL.h"


namespace v3d {

class RegularGridSliceRendererGL {
public:
    RegularGridSliceRendererGL();

    // input
    void setQuad(const Quad<float>& quad);          // quad in the world
    void setSliceQuad(const Quad<float>& quad);     // quad in the volume
    void setModelViewProjectionMatrix(const mat4& mvpMatrix)       { _mvpMatrix = mvpMatrix; }
    void setOpacity(float opacity)                                 { _opacity = opacity; }
    void setOverlayColor(const vec4& color)                        { _overlayColor = color; }
    void setUvwTransform(const vec3& scale, const vec3& translate) { _xfScale = scale; _xfTranslate = translate; }
    void setScalarMapping(float scale, float bias)                 { _scalarScale = scale; _scalarBias = bias; }
    void setDataTexture(GLTexture3D* dataTex)                      { _dataTex = dataTex; }
    void setTransferFunctionTexture(GLTexture1D* tfTex)            { _tfTex = tfTex; }

    void setBorder(bool enabled)                                   { _borderEnabled = enabled; }
    void setBorderColor(const vec4& color)                         { _borderColor = color; }

    // in/out
    void setFramebuffer(GLFramebufferObject* fbo) { _fbo = fbo; }

    void render();

protected:
    void updateShader();
    void updateQuad();

private:
    std::unique_ptr<GLShaderProgram> _shader;
    bool _shaderDirty;

    std::unique_ptr<SingleColorShaderGL> _borderShader;

    std::unique_ptr<QuadGL> _quad;
    Quad<float> _sliceQuad;
    std::unique_ptr<GLBuffer> _sliceQuadBuffer;
    bool _quadDirty;

    mat4 _mvpMatrix;
    float _opacity;
    vec4 _overlayColor;
    vec3 _xfScale;
    vec3 _xfTranslate;
    float _scalarScale;
    float _scalarBias;

    GLTexture3D* _dataTex;
    GLTexture1D* _tfTex;

    bool _borderEnabled;
    vec4 _borderColor;

    GLFramebufferObject* _fbo;
};

} // namespace v3d

#endif // V3D_RENDERER_REGULARGRIDSLICERENDERERGL_H_
