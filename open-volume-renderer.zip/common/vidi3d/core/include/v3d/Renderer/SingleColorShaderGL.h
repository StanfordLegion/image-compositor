#ifndef V3D_RENDERER_SINGLECOLORSHADERGL_H_
#define V3D_RENDERER_SINGLECOLORSHADERGL_H_

#include <memory>

#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class SingleColorShaderGL {
public:
    SingleColorShaderGL();

    void bind();
    void release();

    void setModelViewProjectionMatrix(const mat4& matrix);
    void setColor(const vec4& color);

private:
    std::unique_ptr<GLShaderProgram> _shader;
};

} // namespace v3d

#endif // V3D_RENDERER_SINGLECOLORSHADERGL_H_
