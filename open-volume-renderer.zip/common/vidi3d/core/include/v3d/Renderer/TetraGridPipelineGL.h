#ifndef V3D_RENDERER_TETRAGRIDPIPELINEGL_H_
#define V3D_RENDERER_TETRAGRIDPIPELINEGL_H_

#include <memory>

#include "v3d/Renderer/IGeometryProperty.h"
#include "v3d/Renderer/ITetraGridSceneGL.h"
#include "v3d/Renderer/PolyRendererGL.h"
#include "v3d/Renderer/TetraGridEntryExitRendererGL.h"
#include "v3d/Renderer/TetraGridRayCasterGL.h"
#include "v3d/Renderer/TFPreIntegratorGL.h"
#include "v3d/Renderer/VolumePipelineGL.h"

#include "v3d/Util/BoxGL.h"
#include "v3d/Util/ModelGL.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/GLVertexArrayObject.h"
#include "v3d/Util/Quad.h"


namespace v3d {

class TriangleMeshGL;

////////////////////////////////////////////////////////////////////////////////

class TetraGridPipelineGL : public VolumePipelineGL {
public:
    TetraGridPipelineGL();

    void resize(int w, int h) override;
    void render() override;

    std::shared_ptr<IGeometryProperty> boundaryGeometryProperty() { return _boundaryGeometryProperty; }

    void setScene(std::shared_ptr<ITetraGridSceneGL> scn);
    void setBoundaryGeometryProperty(std::shared_ptr<IGeometryProperty> geomProperty) { _boundaryGeometryProperty = geomProperty; }

    // TODO: consider if this function is proper
    std::shared_ptr<ICamera> camera() override { return _scene->camera(); }

protected:
    void prepareGL();
    void checkFlags();
    ITetraGridSceneGL* scene()   { return _scene.get(); }
    ITetraGridVolumeGL* volume() { return _scene->volume().get(); }

private:
    std::unique_ptr<TFPreIntegratorGL> _tfPreIntegrator;
    std::unique_ptr<TetraGridEntryExitRendererGL> _entryExitRenderer;
    std::unique_ptr<TetraGridRayCasterGL> _rayCaster;
    std::unique_ptr<PolyRendererGL> _polyRenderer;
    std::unique_ptr<TriangleMeshGL> _boundaryMesh;
    std::unique_ptr<BoxGL> _boundingBox;
    std::unique_ptr<GLTexture2D> _entryPointTex;
    std::unique_ptr<GLTexture2D> _entryCellIdTex;
    std::unique_ptr<GLTexture2D> _entryDepthTex[2];     // two buffers for ping-pong rendering
    std::unique_ptr<GLTexture2D> _exitPointTex;
    std::unique_ptr<GLTexture2D> _exitDepthTex[2];      // two buffers for ping-pong rendering

    // used in TetraCellLocateRenderer
    std::unique_ptr<GLTexture2D> _interiorCellIdTex;
    std::unique_ptr<GLTexture2D> _interiorPointTex;
    std::unique_ptr<GLTexture2D> _workCellIdTex;
    std::unique_ptr<GLTexture2D> _workEntryPointTex;
    std::unique_ptr<GLTexture2D> _workDepthTex;

    std::unique_ptr<GLTexture1D> _tfTex;
    std::unique_ptr<GLTexture2D> _tfFullTex;    // pre-integrated TF
    std::unique_ptr<GLTexture2D> _tfFrontTex;   // pre-integrated TF; for lighting

    std::shared_ptr<ITetraGridSceneGL>  _scene;
    std::shared_ptr<IGeometryProperty>  _boundaryGeometryProperty;
};

////////////////////////////////////////////////////////////////////////////////

class TriangleMeshGL : public ModelGL {
public:
    TriangleMeshGL();

    void draw() const override;

    void setTriangleCount(int count) { _triangleCount = count; }
    void setVertexBuffer(GLBuffer& buffer, GLint offset = 0);
    void setNormalBuffer(GLBuffer& buffer, GLint offset = 0);
    void setIndexBuffer(GLBuffer* buffer, int triangleCount);

private:
    GLBuffer* _ibo;
    int _triangleCount;
};

} // namespace v3d

#endif // V3D_RENDERER_TETRAGRIDPIPELINEGL_H_
