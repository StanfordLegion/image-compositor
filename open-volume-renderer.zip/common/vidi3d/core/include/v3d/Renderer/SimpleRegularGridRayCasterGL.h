#ifndef V3D_RENDERER_SIMPLEREGULARGRIDRAYCASTERGL_H_
#define V3D_RENDERER_SIMPLEREGULARGRIDRAYCASTERGL_H_

#include <memory>

#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/QuadGL.h"


namespace v3d {

class SimpleRegularGridRayCasterGL {
public:
    SimpleRegularGridRayCasterGL();

    void apply();

    // input
    void setModelViewProjectionMatrix(const mat4& mvpMatrix)  { _mvpMatrix = mvpMatrix; }
    void setSampleDistance(float sampleDistance)              { _sampleDistance = sampleDistance; }
    void setOpacityUnitDistance(float opacityUnitDistance)    { _opacityUnitDistance = opacityUnitDistance; }
    void setCoordMapping(const vec3& scale, const vec3& bias) { _coordScale = scale; _coordBias = bias; }
    void setScalarMapping(float scale, float bias)            { _scalarScale = scale; _scalarBias = bias; }
    void setEntryTexture(GLTexture2D* entryTex)               { _entryTex = entryTex; }
    void setExitTexture(GLTexture2D* exitTex)                 { _exitTex = exitTex; }
    void setDataTexture(GLTexture3D* dataTex)                 { _dataTex = dataTex; }
    void setTransferFunctionTexture(GLTexture1D* tfTex)       { _tfTex = tfTex; }
    void setLighting(bool enable)                             { _lighting = enable; }
    void setLightPosition(const vec4& position)               { _lightPosition = position; }
    void setLightAmbient(const vec4& ambient)                 { _lightAmbient = ambient; }
    void setLightDiffuse(const vec4& diffuse)                 { _lightDiffuse = diffuse; }
    void setLightSpecular(const vec4& specular)               { _lightSpecular = specular; }
    void setMaterialAmbient(float ambient)                    { _materialAmbient = ambient; }
    void setMaterialDiffuse(float diffuse)                    { _materialDiffuse = diffuse; }
    void setMaterialSpecular(float specular)                  { _materialSpecular = specular; }
    void setMaterialShininess(float shininess)                { _materialShininess = shininess; }

    // output
    void setFramebuffer(GLFramebufferObject* fbo) { _fbo = fbo; }

private:
    std::unique_ptr<GLShaderProgram> _shader;
    std::unique_ptr<QuadGL> _fullScreenQuad;

    mat4 _mvpMatrix;
    float _sampleDistance;
    float _opacityUnitDistance;
    vec3 _coordScale;
    vec3 _coordBias;
    float _scalarScale;
    float _scalarBias;
    GLTexture2D* _entryTex;
    GLTexture2D* _exitTex;
    GLTexture3D* _dataTex;
    GLTexture1D* _tfTex;
    bool _lighting;
    vec4 _lightPosition;
    vec4 _lightAmbient;
    vec4 _lightDiffuse;
    vec4 _lightSpecular;
    float _materialAmbient;
    float _materialDiffuse;
    float _materialSpecular;
    float _materialShininess;

    GLFramebufferObject* _fbo;
};

} // namespace v3d

#endif // V3D_RENDERER_SIMPLEREGULARGRIDRAYCASTERGL_H_
