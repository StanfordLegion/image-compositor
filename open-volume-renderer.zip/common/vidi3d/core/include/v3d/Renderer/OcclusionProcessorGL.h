#ifndef V3D_RENDERER_OCCLUSIONPROCESSORGL_H_
#define V3D_RENDERER_OCCLUSIONPROCESSORGL_H_
#ifdef V3D_USE_OPENGL_4_3

#include <memory>

#include "v3d/Util/Box.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/Histogram.h"


// TODO: remove this. use Util/RegularOcclusionFilterGL


namespace v3d {

// TODO: merge with OcclusionModule
class OcclusionProcessorGL {
public:
    OcclusionProcessorGL();

    void setDataTexture(GLTexture3D* tex)                          { _dataTex = tex; }
    void setBoundingBox(const Box<float>& box)                     { _boundingBox = box; }
    void setUvwTransform(const vec3& scale, const vec3& translate) { _uvwXfScale = scale; _uvwXfTranslate = translate; }
    void setScalarMapping(float scale, float bias)                 { _scalarScale = scale; _scalarBias = bias; }

    // output
    void setOutputOcclusionTexture(std::shared_ptr<GLTexture3D> tex) { _occlusionTex = tex; }

    std::shared_ptr<GLTexture3D> outputOcclusionTexture() { return _occlusionTex; }

    /**
     * @brief Generates occlusion volume for occlusion spectrum classification.
     * Does nothing if input data texture is null (default).
     */
    void process();

    Histogram2D getHistogram2D();   // occlusion spectrum

protected:
    void updateShader();
    void prepareTexture();

private:
    std::unique_ptr<GLShaderProgram> _shader;

    std::shared_ptr<GLTexture3D> _occlusionTex;

    GLTexture3D* _dataTex;

    Box<float> _boundingBox;    // defines visible area of the volume
    vec3 _uvwXfScale;           // model space -> uvw space
    vec3 _uvwXfTranslate;
    float _scalarScale;
    float _scalarBias;

    // histogram generation
    std::unique_ptr<GLShaderProgram> _histogramShader;
};

} // namespace v3d

#endif // V3D_USE_OPENGL_4_3
#endif // V3D_RENDERER_OCCLUSIONPROCESSORGL_H_
