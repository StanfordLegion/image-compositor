#ifndef V3D_RENDERER_IREGULARGRIDSCENEGL_H_
#define V3D_RENDERER_IREGULARGRIDSCENEGL_H_

#include <memory>

#include "v3d/Renderer/IRegularGridVolumeGL.h"
#include "v3d/Util/ICamera.h"
#include "v3d/Util/LightSource.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class IRegularGridSceneGL {
public:
    enum LightingSide {
        FRONT_SIDE = 0,
        BACK_SIDE,
        TWO_SIDE
    };

    virtual std::shared_ptr<IRegularGridVolumeGL> volume() = 0;
    virtual std::shared_ptr<const IRegularGridVolumeGL> volume() const = 0;

    virtual std::shared_ptr<ICamera> camera() = 0;
    virtual std::shared_ptr<const ICamera> camera() const = 0;

    virtual std::shared_ptr<LightSource> lightSource() = 0;
    virtual std::shared_ptr<const LightSource> lightSource() const = 0;
    virtual bool isLightSourceDirty() const = 0;
    virtual void setLightSourceDirty(bool dirty) = 0;

    virtual vec4 backgroundColor() const = 0;
    virtual bool isLightingEnabled() const = 0;
    virtual LightingSide lightingSide() const = 0;
    virtual bool isTFPreIntegrationEnabled() const = 0;
    virtual bool isEmptySpaceSkippingEnabled() const = 0;
    virtual bool isAmbientOcclusionEnabled() const = 0;
    virtual bool isAOAsShadowEnabled() const = 0;
    virtual float AOStrength() const = 0;
    virtual float AOSampleResolution() const = 0;
    virtual int   AOLocalSampleSize() const = 0;
    virtual bool isGlobalLightingEnabled() const = 0;
    virtual vec4 globalAmbient() const = 0;

    virtual bool isBackgroundColorDirty() const = 0;
    virtual bool isTFPreIntegrationDirty() const = 0;
    virtual bool isLightingDirty() const = 0;
    virtual bool isLightingSideDirty() const = 0;
    virtual bool isEmptySpaceSkippingDirty() const = 0;
    virtual bool isAmbientOcclusionDirty() const = 0;
    virtual bool isAOAsShadowDirty() const = 0;
    virtual bool isAOStrengthDirty() const = 0;
    virtual bool isAOSampleResolutionDirty() const = 0;
    virtual bool isAOLocalSampleSizeDirty() const = 0;
    virtual bool isGlobalLightingDirty() const = 0;
    virtual bool isGlobalAmbientDirty() const = 0;

    virtual void setBackgroundColorDirty(bool dirty) = 0;
    virtual void setTFPreIntegrationDirty(bool dirty) = 0;
    virtual void setLightingDirty(bool dirty) = 0;
    virtual void setLightingSideDirty(bool dirty) = 0;
    virtual void setEmptySpaceSkippingDirty(bool dirty) = 0;
    virtual void setAmbientOcclusionDirty(bool dirty) = 0;
    virtual void setAOAsShadowDirty(bool dirty) = 0;
    virtual void setAOStrengthDirty(bool dirty) = 0;
    virtual void setAOSampleResolutionDirty(bool dirty) = 0;
    virtual void setAOLocalSampleSizeDirty(bool dirty) = 0;
    virtual void setGlobalLightingDirty(bool dirty) = 0;
    virtual void setGlobalAmbientDirty(bool dirty) = 0;

    virtual void setAllDirty(bool dirty) = 0;
};

} // namespace v3d

#endif // V3D_RENDERER_IREGULARGRIDSCENEGL_H_
