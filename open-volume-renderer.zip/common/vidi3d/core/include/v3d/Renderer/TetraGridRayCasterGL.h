#ifndef V3D_RENDERER_TETRAGRIDRAYCASTERGL_H_
#define V3D_RENDERER_TETRAGRIDRAYCASTERGL_H_

#include <memory>
#include <vector>

#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/InterpolationType.h"
#include "v3d/Util/QuadGL.h"


namespace v3d {

class TetraGridRayCasterGL {
public:
    TetraGridRayCasterGL();

    void setSamplesPerCell(int samplesPerCell)             { _samplesPerCell = samplesPerCell; }
    void setSampleDistance(float sampleDistance)           { _sampleDistance = sampleDistance; }
    void setOpacityUnitDistance(float opacityUnitDistance) { _opacityUnitDistance = opacityUnitDistance; }
    void setScalarMapping(float scale, float bias)         { _scalarScale = scale; _scalarBias = bias; }
    void setPointsTexture(GLTextureBuffer* tex)            { _pointsTex = tex; }
    void setCellsTexture(GLTextureBuffer* tex)             { _cellsTex = tex; }
    void setCellConnectionsTexture(GLTextureBuffer* tex)   { _cellConnsTex = tex; }
    void setPointDataTexture(GLTextureBuffer* tex)         { _pointDataTex = tex; }
    void setPointGradientTexture(GLTextureBuffer* tex)     { _pointGradientTex = tex; }
    void setEntryPointTexture(GLTexture2D* tex)            { _entryPointTex = tex; }
    void setEntryCellIdTexture(GLTexture2D* tex)           { _entryCellIdTex = tex; }
    void setExitPointTexture(GLTexture2D* tex)             { _exitPointTex = tex; }
    void setTransferFunctionTexture(GLTexture1D* tex)      { _tfTex = tex; }
    void setTFFullTexture(GLTexture2D* tfFullTex)          { _tfFullTex = tfFullTex; }
    void setTFFrontTexture(GLTexture2D* tfFrontTex)        { _tfFrontTex = tfFrontTex; }

    void setLightPosition(const vec4& position)            { _lightPosition[0] = position; }
    void setLightAmbient(const vec4& ambient)              { _lightAmbient[0] = ambient; }
    void setLightDiffuse(const vec4& diffuse)              { _lightDiffuse[0] = diffuse; }
    void setLightSpecular(const vec4& specular)            { _lightSpecular[0] = specular; }
    void setMaterialAmbient(float ambient)                 { _materialAmbient = ambient; }
    void setMaterialDiffuse(float diffuse)                 { _materialDiffuse = diffuse; }
    void setMaterialSpecular(float specular)               { _materialSpecular = specular; }
    void setMaterialShininess(float shininess)             { _materialShininess = shininess; }

    void setInOutFramebuffer(GLFramebufferObject* fbo) { _inOutFbo = fbo; }

    void setTFPreIntegration(bool enable);
    void setLighting(bool enable);
    void setInterpolationType(InterpolationType type);

    void setLayer(int layer) { _layer = layer; }

    void render();

protected:
    void createShader();

private:
    std::unique_ptr<GLShaderProgram> _shader;
    std::unique_ptr<QuadGL> _screenQuad;

    int _samplesPerCell;
    float _sampleDistance;      // TODO: check this
    float _opacityUnitDistance;
    float _scalarScale;
    float _scalarBias;
    GLTextureBuffer* _pointsTex;
    GLTextureBuffer* _cellsTex;
    GLTextureBuffer* _cellConnsTex;
    GLTextureBuffer* _pointDataTex;
    GLTextureBuffer* _pointGradientTex;
    GLTexture2D* _entryPointTex;
    GLTexture2D* _entryCellIdTex;
    GLTexture2D* _exitPointTex;
    GLTexture1D* _tfTex;
    GLTexture2D* _tfFullTex;
    GLTexture2D* _tfFrontTex;

    std::vector<vec4> _lightPosition;
    std::vector<vec4> _lightAmbient;
    std::vector<vec4> _lightDiffuse;
    std::vector<vec4> _lightSpecular;
    float _materialAmbient;
    float _materialDiffuse;
    float _materialSpecular;
    float _materialShininess;

    GLFramebufferObject* _inOutFbo;

    bool _tfPreIntegration;
    bool _lighting;

    InterpolationType _interpolationType;

    bool _isShaderDirty;

    // for debug
    int _layer;
};

} // namespace v3d

#endif // V3D_RENDERER_TETRAGRIDRAYCASTERGL_H_
