#ifndef V3D_RENDERER_GEOMETRYPROPERTY_H_
#define V3D_RENDERER_GEOMETRYPROPERTY_H_

#include "v3d/Renderer/IGeometryProperty.h"
#include "v3d/Util/Box.h"
#include "v3d/Util/Material.h"
#include "v3d/Util/Property.h"


namespace v3d {

class GeometryProperty : public IGeometryProperty {
public:
    GeometryProperty();

    bool       isVisible()     const override { return _visible.value(); }
    Material   frontMaterial() const override { return _frontMaterial.value(); }
    Box<float> clippingBox()   const override { return _clippingBox.value(); }

    void setVisible(bool visible)                   { _visible.setValue(visible); }
    void setFrontMaterial(const Material& material) { _frontMaterial.setValue(material); }
    void setClippingBox(const Box<float>& box)      { _clippingBox.setValue(box); }

    bool isVisibleDirty()       const override { return _visible.isDirty(); }
    bool isFrontMaterialDirty() const override { return _frontMaterial.isDirty(); }
    bool isClippingBoxDirty()   const override { return _clippingBox.isDirty(); }

    void setVisibleDirty(bool dirty)       override { _visible.setDirty(dirty); }
    void setFrontMaterialDirty(bool dirty) override { _frontMaterial.setDirty(dirty); }
    void setClippingBoxDirty(bool dirty)   override { _clippingBox.setDirty(dirty); }

    Property<bool>*       visibleProperty()       { return &_visible; }
    Property<Material>*   frontMaterialProperty() { return &_frontMaterial; }
    Property<Box<float>>* clippingBoxProperty()   { return &_clippingBox; }

private:
//    Material _frontMaterial;
//    bool _frontMaterialDirty;

    Property<bool>       _visible;
    Property<Material>   _frontMaterial;
    Property<Box<float>> _clippingBox;
};

} // namespace v3d

#endif // V3D_RENDERER_GEOMETRYPROPERTY_H_
