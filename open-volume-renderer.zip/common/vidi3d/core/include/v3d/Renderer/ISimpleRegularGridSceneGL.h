#ifndef V3D_RENDERER_ISIMPLEREGULARGRIDSCENEGL_H_
#define V3D_RENDERER_ISIMPLEREGULARGRIDSCENEGL_H_

#include <memory>

#include "v3d/Renderer/IRegularGridVolumeGL.h"
#include "v3d/Util/ICamera.h"
#include "v3d/Util/LightSource.h"


namespace v3d {

class ISimpleRegularGridSceneGL {
public:
    virtual std::shared_ptr<IRegularGridVolumeGL> volume() = 0;
    virtual std::shared_ptr<const IRegularGridVolumeGL> volume() const = 0;

    virtual std::shared_ptr<ICamera> camera() = 0;
    virtual std::shared_ptr<const ICamera> camera() const = 0;

    virtual std::shared_ptr<LightSource> lightSource() = 0;
    virtual std::shared_ptr<const LightSource> lightSource() const = 0;
    virtual bool isLightSourceDirty() const = 0;
    virtual void setLightSourceDirty(bool dirty) = 0;

    virtual bool isLightingEnabled() const = 0;
    virtual bool isLightingDirty() const = 0;
    virtual void setLightingDirty(bool dirty) = 0;
};

} // namespace v3d

#endif // V3D_RENDERER_ISIMPLEREGULARGRIDSCENEGL_H_
