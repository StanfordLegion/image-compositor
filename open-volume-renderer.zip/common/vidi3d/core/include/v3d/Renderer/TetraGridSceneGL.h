#ifndef V3D_RENDERER_TETRAGRIDSCENEGL_H_
#define V3D_RENDERER_TETRAGRIDSCENEGL_H_

#include "v3d/Renderer/ITetraGridSceneGL.h"
#include "v3d/Util/Property.h"


namespace v3d {

class TetraGridSceneGL : public ITetraGridSceneGL {
public:
    TetraGridSceneGL()
        : _lightSource(std::make_shared<LightSource>())
        , _lightSourceDirty(true)
        , _backgroundColor(vec4(0.0f, 0.0f, 0.0f, 0.0f))
        , _tfPreIntegration(false)
        , _lighting(false) {
    }
    virtual ~TetraGridSceneGL() {}

    std::shared_ptr<ITetraGridVolumeGL> volume() override             { return _volume; }
    std::shared_ptr<const ITetraGridVolumeGL> volume() const override { return _volume; }
    void setVolume(std::shared_ptr<ITetraGridVolumeGL> vol)           { _volume = vol; }

    std::shared_ptr<ICamera> camera() override                      { return _camera; }
    std::shared_ptr<const ICamera> camera() const override          { return _camera; }
    void setCamera(std::shared_ptr<ICamera> cam)                    { _camera = cam; }

    std::shared_ptr<LightSource> lightSource() override             { return _lightSource; }
    std::shared_ptr<const LightSource> lightSource() const override { return _lightSource; }
    void setLightSource(std::shared_ptr<LightSource> lightSrc) { _lightSource = lightSrc; }
    bool isLightSourceDirty() const override                   { return _lightSourceDirty; }
    void setLightSourceDirty(bool dirty) override              { _lightSourceDirty = dirty; }

    vec4 backgroundColor() const override              { return _backgroundColor.value(); }
    bool isTFPreIntegrationEnabled() const override    { return _tfPreIntegration.value(); }
    bool isLightingEnabled() const override            { return _lighting.value(); }

    // TODO: implement these
    LightingSide lightingSide() const override { return FRONT_SIDE; }
    vec4 globalAmbient() const override { return vec4(0.0f); }

    void setBackgroundColor(const vec4& color)         { _backgroundColor.setValue(color); }
    void setTFPreIntegration(bool enable)              { _tfPreIntegration.setValue(enable); }
    void setLighting(bool enable)                      { _lighting.setValue(enable); }

    // TODO: implement these
    void setLightingSide(LightingSide /*lightSide*/) {}
    void setGlobalAmbient(const vec4& /*globalAmbient*/) {}

    bool isBackgroundColorDirty() const override        { return _backgroundColor.isDirty(); }
    bool isTFPreIntegrationDirty() const override       { return _tfPreIntegration.isDirty(); }
    bool isLightingDirty() const override               { return _lighting.isDirty(); }

    // TODO: implement these
    bool isLightingSideDirty() const override { return false; }
    bool isGlobalAmbientDirty() const override { return false; }

    void setBackgroundColorDirty(bool dirty) override        { _backgroundColor.setDirty(dirty); }
    void setTFPreIntegrationDirty(bool dirty) override       { _tfPreIntegration.setDirty(dirty); }
    void setLightingDirty(bool dirty) override               { _lighting.setDirty(dirty); }

    // TODO: implement these
    void setLightingSideDirty(bool /*dirty*/) override {}
    void setGlobalAmbientDirty(bool /*dirty*/) override {}

    Property<vec4>*  backgroundColorProperty()     { return &_backgroundColor; }
    Property<bool>*  tfPreIntegrationProperty()    { return &_tfPreIntegration; }
    Property<bool>*  lightingProperty()            { return &_lighting; }

private:
    std::shared_ptr<ITetraGridVolumeGL> _volume;

    std::shared_ptr<ICamera> _camera;

    std::shared_ptr<LightSource> _lightSource;
    bool _lightSourceDirty;

    Property<vec4>  _backgroundColor;
    Property<bool>  _tfPreIntegration;
    Property<bool>  _lighting;
};

} // namespace v3d

#endif // V3D_RENDERER_TETRAGRIDSCENEGL_H_
