#ifndef V3D_RENDERER_IGEOMETRYPROPERTY_H_
#define V3D_RENDERER_IGEOMETRYPROPERTY_H_

#include "v3d/Util/Box.h"
#include "v3d/Util/Material.h"


namespace v3d {

class IGeometryProperty {
public:
    virtual bool isVisible() const = 0;
    virtual Material frontMaterial() const = 0;
    virtual Box<float> clippingBox() const = 0;

    virtual bool isVisibleDirty() const = 0;
    virtual bool isFrontMaterialDirty() const = 0;
    virtual bool isClippingBoxDirty() const = 0;

    virtual void setVisibleDirty(bool dirty) = 0;
    virtual void setFrontMaterialDirty(bool dirty) = 0;
    virtual void setClippingBoxDirty(bool dirty) = 0;
};

} // namespace v3d

#endif // V3D_RENDERER_IGEOMETRYPROPERTY_H_
