#ifndef V3D_RENDERER_REGULARGRIDPIPELINEGL_H_
#define V3D_RENDERER_REGULARGRIDPIPELINEGL_H_

#include <memory>

#include "v3d/Renderer/BoxRendererGL.h"
#include "v3d/Renderer/EntryExitRendererGL.h"
#include "v3d/Renderer/FramebufferGL.h"
#include "v3d/Renderer/ImageRendererGL.h"
#include "v3d/Renderer/IRegularGridSceneGL.h"
//#include "v3d/Renderer/PolyRendererGL.h"
#include "v3d/Renderer/RegularGridRayCasterGL.h"
#include "v3d/Renderer/RegularGridSliceRendererGL.h"
#include "v3d/Renderer/TFPreIntegratorGL.h"
#include "v3d/Renderer/VolumePipelineGL.h"
#include "v3d/Util/BoxGL.h"
#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLTexture.h"

//#define V3D_USE_OPENGL_4_3

#ifdef V3D_USE_OPENGL_4_3
#include "v3d/Renderer/Advanced/OcclusionModule.h"
#include "v3d/Renderer/SimpleEmptySpaceSkipping.h"
//#include "v3d/Renderer/OcclusionProcessorGL.h"
#include "v3d/Renderer/Advanced/ConvectDiffuseIlluminatorGL.h"
#endif


namespace v3d {

class RegularGridPipelineGL : public VolumePipelineGL {
public:
    RegularGridPipelineGL();

    void resize(int w, int h) override;
    void render() override;

    void setScene(std::shared_ptr<IRegularGridSceneGL> scn);

    // TODO: consider if this function is proper
    std::shared_ptr<ICamera> camera() override { return _scene->camera(); }

    // TODO: remove this
//    std::shared_ptr<Histogram2D> histogram2D() { return _occlusionHistogram; }

protected:
    void checkFlags();
    void renderVolume(const mat4& mvpMatrix);
    void renderVolumeBricks(const mat4& mvpMatrix);
    void renderSlices(const mat4& mvpMatrix, const vec3& uvwXfScale, const vec3& uvwXfTranslate, float scalarScale, float scalarBias);
    void getCoordMapping(vec3& coordScale, vec3& coordBias);        // TODO: -> getTransform
    void getScalarMapping(float& scalarScale, float& scalarBias);
    void updateOTFTexture();
    void updateBrickBoxes();
    IRegularGridSceneGL* scene() { return _scene.get(); }
    IRegularGridVolumeGL* volume() { return _scene->volume().get(); }

private:
    std::unique_ptr<TFPreIntegratorGL> _tfPreIntegrator;
    std::unique_ptr<EntryExitRendererGL> _entryExitRenderer;
    std::unique_ptr<RegularGridRayCasterGL> _rayCaster;
    std::unique_ptr<BoxRendererGL> _boxRenderer;
    std::unique_ptr<RegularGridSliceRendererGL> _sliceRenderer[3];  // x-, y-, z-slice
//    std::unique_ptr<PolyRendererGL> _polyRenderer;  // renders light bulbs
    std::unique_ptr<ImageRendererGL> _imageRenderer;
    std::unique_ptr<FramebufferGL> _framebuffer;
    std::unique_ptr<GLFramebufferObject> _entryFbo;
    std::unique_ptr<GLFramebufferObject> _exitFbo;
    std::unique_ptr<GLTexture2D> _entryTex;
    std::unique_ptr<GLTexture2D> _exitTex;
    std::unique_ptr<GLTexture2D> _entryDepthTex;
    std::unique_ptr<GLTexture2D> _exitDepthTex;
    std::unique_ptr<GLTexture1D> _tfTex;

    std::unique_ptr<GLTexture2D> _tfFullTex;    // pre-integrated TF
    std::unique_ptr<GLTexture2D> _tfFrontTex;   // pre-integrated TF; for lighting

    std::unique_ptr<GLTexture2D> _otfTex;

    std::shared_ptr<IRegularGridSceneGL> _scene;

    std::shared_ptr<BoxGL> _boundingBox;            // TODO: move this to RegularGridVolumeGL?
    std::shared_ptr<BoxGL> _clippingBox;

#ifdef V3D_USE_OPENGL_4_3
    std::unique_ptr<SimpleEmptySpaceSkippingModule> _spaceSkipModule;
    std::unique_ptr<OcclusionModule> _occlusionModule;

    // TODO: remove this
//    std::unique_ptr<OcclusionProcessorGL> _occlusionProcessor;

    std::unique_ptr<ConvectDiffuseIlluminatorGL> _cdIlluminator;
#endif

    // TODO: move it to somewhere else
//    std::shared_ptr<Histogram2D> _occlusionHistogram;

    // in-core bricking; an important optimization for improving cache performance
    bool _bricking = true;
//    bool _bricking = false;
    size_t _maxBrickSize = 512 * 512 * 256;     // maximum size of each brick; this number is good with Titan X
    std::vector<std::shared_ptr<BoxGL>> _brickBoxes;
};

} // namespace v3d

#endif // V3D_RENDERER_REGULARGRIDPIPELINEGL_H_
