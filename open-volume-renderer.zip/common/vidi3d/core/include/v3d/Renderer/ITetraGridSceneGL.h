#ifndef V3D_RENDERER_ITETRAGRIDSCENEGL_H_
#define V3D_RENDERER_ITETRAGRIDSCENEGL_H_

#include <memory>

#include "v3d/Renderer/ITetraGridVolumeGL.h"
#include "v3d/Util/ICamera.h"
#include "v3d/Util/LightSource.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class ITetraGridSceneGL {
public:
    enum LightingSide {
        FRONT_SIDE = 0,
        BACK_SIDE,
        TWO_SIDE
    };

    virtual std::shared_ptr<ITetraGridVolumeGL> volume() = 0;
    virtual std::shared_ptr<const ITetraGridVolumeGL> volume() const = 0;

    virtual std::shared_ptr<ICamera> camera() = 0;
    virtual std::shared_ptr<const ICamera> camera() const = 0;

    virtual std::shared_ptr<LightSource> lightSource() = 0;
    virtual std::shared_ptr<const LightSource> lightSource() const = 0;
    virtual bool isLightSourceDirty() const = 0;
    virtual void setLightSourceDirty(bool dirty) = 0;

    virtual vec4 backgroundColor() const = 0;
    virtual bool isTFPreIntegrationEnabled() const = 0;
    virtual bool isLightingEnabled() const = 0;
    virtual LightingSide lightingSide() const = 0;
    virtual vec4 globalAmbient() const = 0;

    virtual bool isBackgroundColorDirty() const = 0;
    virtual bool isTFPreIntegrationDirty() const = 0;
    virtual bool isLightingDirty() const = 0;
    virtual bool isLightingSideDirty() const = 0;
    virtual bool isGlobalAmbientDirty() const = 0;

    virtual void setBackgroundColorDirty(bool dirty) = 0;
    virtual void setTFPreIntegrationDirty(bool dirty) = 0;
    virtual void setLightingDirty(bool dirty) = 0;
    virtual void setLightingSideDirty(bool dirty) = 0;
    virtual void setGlobalAmbientDirty(bool dirty) = 0;
};

} // namespace v3d

#endif // V3D_RENDERER_ITETRAGRIDSCENEGL_H_
