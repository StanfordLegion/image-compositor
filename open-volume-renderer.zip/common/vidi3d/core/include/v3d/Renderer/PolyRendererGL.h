#ifndef V3D_RENDERER_POLYRENDERERGL_H_
#define V3D_RENDERER_POLYRENDERERGL_H_

#include <vector>

#include "v3d/Util/Box.h"
#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/LightSource.h"
#include "v3d/Util/Material.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/ModelGL.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class PolyRendererGL {
public:
    PolyRendererGL();

    void setModelViewProjectionMatrix(const mat4& matrix) { _mvpMatrix = matrix; }
    void setModelViewMatrix(const mat4& matrix)           { _mvMatrix = matrix; }
    void setNormalMatrix(const mat3& matrix)              { _normalMatrix = matrix; }
    void setColor(const vec4& color)                      { _color = color; }
    void setClippingBox(const Box<float>& box)            { _clippingBox = box; }
    void setFrontMaterial(const Material& material)       { _frontMaterial = material; }
    void setLightSource(const LightSource& lightSrc)      { _lightSources[0] = lightSrc; }
    void setFrontDepthFunction(GLenum depthFunc)          { _frontDepthFunc = depthFunc; }
    void setClipping(bool enable);
    void setFrontDepthTest(bool enable);
    void setModel(ModelGL* model)                         { _model = model; }
    void setFrontDepthTexture(GLTexture2D* tex)           { _frontDepthTex = tex; }
    void setInOutFramebuffer(GLFramebufferObject* fbo)    { _fbo = fbo; }

    void render();

protected:
    void createShader();

private:
    std::unique_ptr<GLShaderProgram> _shader;
    bool _shaderDirty;

    mat4 _mvpMatrix;
    mat4 _mvMatrix;
    mat3 _normalMatrix;
    vec4 _color;
    Box<float> _clippingBox;
    std::vector<LightSource> _lightSources;
    Material _frontMaterial;
    GLenum _frontDepthFunc;

    bool _clipping;
    bool _frontDepthTest;

    ModelGL* _model;
    GLTexture2D* _frontDepthTex;
    GLFramebufferObject* _fbo;
};

} // namespace v3d

#endif // V3D_RENDERER_POLYRENDERERGL_H_
