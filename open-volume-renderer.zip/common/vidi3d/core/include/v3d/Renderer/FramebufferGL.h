#ifndef V3D_RENDERER_FRAMEBUFFERGL_H_
#define V3D_RENDERER_FRAMEBUFFERGL_H_

#include <memory>

#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLTexture.h"

namespace v3d {

class FramebufferGL {
public:
    FramebufferGL(int w, int h);

    int width() const { return _width; }
    int height() const { return _height; }

    void resize(int w, int h);

    void bind();
    void release();

    GLFramebufferObject* framebufferObject() { return _fbo.get(); }
    GLTexture2D*         colorTexture() { return _colorTex.get(); }
    GLTexture2D*         depthTexture() { return _depthTex.get(); }

    std::shared_ptr<GLFramebufferObject> sharedFramebufferObject()
    {
        return _fbo;
    }

private:
    int _width;
    int _height;

    std::shared_ptr<GLFramebufferObject> _fbo;
    std::shared_ptr<GLTexture2D>         _colorTex;
    std::shared_ptr<GLTexture2D>         _depthTex;
};

} // namespace v3d

#endif // V3D_RENDERER_FRAMEBUFFERGL_H_
