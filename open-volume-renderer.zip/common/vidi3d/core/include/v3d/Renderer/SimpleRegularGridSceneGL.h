#ifndef V3D_RENDERER_SIMPLEREGULARGRIDSCENEGL_H_
#define V3D_RENDERER_SIMPLEREGULARGRIDSCENEGL_H_

#include "v3d/Renderer/ISimpleRegularGridSceneGL.h"
#include "v3d/Util/Property.h"


namespace v3d {

class SimpleRegularGridSceneGL : public ISimpleRegularGridSceneGL {
public:
    SimpleRegularGridSceneGL()
        : _lightSource(std::make_shared<LightSource>())
        , _lightSourceDirty(true)
        , _lighting(false) {
    }
    virtual ~SimpleRegularGridSceneGL() {}

    std::shared_ptr<IRegularGridVolumeGL> volume() override             { return _volume; }
    std::shared_ptr<const IRegularGridVolumeGL> volume() const override { return _volume; }
    void setVolume(std::shared_ptr<IRegularGridVolumeGL> vol)           { _volume = vol; }

    std::shared_ptr<ICamera> camera() override                      { return _camera; }
    std::shared_ptr<const ICamera> camera() const override          { return _camera; }
    void setCamera(std::shared_ptr<ICamera> cam)                    { _camera = cam; }

    std::shared_ptr<LightSource> lightSource() override             { return _lightSource; }
    std::shared_ptr<const LightSource> lightSource() const override { return _lightSource; }
    void setLightSource(std::shared_ptr<LightSource> lightSrc)      { _lightSource = lightSrc; }
    bool isLightSourceDirty() const override                        { return _lightSourceDirty; }
    void setLightSourceDirty(bool dirty) override                   { _lightSourceDirty = dirty; }

    bool isLightingEnabled() const override    { return _lighting.value(); }
    void setLighting(bool enable)              { _lighting.setValue(enable); }
    bool isLightingDirty() const override      { return _lighting.isDirty(); }
    void setLightingDirty(bool dirty) override { _lighting.setDirty(dirty); }
    Property<bool>* lightingProperty()         { return &_lighting; }

private:
    std::shared_ptr<IRegularGridVolumeGL> _volume;

    std::shared_ptr<ICamera> _camera;

    std::shared_ptr<LightSource> _lightSource;
    bool _lightSourceDirty;

    Property<bool> _lighting;
};

} // namespace v3d

#endif // V3D_RENDERER_SIMPLEREGULARGRIDSCENEGL_H_
