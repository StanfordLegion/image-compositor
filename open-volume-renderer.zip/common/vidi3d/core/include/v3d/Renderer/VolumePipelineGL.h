#ifndef V3D_RENDERER_VOLUMEPIPELINEGL_H_
#define V3D_RENDERER_VOLUMEPIPELINEGL_H_

#include <memory>

#include "v3d/Renderer/IRendererGL.h"
//#include "v3d/Renderer/IVolumeProperty.h"
#include "v3d/Util/GLConfig.h"
#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/ICamera.h"
#include "v3d/Util/LightSource.h"


namespace v3d {

/**
 * @brief The VolumePipelineGL class
 *
 * Base class inherited by pipeline classes.
 */
class VolumePipelineGL : public IRendererGL {
public:
    VolumePipelineGL();
    virtual ~VolumePipelineGL() {}

    void setFramebufferObject(std::shared_ptr<GLFramebufferObject> fbo) override { _fbo = fbo; }

    int width() const override  { return _width; }
    int height() const override { return _height; }
    void resize(int w, int h) override;

    std::shared_ptr<GLFramebufferObject> framebufferObject() { return _fbo; }

    virtual std::shared_ptr<ICamera> camera() = 0; // { return _camera; }

    // TODO: remove deprecated members
    std::shared_ptr<LightSource> lightSource()        { return _lightSource; }
//    std::shared_ptr<IVolumeProperty> volumeProperty() { return _volumeProperty; }

//    void setCamera(std::shared_ptr<ICamera> cam);
    void setLightSource(std::shared_ptr<LightSource> light)          { _lightSource = light; }
//    void setVolumeProperty(std::shared_ptr<IVolumeProperty> volProp) { _volumeProperty = volProp; }

private:
    std::shared_ptr<GLFramebufferObject> _fbo;
    int _width;
    int _height;
//    std::shared_ptr<ICamera> _camera;
    std::shared_ptr<LightSource> _lightSource;
//    std::shared_ptr<IVolumeProperty> _volumeProperty;
};

} // namespace v3d

#endif // V3D_RENDERER_VOLUMEPIPELINEGL_H_
