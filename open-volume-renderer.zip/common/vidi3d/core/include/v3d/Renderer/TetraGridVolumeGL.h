#ifndef V3D_RENDERER_TETRAGRIDVOLUMEGL_H_
#define V3D_RENDERER_TETRAGRIDVOLUMEGL_H_

#include <memory>

#include "v3d/Data/TetraGridDataGL.h"
#include "v3d/Renderer/ITetraGridVolumeGL.h"
#include "v3d/Util/Property.h"


namespace v3d {

class TetraGridVolumeGL : public ITetraGridVolumeGL {
public:
    TetraGridVolumeGL();
    virtual ~TetraGridVolumeGL() {}

    GLBuffer* pointsBuffer() override;
    GLBuffer* cellsBuffer() override;
    GLBuffer* cellConnectionsBuffer() override;
    GLBuffer* boundaryTrianglesBuffer() override;
    GLBuffer* boundaryCellIdsBuffer() override;
    GLBuffer* boundaryVerticesBuffer() override;
    GLTextureBuffer* pointsTexture() override;
    GLTextureBuffer* cellsTexture() override;
    GLTextureBuffer* cellConnectionsTexture() override;
    GLTextureBuffer* pointDataTexture() override;
    GLTextureBuffer* pointGradientTexture() override;
    GLTextureBuffer* boundaryCellIdsTexture() override;
    int boundaryTriangleCount() const override { return _data->grid()->boundaryMesh()->triangleCount(); }
    int boundaryVertexCount() const override { return _data->grid()->boundaryMesh()->vertexCount(); }
    Box<float> boundingBox() const override { return _boundingBox; }

    bool isDataDirty() const override      { return _dataDirty; }
    void setDataDirty(bool dirty) override { _dataDirty = dirty; }

    void setData(std::shared_ptr<TetraGridDataGL> data) { _data = data; }
    void setBoundingBox(const Box<float>& box) { _boundingBox = box; }

    bool  isVisible() const override                   { return _visible.value(); }
    int samplesPerCell() const override                { return _samplesPerCell.value(); }

    // TODO: check if this is required
    float sampleDistance() const override              { return _sampleDistance.value(); }

    InterpolationType interpolationType() const override { return InterpolationType(_interpolationType.value()); }
    dvec2 scalarMappingRange() const override          { return _scalarMappingRange.value(); }
    float opacityUnitDistance() const override         { return _opacityUnitDistance.value(); }
    float ambient() const override                     { return _ambient.value(); }
    float diffuse() const override                     { return _diffuse.value(); }
    float specular() const override                    { return _specular.value(); }
    float shininess() const override                   { return _shininess.value(); }

    void setVisible(bool visible)                      { _visible.setValue(visible); }
    void setSamplesPerCell(int samples)                { _samplesPerCell.setValue(samples); }
    void setSampleDistance(float sampleDistance)       { _sampleDistance.setValue(sampleDistance); }
    void setInterpolationType(InterpolationType type)  { _interpolationType.setValue(int(type)); }
    void setScalarMappingRange(const dvec2& range)     { _scalarMappingRange.setValue(range); }
    void setOpacityUnitDistance(float opcUnitDistance) { _opacityUnitDistance.setValue(opcUnitDistance); }
    void setAmbient(float ambient)                     { _ambient.setValue(ambient); }
    void setDiffuse(float diffuse)                     { _diffuse.setValue(diffuse); }
    void setSpecular(float specular)                   { _specular.setValue(specular); }
    void setShininess(float shininess)                 { _shininess.setValue(shininess); }

    bool isVisibleDirty() const override                { return _visible.isDirty(); }
    bool isSamplesPerCellDirty() const override         { return _samplesPerCell.isDirty(); }
    bool isSampleDistanceDirty() const override         { return _sampleDistance.isDirty(); }
    bool isInterpolationTypeDirty() const override      { return _interpolationType.isDirty(); }
    bool isScalarMappingRangeDirty() const override     { return _scalarMappingRange.isDirty(); }
    bool isOpacityUnitDistanceDirty() const override    { return _opacityUnitDistance.isDirty(); }
    bool isAmbientDirty() const override                { return _ambient.isDirty(); }
    bool isDiffuseDirty() const override                { return _diffuse.isDirty(); }
    bool isSpecularDirty() const override               { return _specular.isDirty(); }
    bool isShininessDirty() const override              { return _shininess.isDirty(); }

    void setVisibleDirty(bool dirty) override                { _visible.setDirty(dirty); }
    void setSamplesPerCellDirty(bool dirty) override         { _samplesPerCell.setDirty(dirty); }
    void setSampleDistanceDirty(bool dirty) override         { _sampleDistance.setDirty(dirty); }
    void setInterpolationTypeDirty(bool dirty) override      { _interpolationType.setDirty(dirty); }
    void setScalarMappingRangeDirty(bool dirty) override     { _scalarMappingRange.setDirty(dirty); }
    void setOpacityUnitDistanceDirty(bool dirty) override    { _opacityUnitDistance.setDirty(dirty); }
    void setAmbientDirty(bool dirty) override                { _ambient.setDirty(dirty); }
    void setDiffuseDirty(bool dirty) override                { _diffuse.setDirty(dirty); }
    void setSpecularDirty(bool dirty) override               { _specular.setDirty(dirty); }
    void setShininessDirty(bool dirty) override              { _shininess.setDirty(dirty); }

    std::shared_ptr<ILookupTable<vec4>> transferFunction() override { return _tf; }
    virtual void setTransferFunction(std::shared_ptr<ILookupTable<vec4>> tf) { _tf = tf; }
    bool isTransferFunctionDirty() const override       { return _isTFDirty; }
    bool isTransferFunctionDirtyCoarse() const override { return _isTFDirtyCoarse; }
    void setTransferFunctionDirty(bool dirty) override       { _isTFDirty = dirty; }
    void setTransferFunctionDirtyCoarse(bool dirty) override { _isTFDirtyCoarse = dirty; }

    Property<bool>*  visibleProperty()             { return &_visible; }
    Property<int>*   samplesPerCellProperty()      { return &_samplesPerCell; }
    Property<float>* sampleDistanceProperty()      { return &_sampleDistance; }
    Property<int>*   interpolationTypeProperty()   { return &_interpolationType; }
    Property<dvec2>* scalarMappingRangeProperty()  { return &_scalarMappingRange; }
    Property<float>* opacityUnitDistanceProperty() { return &_opacityUnitDistance; }
    Property<float>* ambientProperty()             { return &_ambient; }
    Property<float>* diffuseProperty()             { return &_diffuse; }
    Property<float>* specularProperty()            { return &_specular; }
    Property<float>* shininessProperty()           { return &_shininess; }

private:
    std::shared_ptr<TetraGridDataGL> _data;
    Box<float> _boundingBox;

    bool _dataDirty;

    std::shared_ptr<ILookupTable<vec4>> _tf;
    bool _isTFDirty;
    bool _isTFDirtyCoarse;

    Property<bool>  _visible;
    Property<int>   _samplesPerCell;
    Property<float> _sampleDistance;
    Property<int>   _interpolationType;
    Property<dvec2> _scalarMappingRange;
    Property<float> _opacityUnitDistance;
    Property<float> _ambient;
    Property<float> _diffuse;
    Property<float> _specular;
    Property<float> _shininess;
};

} // namespace v3d

#endif // V3D_RENDERER_TETRAGRIDVOLUMEGL_H_
