#ifndef V3D_RENDERER_ITETRAGRIDVOLUMEGL_H_
#define V3D_RENDERER_ITETRAGRIDVOLUMEGL_H_

#include "v3d/Util/Box.h"
#include "v3d/Util/GLBuffer.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/InterpolationType.h"
//#include "v3d/Util/IRgbaFunction.h"
#include "v3d/Util/ILookupTable.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class ITetraGridVolumeGL {
public:
    virtual GLBuffer* pointsBuffer() = 0;
    virtual GLBuffer* cellsBuffer() = 0;
    virtual GLBuffer* cellConnectionsBuffer() = 0;
    virtual GLBuffer* boundaryTrianglesBuffer() = 0;
    virtual GLBuffer* boundaryCellIdsBuffer() = 0;
    virtual GLBuffer* boundaryVerticesBuffer() = 0;
    virtual GLTextureBuffer* pointsTexture() = 0;
    virtual GLTextureBuffer* cellsTexture() = 0;
    virtual GLTextureBuffer* cellConnectionsTexture() = 0;
    virtual GLTextureBuffer* pointDataTexture() = 0;
    virtual GLTextureBuffer* pointGradientTexture() = 0;
    virtual GLTextureBuffer* boundaryCellIdsTexture() = 0;
    virtual int boundaryTriangleCount() const = 0;
    virtual int boundaryVertexCount() const = 0;
    virtual Box<float> boundingBox() const = 0;

    virtual bool isDataDirty() const = 0;
    virtual void setDataDirty(bool dirty) = 0;

    virtual bool isVisible() const = 0;
    virtual int samplesPerCell() const = 0;
    virtual float sampleDistance() const = 0;
    virtual InterpolationType interpolationType() const = 0;
    virtual dvec2 scalarMappingRange() const = 0;
    virtual float opacityUnitDistance() const = 0;
    virtual float ambient() const = 0;
    virtual float diffuse() const = 0;
    virtual float specular() const = 0;
    virtual float shininess() const = 0;

    virtual bool isVisibleDirty() const = 0;
    virtual bool isSamplesPerCellDirty() const = 0;
    virtual bool isSampleDistanceDirty() const = 0;
    virtual bool isInterpolationTypeDirty() const = 0;
    virtual bool isScalarMappingRangeDirty() const = 0;
    virtual bool isOpacityUnitDistanceDirty() const = 0;
    virtual bool isAmbientDirty() const = 0;
    virtual bool isDiffuseDirty() const = 0;
    virtual bool isSpecularDirty() const = 0;
    virtual bool isShininessDirty() const = 0;

    virtual void setVisibleDirty(bool dirty) = 0;
    virtual void setSamplesPerCellDirty(bool dirty) = 0;
    virtual void setSampleDistanceDirty(bool dirty) = 0;
    virtual void setInterpolationTypeDirty(bool dirty) = 0;
    virtual void setScalarMappingRangeDirty(bool dirty) = 0;
    virtual void setOpacityUnitDistanceDirty(bool dirty) = 0;
    virtual void setAmbientDirty(bool dirty) = 0;
    virtual void setDiffuseDirty(bool dirty) = 0;
    virtual void setSpecularDirty(bool dirty) = 0;
    virtual void setShininessDirty(bool dirty) = 0;

    virtual std::shared_ptr<ILookupTable<vec4>> transferFunction() = 0;
    virtual bool isTransferFunctionDirty() const = 0;
    virtual bool isTransferFunctionDirtyCoarse() const = 0;
    virtual void setTransferFunctionDirty(bool dirty) = 0;
    virtual void setTransferFunctionDirtyCoarse(bool dirty) = 0;
};

} // namespace v3d

#endif // V3D_RENDERER_ITETRAGRIDVOLUMEGL_H_
