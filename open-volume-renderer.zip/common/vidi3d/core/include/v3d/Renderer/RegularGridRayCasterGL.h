#ifndef V3D_RENDERER_REGULARGRIDRAYCASTERGL_H_
#define V3D_RENDERER_REGULARGRIDRAYCASTERGL_H_

#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/QuadGL.h"
#include <memory>
#include <string>

namespace v3d {

class RegularGridRayCasterGL {
public:
    enum LightingSide {
        FRONT_SIDE = 0,
        BACK_SIDE,
        TWO_SIDE
    };

public:
    RegularGridRayCasterGL();

    // input
    void setModelViewProjectionMatrix(const mat4& mvpMatrix)  { _mvpMatrix = mvpMatrix; }
    void setSampleDistance(float sampleDistance)              { _sampleDistance = sampleDistance; }
    void setOpacityUnitDistance(float opacityUnitDistance)    { _opacityUnitDistance = opacityUnitDistance; }
    void setCoordMapping(const vec3& scale, const vec3& bias) { _coordScale = scale; _coordBias = bias; }
    void setGridSpacing(const vec3& spacing)                  { _gridSpacing = spacing; }
    void setScalarMapping(float scale, float bias)            { _scalarScale = scale; _scalarBias = bias; }
    void setEntryTexture(GLTexture2D* entryTex)               { _entryTex = entryTex; }
    void setExitTexture(GLTexture2D* exitTex)                 { _exitTex = exitTex; }
    void setDataTexture(GLTexture3D* dataTex)                 { _dataTex = dataTex; }
    void setTransferFunctionTexture(GLTexture1D* tfTex)       { _tfTex = tfTex; }
    void setTFFullTexture(GLTexture2D* tfFullTex)             { _tfFullTex = tfFullTex; }
    void setTFFrontTexture(GLTexture2D* tfFrontTex)           { _tfFrontTex = tfFrontTex; }
    void setLightPosition(const vec4& position)               { _lightPosition = position; }
    void setLightAmbient(const vec4& ambient)                 { _lightAmbient = ambient; }
    void setLightDiffuse(const vec4& diffuse)                 { _lightDiffuse = diffuse; }
    void setLightSpecular(const vec4& specular)               { _lightSpecular = specular; }
    void setMaterialAmbient(float ambient)                    { _materialAmbient = ambient; }
    void setMaterialDiffuse(float diffuse)                    { _materialDiffuse = diffuse; }
    void setMaterialSpecular(float specular)                  { _materialSpecular = specular; }
    void setMaterialShininess(float shininess)                { _materialShininess = shininess; }

#ifdef V3D_USE_OPENGL_4_3
    void setEmptySpaceTexture(GLTexture3D* emptySpaceTex)     { _emptySpaceTex = emptySpaceTex; }
    void setEmptySpaceSkipping(bool enable);
    void setAmbientOcclusionTexture(GLTexture3D* ambOcclusionTex) { _ambOcclusionTex = ambOcclusionTex; }
    void setAmbientOcclusionEnabled(bool enable);
    void setAOAsShadowEnabled(bool enable);
    void setAOStrength(float strength)                        { _AOStrength = strength; }
#endif

    void setTricubicInterpolation(bool enabled);

    void setTFPreIntegrationEnabled(bool enable);
    void setLighting(bool enable);
    void setLightingSide(LightingSide lightSide);
    void setGlobalLighting(bool enabled);
    void setGlobalAmbient(const vec4& color)                  { _globalAmbient = color; }

    // 2D TF
    void setSecondaryDataTexture(GLTexture3D* tex)      { _secondDataTex = tex; }
    void setTransferFunction2DTexture(GLTexture2D* tex) { _tf2dTex = tex; }
    void setTransferFunction2DEnabled(bool enabled);
    void setSecondaryScalarMapping(float scale, float bias) { _secondScalarScale = scale, _secondScalarBias = bias; }

    // global lighting
    void setLightVolumeTexture(GLTexture3D* tex) { _lightTex = tex; }

    void setBricking(bool enabled);

    // output
    void setFramebuffer(GLFramebufferObject* fbo) { _fbo = fbo; }

    void render();

protected:
    void updateShader();

private:
    std::unique_ptr<GLShaderProgram> _shader;
    bool _shaderDirty;

    std::unique_ptr<QuadGL> _fullScreenQuad;

    mat4 _mvpMatrix;
    float _sampleDistance;
    float _opacityUnitDistance;
    vec3 _coordScale;
    vec3 _coordBias;
    vec3 _gridSpacing = vec3(1.0f);
    float _scalarScale;
    float _scalarBias;
    GLTexture2D* _entryTex;
    GLTexture2D* _exitTex;
    GLTexture3D* _dataTex;
    GLTexture1D* _tfTex;
    GLTexture2D* _tfFullTex;
    GLTexture2D* _tfFrontTex;
    vec4 _lightPosition;
    vec4 _lightAmbient;
    vec4 _lightDiffuse;
    vec4 _lightSpecular;
    float _materialAmbient;
    float _materialDiffuse;
    float _materialSpecular;
    float _materialShininess;

#ifdef V3D_USE_OPENGL_4_3
    GLTexture3D* _emptySpaceTex;
    bool _emptySpaceSkippingEnabled = false;

    GLTexture3D* _ambOcclusionTex;
    bool _ambientOcclusionEnabled = false;
    bool _AOAsShadowEnabled = false;
    float _AOStrength;
#else
    const bool _emptySpaceSkippingEnabled = false;
    const bool _ambientOcclusionEnabled = false;
    const bool _AOAsShadowEnabled = false;
#endif

    bool _tricubicInterp;

    GLTexture3D* _secondDataTex;    // data for the second dimension of 2D TF classification
    GLTexture2D* _tf2dTex;
    bool _tf2dEnabled;
    float _secondScalarScale;
    float _secondScalarBias;

    bool _tfPreIntegrationEnabled;
    bool _lighting;
    LightingSide _lightingSide;

    GLTexture3D* _lightTex;
    bool _globalLighting;
    vec4 _globalAmbient;

    bool _bricking = false;

    GLFramebufferObject* _fbo;
};

} // namespace v3d

#endif // V3D_RENDERER_REGULARGRIDRAYCASTERGL_H_
