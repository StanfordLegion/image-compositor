#ifndef V3D_RENDERER_TETRAGRIDENTRYEXITRENDERERGL_H_
#define V3D_RENDERER_TETRAGRIDENTRYEXITRENDERERGL_H_

#include <memory>

#include "v3d/Util/Box.h"
#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/QuadGL.h"


namespace v3d {

class TriangleMeshGL;

class TetraGridEntryExitRendererGL {
public:
    TetraGridEntryExitRendererGL();

    GLTexture2D* outputEntryDepthTexture() { return _outEntryDepthTex; }
    GLTexture2D* outputExitDepthTexture()  { return _outExitDepthTex; }

    void setModelViewProjectionMatrix(const mat4& matrix) { _mvpMatrix = matrix; }
    void setBoundingBox(const Box<float>& box)            { _boundingBox = box; }
    void setBoundaryMesh(TriangleMeshGL* mesh)            { _boundaryMesh = mesh; }
    void setBoundaryCellIdsTexture(GLTextureBuffer* tex)  { _boundaryCellIdsTex = tex; }
    void setPointsTexture(GLTextureBuffer* tex)           { _pointsTex = tex; }
    void setCellsTexture(GLTextureBuffer* tex)            { _cellsTex = tex; }
    void setCellConnectionsTexture(GLTextureBuffer* tex)  { _cellConnsTex = tex; }

    // outputs
    void setOutputEntryPointTexture(GLTexture2D* tex);
    void setOutputEntryCellIdTexture(GLTexture2D* tex);
    void setOutputEntryDepthTexture(GLTexture2D* tex)     { _outEntryDepthTex = tex; }
    void setOutputExitPointTexture(GLTexture2D* tex);
    void setOutputExitDepthTexture(GLTexture2D* tex)      { _outExitDepthTex = tex; }

    // working space
    void setEntryFrontDepthTexture(GLTexture2D* tex)      { _entryFrontDepthTex = tex; }
    void setExitFrontDepthTexture(GLTexture2D* tex)       { _exitFrontDepthTex = tex; }
    void setFirstEntryCellIdTexture(GLTexture2D* tex)     { _firstEntryCellIdTex = tex; }

    // one pass of the depth peeling process
    bool renderFirstPass();     // returns true if any samples are rendered
    bool render();              // returns true if any samples are rendered
    void swapDepthTextures();   // for ping-pong rendering

protected:
    void initDepthBuffers();
    mat4 createOrthoMatrix(const Quad<float>& imagePlane, const Box<float>& boundingBox);

    // find the cell IDs for the points on the given rectangle; used for finding
    // the ray casting entry points
    bool renderInteriorEntryPoint(const Quad<float>& imagePlane);

    bool renderEntryPoint(bool clear);  // set clear to false for the first pass
    void renderExitPoint();

private:
    std::unique_ptr<GLShaderProgram> _entryShader;      // outputs intersection point and cell ID
    std::unique_ptr<GLShaderProgram> _exitShader;       // outputs intersection point
    std::unique_ptr<GLShaderProgram> _firstEntryShader;     // outputs intersection point and cell ID; no front depth buffer
    std::unique_ptr<GLShaderProgram> _cellWalkShader;       // cell walk to the near clip plane
    std::unique_ptr<GLShaderProgram> _farShader;        // outputs far clip plane

    std::unique_ptr<GLFramebufferObject> _entryFbo;
    std::unique_ptr<GLFramebufferObject> _exitFbo;
    std::unique_ptr<GLFramebufferObject> _firstEntryFbo;
    std::unique_ptr<GLFramebufferObject> _cellWalkFbo;

    std::unique_ptr<QuadGL> _screenQuad;
    std::unique_ptr<GLuint, void(*)(GLuint*)> _queryId;     // any samples passed; for depth peeling

    mat4 _mvpMatrix;
    Box<float> _boundingBox;    // bounding box of the grid
    TriangleMeshGL* _boundaryMesh;
    GLTextureBuffer* _boundaryCellIdsTex;
    GLTextureBuffer* _pointsTex;
    GLTextureBuffer* _cellsTex;
    GLTextureBuffer* _cellConnsTex;
    GLTexture2D* _outEntryPointTex;
    GLTexture2D* _outEntryCellIdTex;
    GLTexture2D* _outEntryDepthTex;
    GLTexture2D* _outExitPointTex;
    GLTexture2D* _outExitDepthTex;

    // additional depth buffers for ping-pong rendering
    GLTexture2D* _entryFrontDepthTex;
    GLTexture2D* _exitFrontDepthTex;

    GLTexture2D* _firstEntryCellIdTex;

    int _pass;
};

} // namespace v3d

#endif // V3D_RENDERER_TETRAGRIDENTRYEXITRENDERERGL_H_
