#ifndef V3D_RENDERER_TFPREINTEGRATORGL_H_
#define V3D_RENDERER_TFPREINTEGRATORGL_H_

#include <memory>

#include "v3d/Util/GLFramebufferObject.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/QuadGL.h"


namespace v3d {

class TFPreIntegratorGL {
public:
    TFPreIntegratorGL();

    void setInputTFTexture(GLTexture1D* tex)           { _inTFTex = tex; }
    void setOutputTFFullTexture(GLTexture2D* tex);
    void setOutputTFFrontTexture(GLTexture2D* tex);
    void setTableSize(int tableSize)                   { _tableSize = tableSize; }
    void setSampleDistance(float sampleDistance)       { _sampleDistance = sampleDistance; }
    void setOpacityUnitDistance(float opcUnitdistance) { _opacityUnitDistance = opcUnitdistance; }
    void setAlphaPremultiplication(bool enable)        { _alphaPremult = enable; }

    void update();

private:
    std::unique_ptr<GLShaderProgram> _shader;
    std::unique_ptr<GLFramebufferObject> _fbo;
    std::unique_ptr<QuadGL> _fullScreenQuad;

    GLTexture1D* _inTFTex;
    GLTexture2D* _outTFFullTex;
    GLTexture2D* _outTFFrontTex;
    int _tableSize;
    float _sampleDistance;
    float _opacityUnitDistance;
    bool _alphaPremult;
};

} // namespace v3d

#endif // V3D_RENDERER_TFPREINTEGRATORGL_H_
