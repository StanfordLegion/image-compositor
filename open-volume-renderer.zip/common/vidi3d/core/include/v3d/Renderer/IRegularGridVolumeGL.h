#ifndef V3D_RENDERER_IREGULARGRIDVOLUMEGL_H_
#define V3D_RENDERER_IREGULARGRIDVOLUMEGL_H_

#include <array>

#include "v3d/Util/Box.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/InterpolationType.h"
//#include "v3d/Util/IRgbaFunction.h"
#include "v3d/Util/ILookupTable.h"
#include "v3d/Util/ILookupTable2D.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class IRegularGridVolumeGL {
public:
    enum TransferFunctionType {
        TRANSFER_FUNCTION = 0,
        TRANSFER_FUNCTION_2D,
        OCCLUSION_TRANSFER_FUNCTION,
        CUSTOM_TRANSFER_FUNCTION_2D
    };

    virtual GLTexture3D* dataTexture() = 0;
    virtual Box<float> textureBox() const = 0;
    virtual Box<float> boundingBox() const = 0;
    virtual Box<float> clippingBox() const = 0;

    virtual vec3 gridSpacing() const = 0;

    virtual bool isDataDirty() const = 0;
    virtual void setDataDirty(bool dirty) = 0;
    virtual bool isClippingBoxDirty() const = 0;
    virtual void setClippingBoxDirty(bool dirty) = 0;

    virtual GLTexture3D* secondaryDataTexture() = 0;

//    virtual std::shared_ptr<IRgbaFunction> transferFunction() = 0;
    virtual std::shared_ptr<ILookupTable<vec4>> transferFunction() = 0;
    virtual bool isTransferFunctionDirty() const = 0;
    virtual bool isTransferFunctionDirtyCoarse() const = 0;
    virtual void setTransferFunctionDirty(bool dirty) = 0;
    virtual void setTransferFunctionDirtyCoarse(bool dirty) = 0;

    virtual std::shared_ptr<ILookupTable2D<vec4>> transferFunction2D() = 0;
    virtual bool isTransferFunction2DDirty() const = 0;
    virtual void setTransferFunction2DDirty(bool dirty) = 0;

    // TODO: remove these
//    virtual std::shared_ptr<ILookupTable2D<vec4>> occlusionTransferFunction() = 0;
//    virtual bool isOcclusionTransferFunctionDirty() const = 0;
//    virtual void setOcclusionTransferFunctionDirty(bool dirty) = 0;

    virtual bool isVisible() const = 0;
    virtual float sampleDistance() const = 0;
    virtual InterpolationType interpolationType() const = 0;
    virtual dvec2 scalarMappingRange() const = 0;
    virtual dvec2 secondaryScalarMappingRange() const = 0;
    virtual float opacityUnitDistance() const = 0;
//    virtual bool isTransferFunction2DEnabled() const = 0;
    virtual TransferFunctionType tfType() const = 0;
    virtual float ambient() const = 0;
    virtual float diffuse() const = 0;
    virtual float specular() const = 0;
    virtual float shininess() const = 0;
    virtual bool isBoundingBoxVisible() const = 0;
    virtual std::array<bool, 6> areBoundingBoxFacesVisible() const = 0;
    virtual vec4 boundingBoxLineColor() const = 0;
    virtual vec4 boundingBoxFillColor() const = 0;

    virtual bool isXSliceVisible() const = 0;
    virtual bool isYSliceVisible() const = 0;
    virtual bool isZSliceVisible() const = 0;
    virtual float xSlicePosition() const = 0;
    virtual float ySlicePosition() const = 0;
    virtual float zSlicePosition() const = 0;
    virtual vec4 xSliceOverlayColor() const = 0;
    virtual vec4 ySliceOverlayColor() const = 0;
    virtual vec4 zSliceOverlayColor() const = 0;

    virtual bool isVisibleDirty() const = 0;
    virtual bool isSampleDistanceDirty() const = 0;
    virtual bool isInterpolationTypeDirty() const = 0;
    virtual bool isScalarMappingRangeDirty() const = 0;
    virtual bool isSecondaryScalarMappingRangeDirty() const = 0;
    virtual bool isOpacityUnitDistanceDirty() const = 0;
//    virtual bool isTransferFunction2DEnabledDirty() const = 0;
    virtual bool isTFTypeDirty() const = 0;
    virtual bool isAmbientDirty() const = 0;
    virtual bool isDiffuseDirty() const = 0;
    virtual bool isSpecularDirty() const = 0;
    virtual bool isShininessDirty() const = 0;
    virtual bool isBoundingBoxVisibleDirty() const = 0;
    virtual bool isBoundingBoxFacesVisibleDirty() const = 0;
    virtual bool isBoundingBoxLineColorDirty() const = 0;
    virtual bool isBoundingBoxFillColorDirty() const = 0;

    virtual void setVisibleDirty(bool dirty) = 0;
    virtual void setSampleDistanceDirty(bool dirty) = 0;
    virtual void setInterpolationTypeDirty(bool dirty) = 0;
    virtual void setScalarMappingRangeDirty(bool dirty) = 0;
    virtual void setSecondaryScalarMappingRangeDirty(bool dirty) = 0;
    virtual void setOpacityUnitDistanceDirty(bool dirty) = 0;
//    virtual void setTransferFunction2DEnabledDirty(bool dirty) = 0;
    virtual void setTFTypeDirty(bool dirty) = 0;
    virtual void setAmbientDirty(bool dirty) = 0;
    virtual void setDiffuseDirty(bool dirty) = 0;
    virtual void setSpecularDirty(bool dirty) = 0;
    virtual void setShininessDirty(bool dirty) = 0;
    virtual void setBoundingBoxVisibleDirty(bool dirty) = 0;
    virtual void setBoundingBoxFacesVisibleDirty(bool dirty) = 0;
    virtual void setBoundingBoxLineColorDirty(bool dirty) = 0;
    virtual void setBoundingBoxFillColorDirty(bool dirty) = 0;

    virtual void setAllDirty(bool dirty) = 0;
};

} // namespace v3d

#endif // V3D_RENDERER_IREGULARGRIDVOLUMEGL_H_
