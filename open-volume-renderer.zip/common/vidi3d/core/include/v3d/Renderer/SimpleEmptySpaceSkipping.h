#ifndef V3D_RENDERER_SIMPLEEMPTYSPACESKIPPING_H_
#define V3D_RENDERER_SIMPLEEMPTYSPACESKIPPING_H_
#ifdef V3D_USE_OPENGL_4_3

#include "v3d/Util/GLConfig.h"
#include "v3d/Util/GLTexture.h"
#include "v3d/Util/GLShaderProgram.h"
#include "v3d/Util/Matrix.h"

namespace v3d {

// TODO: rename as ***GL
class SimpleEmptySpaceSkippingModule {
public:
    SimpleEmptySpaceSkippingModule();

    // input
    void setTransferFunctionTexture(GLTexture1D* tfTex)                   { _tfTex = tfTex; }
    void setDataTexture(GLTexture3D* dataTex)                             { _dataTex = dataTex; }
    void setCoordMapping(const vec3& scale, const vec3& bias)             { _coordScale = scale; _coordBias = bias; }
    void setScalarMapping(float scale, float bias)                        { _scalarScale = scale; _scalarBias = bias; }
    void setEmptySpaceTexture(std::shared_ptr<GLTexture3D> emptySpaceTex) { _emptySpaceTex = emptySpaceTex; }
    void setDataSize(const ivec3& size);

    // output
    void genTexture();
    std::shared_ptr<GLTexture3D> getEmptySpaceTexture()                   { return _emptySpaceTex; }

protected:
    void createShader();

private:
    std::unique_ptr<GLShaderProgram> _shader;
    std::shared_ptr<GLTexture3D> _emptySpaceTex;

    GLTexture1D* _tfTex;
    GLTexture3D* _dataTex;
    int _maxLevels;
    ivec3 _dataSize;
    vec3 _coordScale;
    vec3 _coordBias;
    float _scalarScale;
    float _scalarBias;
};

} // namespace v3d

#endif // V3D_USE_OPENGL_4_3
#endif // V3D_RENDERER_SIMPLEEMPTYSPACESKIPPING_H_
