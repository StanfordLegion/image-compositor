#ifndef V3D_UTIL_ICAMERA_H_
#define V3D_UTIL_ICAMERA_H_

#include "v3d/Util/Matrix.h"


namespace v3d {

class ICamera {
public:
    virtual void setAspect(double aspect) = 0;
    virtual dmat4 viewMatrix() const = 0;
    virtual dmat4 projectionMatrix() const = 0;
    virtual dmat4 viewProjectionMatrix() const = 0;
    virtual dmat3 normalMatrix() const = 0;
};

} // namespace v3d

#endif // V3D_UTIL_ICAMERA_H_
