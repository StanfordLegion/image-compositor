#ifndef V3D_UTIL_CAMERA_H_
#define V3D_UTIL_CAMERA_H_

#include "v3d/Util/ICamera.h"
#include "v3d/Util/Matrix.h"
#include "v3d/Util/Vector.h"

#include <v3d_core_export.h>

namespace v3d {

class Camera : public ICamera {
public:
    enum ProjectionMode { ORTHO, PERSPECTIVE };

public:
    Camera() {}

    dvec3  eye()      const { return _eye; }
    dvec3  center()   const { return _center; }
    dvec3  up()       const { return _up; }
    double fovy()     const { return _fovy; }
    double aspect()   const { return _aspect; }
    double zNear()    const { return _near; }
    double zFar()     const { return _far; }
    ProjectionMode projectionMode() const { return _projectionMode; }
    double distance() const;

    void setEye(const dvec3& eye)                { _eye = eye; }
    void setEye(double x, double y, double z)    { setEye(dvec3(x, y, z)); }
    void setCenter(const dvec3& center)          { _center = center; }
    void setCenter(double x, double y, double z) { setCenter(dvec3(x, y, z)); }
    void setUp(const dvec3& up);
    void setUp(double x, double y, double z)     { setUp(dvec3(x, y, z)); }

    void setFovy(double fovy)                    { _fovy = fovy; }
    void setAspect(double aspect) override       { _aspect = aspect; }
    void setNear(double zNear)                   { _near = zNear; }
    void setFar(double zFar)                     { _far = zFar; }
    void setProjectionMode(ProjectionMode mode)  { _projectionMode = mode; }
    void setDistance(double distance);

    void lookAt(const dvec3& eye, const dvec3& center, const dvec3& up);
    void perspective(double fovy, double aspect, double zNear, double zFar);

    void moveLeft(double delta);
    void moveRight(double delta);
    void moveDown(double delta);
    void moveUp(double delta);
    void moveForward(double delta);
    void moveBackward(double delta);

    void moveCenterTo(const dvec3& center);

    // TODO: turn{Left, Right}

    dmat4 viewMatrix() const override;              // V
    dmat4 projectionMatrix() const override;        // P
    dmat4 viewProjectionMatrix() const override;    // P * V
    dmat3 normalMatrix() const override;

private:
    dvec3  _eye    = dvec3(0.0, 0.0, 1.0);  // camera position
    dvec3  _center = dvec3(0.0, 0.0, 0.0);  // camera focal point
    dvec3  _up     = dvec3(0.0, 1.0, 0.0);  // camera view up
    double _fovy   = 45.0;
    double _aspect = 1.0;                   // aspect ratio, i.e. the ratio of width to height
    double _near   = 0.001;
    double _far    = 1000.0;
    ProjectionMode _projectionMode = PERSPECTIVE;   // Ortho, Perspective
};

} // namespace v3d

#endif // V3D_UTIL_CAMERA_H_
