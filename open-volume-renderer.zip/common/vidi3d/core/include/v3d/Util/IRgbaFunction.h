#ifndef V3D_UTIL_IRGBAFUNCTION_H_
#define V3D_UTIL_IRGBAFUNCTION_H_

#include <vector>

#include "v3d/Util/Vector.h"


namespace v3d {

class IRgbaFunction {
public:
    virtual const std::vector<vec4>& rgbaTable() const = 0;
};

} // namespace v3d

#endif // V3D_UTIL_IRGBAFUNCTION_H_
