#ifndef V3D_UTIL_POISSONDISCSAMPLER_H_
#define V3D_UTIL_POISSONDISCSAMPLER_H_

#include <vector>

#include "v3d/Util/Vector.h"


namespace v3d {

class PoissonDiscSampler {
public:
    PoissonDiscSampler();

//    void setNumberOfPoints(int numPoints) { _numPoints = numPoints; }
    void setPoints(std::vector<vec2>* points) { _points = points; }
    void setRepeating(bool repeating) { _repeating = repeating; }

//    std::vector<vec2> generatePoints();
    void generatePoints(int numPoints);

private:
//    float _minDist;
//    int _numPoints;
    std::vector<vec2>* _points;
    bool _repeating;    // whether 1.0 is connected with 0.0
};

} // namespace v3d

#endif // V3D_UTIL_POISSONDISCSAMPLER_H_
