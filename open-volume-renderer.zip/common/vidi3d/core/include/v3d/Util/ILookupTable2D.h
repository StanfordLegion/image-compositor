#ifndef V3D_UTIL_ILOOKUPTABLE2D_H_
#define V3D_UTIL_ILOOKUPTABLE2D_H_

#include "v3d/Util/Vector.h"


namespace v3d {

// TODO: move to ILookupTable2D.h
template<class T>
class ILookupTable2D {
public:
    virtual const T* data() const = 0;
    virtual ivec2 size() const = 0;
};

} // namespace v3d

#endif // V3D_UTIL_ILOOKUPTABLE2D_H_
