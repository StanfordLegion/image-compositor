#ifndef V3D_UTIL_SHADERPREPROCESSOR_H_
#define V3D_UTIL_SHADERPREPROCESSOR_H_

#include <map>
#include <string>

namespace v3d {

class ShaderPreprocessor {
public:
    ShaderPreprocessor();

    void setSourceCode(const std::string& source);
    void setSourceFile(const std::string& fileName);
    void setModuleSourceCode(const std::string& moduleName, const std::string& moduleSource);
    void setModule(const std::string& moduleName, const std::string& fileName);

    std::string generate() const;

protected:
    std::string processPragma(const std::string& sourceCode) const;
    std::string processInclude(const std::string& sourceCode) const;

private:
    std::string _source;
    std::map<std::string, std::string> _moduleMap;
};

} // namespace v3d

#endif // V3D_UTIL_SHADERPREPROCESSOR_H_
