#ifndef V3D_DATA_TETRACONNECTIVITYBUILDER_H_
#define V3D_DATA_TETRACONNECTIVITYBUILDER_H_

#include "v3d/Util/Vector.h"


namespace v3d {

class TetraConnectivityBuilder {
public:
    TetraConnectivityBuilder();

    void setPointCount(int pointCount) { _pointCount = pointCount; }
    void setInputCells(const ivec4* cells, int cellCount) { _inCells = cells; _cellCount = cellCount; }
    void setOutputCellConnections(ivec4* cellConnects) { _outCellConns = cellConnects; }

    void buildCellToCellConnectivity();
    void _buildCellToCellConnectivity();

private:
    const ivec4* _inCells;
    ivec4* _outCellConns;
    int _pointCount;
    int _cellCount;
};

} // namespace v3d

#endif // V3D_DATA_TETRACONNECTIVITYBUILDER_H_
