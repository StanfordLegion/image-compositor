#ifndef V3D_DATA_TETRAGRIDDATAGL_H_
#define V3D_DATA_TETRAGRIDDATAGL_H_

#include <memory>

#include "v3d/Data/TetraGridData.h"
#include "v3d/Data/TetraGridGL.h"
#include "v3d/Util/GLBuffer.h"
#include "v3d/Util/GLTexture.h"


namespace v3d {

/** @brief This is the TetraGrid class with data included specific for OpenGL implementation
 * This class is movable but not copyable because it contains data
 */
class TetraGridDataGL : public TetraGridData, public TetraGridGL {
public:
    /** @name Special Functions
     *  @note The class is movable but not copyable
     */
    ///@{
    ~TetraGridDataGL() override = default;
    TetraGridDataGL();
    TetraGridDataGL(int pointCount, int cellCount);
    ///@}

    /** @name Getter */
    ///@{
    TetraGridGL*       grid()       { return this; }
    const TetraGridGL* grid() const { return this; }
    ///@}

    /** @name Setter */
    ///@{
    void setGrid(TetraGrid* grid_) override;
    ///@}

    const GLTextureBuffer* pointDataTexture() const { return _pointDataTex.get(); }
    GLTextureBuffer*       pointDataTexture()       { return _pointDataTex.get(); }
    const GLTextureBuffer* pointGradientTexture() const { return _pointGradientTex.get(); }
    GLTextureBuffer*       pointGradientTexture()       { return _pointGradientTex.get(); }

    /** @name Data Allocation Methods */
    ///@{
    void allocateGrid(int pointCount, int cellCount) override;
    void allocateBoundaryMesh(int triangleCount) override
    {
        return TetraGridGL::allocateBoundaryMesh(triangleCount);
    }
    ///@}

    /** @brief Load the data into OpenGL textures
     */
    void loadGL();
    /** @brief Unload the data from OpenGL textures
     */
    void unloadGL();

private:
    std::unique_ptr<GLBuffer> _pointDataBuffer;
    std::unique_ptr<GLBuffer> _pointGradientBuffer;
    std::unique_ptr<GLTextureBuffer> _pointDataTex;
    std::unique_ptr<GLTextureBuffer> _pointGradientTex;
};

} // namespace v3d

#endif // V3D_DATA_TETRAGRIDDATAGL_H_
