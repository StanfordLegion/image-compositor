#ifndef V3D_DATA_TETRAGRIDGL_H_
#define V3D_DATA_TETRAGRIDGL_H_

#include <memory>

#include "v3d/Data/TetraGrid.h"
#include "v3d/Util/GLBuffer.h"
#include "v3d/Util/GLTexture.h"


namespace v3d {

class TetraBoundaryMeshGL;

/** @brief This class specifies how data are stored in OpenGL buffers
 * This class is a value class that can be moved and copied
 */
class TetraGridGL : virtual public TetraGrid {
public:
    /** @name Special Functions
     *  @note This class is a value class that can be moved and copied
     */
    ///@{
    ~TetraGridGL() override = default;
    TetraGridGL();
    TetraGridGL(int pointCount, int cellCount);
    ///@}

    /** @name Read-Only Properties */
    ///@{
    // TODO should not access data here without const
    GLBuffer*       pointsBuffer()       { return _pointsBuffer.get(); }
    const GLBuffer* pointsBuffer() const { return _pointsBuffer.get(); }
    GLBuffer*       cellsBuffer()        { return _cellsBuffer.get(); }
    const GLBuffer* cellsBuffer()  const { return _cellsBuffer.get(); }
    GLBuffer*       cellConnectionsBuffer()       { return _cellConnsBuffer.get(); }
    const GLBuffer* cellConnectionsBuffer() const { return _cellConnsBuffer.get(); }
    GLTextureBuffer*       pointsTexture()        { return _pointsTex.get(); }
    const GLTextureBuffer* pointsTexture()  const { return _pointsTex.get(); }
    GLTextureBuffer*       cellsTexture()         { return _cellsTex.get(); }
    const GLTextureBuffer* cellsTexture()   const { return _cellsTex.get(); }
    GLTextureBuffer*       cellConnectionsTexture()       { return _cellConnsTex.get(); }
    const GLTextureBuffer* cellConnectionsTexture() const { return _cellConnsTex.get(); }
    TetraBoundaryMeshGL*       boundaryMesh();
    const TetraBoundaryMeshGL* boundaryMesh() const;
    ///@}

    /**
     * @brief Data Allocation Methods
     * @param triangleCount
     */
    void allocateBoundaryMesh(int triangleCount) override;

    /**
     * @brief Load the data into OpenGL textures
     */
    void loadGL();

    /**
     * @brief Unload the data from OpenGL textures
     */
    void unloadGL();

private:
    // Note: Qi changed all of the following pointers from unique_ptr to shared_ptr
    std::shared_ptr<GLBuffer> _pointsBuffer;
    std::shared_ptr<GLBuffer> _cellsBuffer;
    std::shared_ptr<GLBuffer> _cellConnsBuffer;
    std::shared_ptr<GLTextureBuffer> _pointsTex;
    std::shared_ptr<GLTextureBuffer> _cellsTex;
    std::shared_ptr<GLTextureBuffer> _cellConnsTex;
};

////////////////////////////////////////////////////////////////////////////////

/** @brief The OpenGL specification for the v3d::TetraBoundaryMesh class
 * This class is movable but not copyable because it contains data
 */
class TetraBoundaryMeshGL : public TetraBoundaryMesh {
public:
    /** @name Constructors */
    ///@{
    explicit TetraBoundaryMeshGL(std::weak_ptr<TetraGridGL> grid_);
    ///@}

    /** @name Getters */
    ///@{
    GLBuffer*       trianglesBuffer()       { return _trianglesBuffer.get(); }
    const GLBuffer* trianglesBuffer() const { return _trianglesBuffer.get(); }
    GLBuffer*       cellIdsBuffer()         { return _cellIdsBuffer.get(); }
    const GLBuffer* cellIdsBuffer()   const { return _cellIdsBuffer.get(); }
    GLBuffer*       verticesBuffer()        { return _verticesBuffer.get(); }
    const GLBuffer* verticesBuffer()  const { return _verticesBuffer.get(); }
    GLTextureBuffer*       cellIdsTexture()       { return _cellIdsTex.get(); }
    const GLTextureBuffer* cellIdsTexture() const { return _cellIdsTex.get(); }
    ///@}

    /** @brief the offset of the normals in verticesBuffer */
    GLint normalsOffset() const;

    void loadGL();
    void unloadGL();

private:
    std::unique_ptr<GLBuffer> _trianglesBuffer;
    std::unique_ptr<GLBuffer> _cellIdsBuffer;
    std::unique_ptr<GLBuffer> _verticesBuffer;
    std::unique_ptr<GLTextureBuffer> _cellIdsTex;
    // TODO: add normals
};

} // namespace v3d

#endif // V3D_DATA_TETRAGRIDGL_H_
