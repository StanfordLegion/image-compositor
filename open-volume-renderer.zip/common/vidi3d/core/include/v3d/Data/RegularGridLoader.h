#ifndef V3D_DATA_REGULARGRIDLOADER_H_
#define V3D_DATA_REGULARGRIDLOADER_H_

#include <string>

#include "v3d/Data/DataUtil.h"
#include "v3d/Data/RegularGridData.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class RegularGridLoader {
public:
    RegularGridLoader();

    std::string fileName() const      { return _fileName; }
    size_t      offset() const        { return _offset; }
    v3d::ivec3  dimensions() const    { return _dim; }
    v3d::Type   type() const          { return _type; }
    v3d::Endian endian() const        { return _endian; }
    bool        fileUpperLeft() const { return _fileUpperLeft; }

    void setFileName(const std::string& fileName) { _fileName = fileName; }
    void setOffset(size_t offset)                 { _offset = offset; }
    void setDimensions(const ivec3& dim)          { _dim = dim; }
    void setType(Type type)                       { _type = type; }
    void setEndian(Endian endian)                 { _endian = endian; }
    void setFileUpperLeft(bool on)                { _fileUpperLeft = on; }

    void setOutputData(RegularGridData* data)     { _outData = data; }

    bool update();

    static bool load(const std::string& fileName, size_t offset, const ivec3& dim, Type type, Endian endian, bool fileUpperLeft, RegularGridData* data);

private:
    std::string      _fileName;
    size_t           _offset;
    ivec3            _dim;
    Type             _type;
    Endian           _endian;
    bool             _fileUpperLeft;    // whether the data comes from the file starting in the lower left (off) or upper left corner (on) of the grid
                                        // i.e. reverses z ordering if it's on; usually required by medical imaging data
    RegularGridData* _outData;
};

} // namespace v3d

#endif // V3D_DATA_REGULARGRIDLOADER_H_
