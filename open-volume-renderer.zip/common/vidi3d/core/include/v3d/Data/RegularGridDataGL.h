#ifndef V3D_DATA_REGULARGRIDDATAGL_H_
#define V3D_DATA_REGULARGRIDDATAGL_H_

#include <memory>

#include "v3d/Data/DataUtilGL.h"
#include "v3d/Data/RegularGridData.h"
#include "v3d/Util/GLTexture.h"


namespace v3d {

/**
 * @brief Defines how the volumetric data is organized using OpenGL textures.
 * This class is currently marked as **final** and inherits the
 * v3d::IVolumetricMedium class
 */
class RegularGridDataGL : public RegularGridData {
public:
    /**
     * @name Special Functions
     * @note This class is movable but not copyable
     */
    ///@{
    ~RegularGridDataGL() override;
    RegularGridDataGL(const RegularGridDataGL&) = delete;
    RegularGridDataGL& operator=(const RegularGridDataGL&) = delete;
    RegularGridDataGL(RegularGridDataGL&&) noexcept;
    RegularGridDataGL& operator=(RegularGridDataGL&&) noexcept;
    RegularGridDataGL();
    RegularGridDataGL(const ivec3 &dim, Type type);
    ///@}

    /**
     * @brief TODO
     * @param internalFormat
     */
    void setInternalFormat(GLint internalFormat);

    /**
     * @brief TODO
     * @return
     */
    GLint internalFormat() const;

    /**
     * @brief TODO
     * @return
     */
    bool isLoadedGL() const;

    /**
     * @brief TODO
     * @return
     */
    GLTexture3D *texture(); // TODO should not access data here

    /**
     * @brief Load the data into OpenGL textures
     */
    void loadGL();

    /**
     * @brief Unload the data from OpenGL textures
     */
    void unloadGL();

private:
    class impl;
    std::unique_ptr<impl> pimpl;
};

} // namespace v3d

#endif // V3D_DATA_REGULARGRIDDATAGL_H_
