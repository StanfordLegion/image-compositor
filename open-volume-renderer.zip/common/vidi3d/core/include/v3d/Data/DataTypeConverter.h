#ifndef V3D_DATA_DATATYPECONVERTER_H_
#define V3D_DATA_DATATYPECONVERTER_H_

#include "v3d/Data/DataUtil.h"


namespace v3d {

class DataTypeConverter {
public:
    DataTypeConverter();

    static void convert(const void* inData, Type inType, Type outType, size_t count, bool normalized, void* outData);

    template<typename InType, typename OutType>
    static void convert(const InType* inData, size_t count, bool normalized, OutType* outData);
};

} // namespace v3d

#endif // V3D_DATA_DATATYPECONVERTER_H_
