#ifndef V3D_DATA_TETRAGRIDDATA_H_
#define V3D_DATA_TETRAGRIDDATA_H_

#include <memory>

#include "v3d/Data/TetraGrid.h"


namespace v3d {

/**
 * @brief This is the v3d::TetraGrid class with data included. This class is
 * movable but not copyable because it contains data.
 */
class TetraGridData: virtual public TetraGrid {
    friend class TetraGridVolumeGL;
public:
    /**
     * @name Special Functions
     * @note The class is movable but not copyable
     */
    ///@{
    ~TetraGridData() override = default;
    TetraGridData(const TetraGridData&) = delete;
    TetraGridData& operator=(const TetraGridData& other) = delete;
    TetraGridData(TetraGridData&&) = default;
    TetraGridData& operator=(TetraGridData&& other) = default;
    TetraGridData();
    TetraGridData(int pointCount, int cellCount);
    ///@}

    /** @name Getter */
    ///@{
    TetraGrid*   grid()            { return this; } // TODO should add const protection and use shared_ptr? but how
    float*       pointData()       { return _pointData.get(); } // TODO should use setter to allocate data
    const float* pointData() const { return _pointData.get(); } // TODO should not use raw pointers
    ///@}

    /** @name Setter */
    ///@{
    virtual void setGrid(TetraGrid*);
    void         setPointData(std::unique_ptr<float[]>&& pointData) { _pointData = std::move(pointData); }
    ///@}

    /** @name Properties */
    ///@{
    const float* cellData()      const { return _cellData.get(); } // TODO should not use raw pointers
    const vec3*  pointGradient() const { return _pointGradient.get(); }
    const vec3*  cellGradient()  const { return _cellGradient.get(); }
    bool isPointDataAvailable()  const { return (_pointData != nullptr); }
    bool isCellDataAvailable()   const { return (_cellData != nullptr); }
    template<typename T>
    Vector2<T> getScalarRange() const;
    ///@}

    /** @name Data Allocation Methods */
    ///@{
    void allocatePointData();
    void allocatePointGradient();
    void allocateCellData();
    void allocateCellGradient();
    virtual void allocateGrid(int, int);
    ///@}

    /**
     * @brief Compute point gradient.
     * Uses TetraGradientFilter.
     */
    void computePointGradient();

    /**
     * @brief Compute point data from cell data.
     * Uses TetraCellDataToPointData.
     */
    void computePointDataFromCellData();

protected:
    /** @name Internal Getters */
    ///@{
    float* cellData()      { return _cellData.get(); } // TODO should not use raw pointers
    vec3*  pointGradient() { return _pointGradient.get(); }
    vec3*  cellGradient()  { return _cellGradient.get(); }
    ///@}

private:
    // Note by Min: Should we change these to shared_ptr?
    // Note by Qi: 1) Probably not because we always this allows us to explicitly handle where data lives. If we can
    //                enforce unique_ptr in the beginning, it should be better.
    //             2) Before c17, shared_ptr cannot handle array using array form: std::shared_ptr<T[]>. We have to use
    //                std::shared_ptr<T>[] instead if we want to std::move from unique_ptr<T[]> to a shared pointer
    //                form. However since c17, this way to move has been forbidden. We need to use shared_ptr<T[]>
    //                instead. This fact will further complicates our implementation if use shared pointer.
    std::unique_ptr<float[]> _pointData;
    std::unique_ptr<vec3[]>  _pointGradient;
    std::unique_ptr<float[]> _cellData;
    std::unique_ptr<vec3[]>  _cellGradient;

};

} // namespace v3d

#endif // V3D_DATA_TETRAGRIDDATA_H_
