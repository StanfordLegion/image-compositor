#ifndef V3D_DATA_DATAUTIL_H_
#define V3D_DATA_DATAUTIL_H_

#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <type_traits>
#include <utility>

namespace v3d {

enum Type {
    V3D_VOID,
    V3D_BYTE,
    V3D_UNSIGNED_BYTE,
    V3D_SHORT,
    V3D_UNSIGNED_SHORT,
    V3D_INT,
    V3D_UNSIGNED_INT,
    V3D_FLOAT,
    V3D_DOUBLE
};

inline size_t typeSize(Type type)
{
    switch (type) {
        case V3D_BYTE:           return sizeof(int8_t);
        case V3D_UNSIGNED_BYTE:  return sizeof(uint8_t);
        case V3D_SHORT:          return sizeof(int16_t);
        case V3D_UNSIGNED_SHORT: return sizeof(uint16_t);
        case V3D_INT:            return sizeof(int32_t);
        case V3D_UNSIGNED_INT:   return sizeof(uint32_t);
        case V3D_FLOAT:          return sizeof(float);
        case V3D_DOUBLE:         return sizeof(double);
        default:                 assert(false); return 0;
    }
}

////////////////////////////////////////////////////////////////////////////////

// integer normalization following OpenGL's specification
// https://www.khronos.org/opengl/wiki/Normalized_Integer

// normalize unsigned integer
template<
  typename OutType, typename InType,
  typename = typename std::enable_if<std::is_floating_point<OutType>::value &&
                                     std::is_integral<InType>::value &&
                                     std::is_unsigned<InType>::value>::type>
inline OutType intNormalize(InType val)
{
    const auto maxVal =
      static_cast<OutType>(std::numeric_limits<InType>::max());
    return (static_cast<OutType>(val) / maxVal);
}

// normalize signed integer
template<
  typename OutType, typename InType, typename = void,
  typename = typename std::enable_if<std::is_floating_point<OutType>::value &&
                                     std::is_integral<InType>::value &&
                                     std::is_signed<InType>::value>::type>
inline OutType intNormalize(InType val)
{
    const auto maxVal =
      static_cast<OutType>(std::numeric_limits<InType>::max());
    const OutType normVal = static_cast<OutType>(val) / maxVal;
    return (normVal < OutType(-1.0) ? OutType(-1.0) : normVal);
}

////////////////////////////////////////////////////////////////////////////////

enum Endian { V3D_BIG_ENDIAN = 0, V3D_LITTLE_ENDIAN = 1 };

inline Endian systemEndian()
{
    uint16_t test = 1;
    return Endian(*reinterpret_cast<char*>(&test));
}

////////////////////////////////////////////////////////////////////////////////

template<size_t Size> inline void swapBytes(void* data)
{
    char* p = reinterpret_cast<char*>(data);
    char* q = p + Size - 1;
    while (p < q) std::swap(*(p++), *(q--));
}

template<> inline void swapBytes<1>(void*) {}

template<> inline void swapBytes<2>(void* data)
{
    char* p = reinterpret_cast<char*>(data);
    std::swap(p[0], p[1]);
}

template<> inline void swapBytes<4>(void* data)
{
    char* p = reinterpret_cast<char*>(data);
    std::swap(p[0], p[3]);
    std::swap(p[1], p[2]);
}

template<> inline void swapBytes<8>(void* data)
{
    char* p = reinterpret_cast<char*>(data);
    std::swap(p[0], p[7]);
    std::swap(p[1], p[6]);
    std::swap(p[2], p[5]);
    std::swap(p[3], p[4]);
}

template<typename T> inline void swapBytes(T* data)
{
    swapBytes<sizeof(T)>(reinterpret_cast<void*>(data));
}

////////////////////////////////////////////////////////////////////////////////

template<typename T, size_t Size> struct ByteSwapImpl {
};

template<typename T> struct ByteSwapImpl<T, 1> {
    static T byteSwapped(T val) { return val; }
};

template<typename T> struct ByteSwapImpl<T, 2> {
    static T byteSwapped(T val)
    {
        auto* p = reinterpret_cast<uint16_t*>(&val);
        *p      = uint16_t(*p << 8U) | uint16_t(*p >> 8U);
        return val;
    }
};

template<typename T> struct ByteSwapImpl<T, 4> {
    static T byteSwapped(T val)
    {
        auto* p = reinterpret_cast<uint32_t*>(&val);
        *p      = ((*p << 8u) & 0xFF00FF00U) | ((*p >> 8u) & 0x00FF00FFU);
        *p      = (*p << 16U) | (*p >> 16U);
        return val;
    }
};

template<typename T> struct ByteSwapImpl<T, 8> {
    static T byteSwapped(T val)
    {
        auto* p = reinterpret_cast<uint64_t*>(&val);
        *p      = ((*p << 8U) & 0xFF00FF00FF00FF00ULL) |
             ((*p >> 8U) & 0x00FF00FF00FF00FFULL);
        *p = ((*p << 16U) & 0xFFFF0000FFFF0000ULL) |
             ((*p >> 16U) & 0x0000FFFF0000FFFFULL);
        *p = (*p << 32U) | (*p >> 32U);
        return val;
    }
};

template<> struct ByteSwapImpl<uint16_t, 2> {
    static uint16_t byteSwapped(uint16_t val)
    {
        return uint16_t(val << 8U) | uint16_t(val >> 8U);
    }
};

template<> struct ByteSwapImpl<uint32_t, 4> {
    static uint32_t byteSwapped(uint32_t val)
    {
        val = ((val << 8U) & 0xFF00FF00U) | ((val >> 8U) & 0x00FF00FFU);
        return (val << 16U) | (val >> 16U);
    }
};

template<> struct ByteSwapImpl<uint64_t, 4> {
    static uint64_t byteSwapped(uint64_t val)
    {
        val = ((val << 8U) & 0xFF00FF00FF00FF00ULL) |
              ((val >> 8U) & 0x00FF00FF00FF00FFULL);
        val = ((val << 16U) & 0xFFFF0000FFFF0000ULL) |
              ((val >> 16U) & 0x0000FFFF0000FFFFULL);
        return (val << 32U) | (val >> 32U);
    }
};

template<typename T> inline T byteSwapped(T src)
{
    return ByteSwapImpl<T, sizeof(T)>::byteSwapped(src);
}

////////////////////////////////////////////////////////////////////////////////

template<typename T> inline T fromBigEndian(T src)
{
    return (systemEndian() == V3D_BIG_ENDIAN) ? src : byteSwapped(src);
}

template<> inline int8_t fromBigEndian(int8_t src) { return src; }

template<> inline uint8_t fromBigEndian(uint8_t src) { return src; }

template<typename T> inline T fromLittleEndian(T src)
{
    return (systemEndian() == V3D_LITTLE_ENDIAN) ? src : byteSwapped(src);
}

template<> inline int8_t fromLittleEndian(int8_t src) { return src; }

template<> inline uint8_t fromLittleEndian(uint8_t src) { return src; }

template<typename T> inline T toBigEndian(T src) { return fromBigEndian(src); }

template<typename T> inline T toLittleEndian(T src)
{
    return fromLittleEndian(src);
}

} // namespace v3d

#endif // V3D_DATA_DATAUTIL_H_
