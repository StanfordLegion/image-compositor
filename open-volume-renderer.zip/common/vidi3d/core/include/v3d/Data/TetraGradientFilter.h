#ifndef V3D_DATA_TETRAGRADIENTFILTER_H_
#define V3D_DATA_TETRAGRADIENTFILTER_H_

#include <vector>

#include "v3d/Util/Vector.h"


namespace v3d {

/**
 * @brief Gradient filter for tetrahedral-grid data
 */
class TetraGradientFilter {
public:
    enum Method {
        WEIGHTED_AVERAGE,
        WEIGHTED_REGRESSION
    };

public:
    TetraGradientFilter();

    void setInput(const vec3*  points,
                  int          pointCount,
                  const ivec4* cells,
                  int          cellCount,
                  const float* pointData);

    void setInputPoints(const vec3* points, int pointCount) { _inPoints = points; _pointCount = pointCount; }
    void setInputCells(const ivec4* cells, int cellCount)   { _inCells = cells; _cellCount = cellCount; }
    void setInputPointData(const float* pointData)          { _inPointData = pointData; }
    void setOutputPointGradient(vec3* pointGradient)        { _outPointGradient = pointGradient; }
    void setMethod(Method method)                           { _method = method; }

    void process();

private:
    const vec3*  _inPoints;
    const ivec4* _inCells;
    const float* _inPointData;
    vec3* _outPointGradient;
    int _pointCount;
    int _cellCount;
    Method _method;
};

////////////////////////////////////////////////////////////////////////////////

/**
 * @brief Vorticity filter for tetrahedral-grid data.
 */
class TetraVorticityFilter {
public:
    enum Method {
        WEIGHTED_AVERAGE,       // faster
        WEIGHTED_REGRESSION     // more accurate
    };

public:
    TetraVorticityFilter();

    void setInput(const vec3*  points,
                  int          pointCount,
                  const ivec4* cells,
                  int          cellCount,
                  const float* pointU,
                  const float* pointV,
                  const float* pointW);

    void setInputPoints(const vec3* points, int pointCount) { _inPoints = points; _pointCount = pointCount; }
    void setInputCells(const ivec4* cells, int cellCount)   { _inCells = cells; _cellCount = cellCount; }
    void setInputPointVelocity(const float* pointU, const float* pointV, const float* pointW);
    void setOutputPointVorticity(vec3* pointVorticity)      { _outPointVorticity = pointVorticity; }
    void setOutputPointQCriterion(float* pointQCriterion)   { _outPointQCriterion = pointQCriterion; }
    void setMethod(Method method)                           { _method = method; }

    void process();

private:
    const vec3*  _inPoints;
    const ivec4* _inCells;
    const float* _inPointU;
    const float* _inPointV;
    const float* _inPointW;
    vec3* _outPointVorticity;
    float* _outPointQCriterion;
    int _pointCount;
    int _cellCount;
    Method _method;
};


// TODO: remove testing code
void estimateGradientsWeightedAverage(
        const vec3*  points,
        int          pointCount,
        const ivec4* cells,
        int          cellCount,
        const float* pointData,
        vec3*        pointGradient);

void estimateGradientsWeightedRegression(
        const vec3*  points,
        int          pointCount,
        const ivec4* cells,
        int          cellCount,
        const float* pointData,
        vec3*        pointGradient);

void estimateVorticities(
        const vec3*  points,
        int          pointCount,
        const ivec4* cells,
        int          cellCount,
        const float* pointU,
        const float* pointV,
        const float* pointW,
        vec3*        pointVorticity);

void estimateQCriterion(
        const vec3*  points,
        int          pointCount,
        const ivec4* cells,
        int          cellCount,
        const float* pointU,
        const float* pointV,
        const float* pointW,
        float*       pointQCriterion);

} // namespace v3d

#endif // V3D_DATA_TETRAGRADIENTFILTER_H_
