#ifndef V3D_DATA_TETRACELLDATATOPOINTDATA_H_
#define V3D_DATA_TETRACELLDATATOPOINTDATA_H_

#include "v3d/Util/Vector.h"


namespace v3d {

class TetraCellDataToPointData {
public:
    TetraCellDataToPointData();

    void setInput(const vec3*  points,
                  int          pointCount,
                  const ivec4* cells,
                  int          cellCount,
                  const float* cellData);
    void setInputPoints(const vec3* points, int pointCount) { _inPoints = points; _pointCount = pointCount; }
    void setInputCells(const ivec4* cells, int cellCount)   { _inCells = cells; _cellCount = cellCount; }
    void setInputCellData(const float* cellData)            { _inCellData = cellData; }
    void setOutputPointData(float* pointData)               { _outPointData = pointData; }

    void process();

private:
    const vec3*  _inPoints;
    const ivec4* _inCells;
    const float* _inCellData;
    float* _outPointData;
    int _pointCount;
    int _cellCount;
};

} // namespace v3d

#endif // V3D_DATA_TETRACELLDATATOPOINTDATA_H_
