#ifndef V3D_DATA_MAGNITUDEFILTER_H_
#define V3D_DATA_MAGNITUDEFILTER_H_

#include "v3d/Util/Vector.h"

namespace v3d {

class MagnitudeFilter {
public:
    MagnitudeFilter();
    void setInputData(const vec3* vecData, int count);
    void setInputData(const float* xData, const float* yData,
                      const float* zData, int count);
    void setOutputData(float* data) { _outData = data; }
    void update();

private:
    const vec3*  _inVecData;
    const float* _inData[4];
    int          _dataCount;
    float*       _outData;
};

inline void MagnitudeFilter::setInputData(const vec3* vecData, int count)
{
    _inVecData = vecData;
    _dataCount = count;
}

} // namespace v3d

#endif // V3D_DATA_MAGNITUDEFILTER_H_
