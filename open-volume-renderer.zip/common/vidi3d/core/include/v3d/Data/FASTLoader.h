#ifndef V3D_DATA_FASTLOADER_H_
#define V3D_DATA_FASTLOADER_H_

#include <cstdint>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "v3d/Data/DataUtil.h"
#include "v3d/Data/TetraGridData.h"
#include "v3d/Util/Vector.h"

namespace v3d {

// helper class for handling endianness
class BinaryReader {
public:
    BinaryReader(const char* fileName, Endian endian = V3D_LITTLE_ENDIAN);
    virtual ~BinaryReader() {}

    size_t getFileSize() const { return _fileSize; }
    Endian getEndian() const { return _endian; }
    void   setEndian(Endian endian) { _endian = endian; }
    bool   isNonNativeEndian() const { return (_endian != _nativeEndian); }
    int    readInt();
    float  readFloat();
    double readDouble();
    void   readInts(int32_t* data, size_t count);
    void   readFloats(float* data, size_t count);
    void   readDoubles(double* data, size_t count);
    std::istream& read(char*           str,
                       std::streamsize count); // no endian correctness
    void          skip(size_t count);          // skip bytes

protected:
    std::ifstream _ifs;
    size_t        _fileSize;
    Endian        _endian;
    Endian        _nativeEndian;
};

////////////////////////////////////////////////////////////////////////////////

// helper class for reading Fortran binary
class FortranReader : public BinaryReader {
public:
    FortranReader(const char* fileName, Endian endian = V3D_LITTLE_ENDIAN);

    int    readHeaderAndDetectEndian(int expected = 4);
    int    readHeader();
    int    readTrailer();
    size_t totalBytes() const { return _totalBytes; }

private:
    bool detectEndian(int test, int expected = 4);

private:
    int32_t _lastHeader;
    size_t  _totalBytes;
};

////////////////////////////////////////////////////////////////////////////////

inline BinaryReader::BinaryReader(const char* fileName, Endian endian)
    : _endian(endian)
{
    _ifs.open(fileName, std::ios::in | std::ios::binary);
    if (_ifs.fail())
        std::cerr << "[Error] Opening file \"" << fileName << "\" failed."
                  << std::endl;

    _ifs.seekg(0, _ifs.end);
    _fileSize = _ifs.tellg();
    _ifs.seekg(0, _ifs.beg);

    _nativeEndian = systemEndian();
}

inline int BinaryReader::readInt()
{
    int32_t ret;
    _ifs.read(reinterpret_cast<char*>(&ret), sizeof(int32_t));
    if (isNonNativeEndian()) swapBytes(&ret);
    return int(ret);
}

inline float BinaryReader::readFloat()
{
    float ret;
    _ifs.read(reinterpret_cast<char*>(&ret), sizeof(float));
    if (isNonNativeEndian()) swapBytes(&ret);
    return ret;
}

inline double BinaryReader::readDouble()
{
    double ret;
    _ifs.read(reinterpret_cast<char*>(&ret), sizeof(double));
    if (isNonNativeEndian()) swapBytes(&ret);
    return ret;
}

inline void BinaryReader::readInts(int32_t* data, size_t count)
{
    if (count <= 0) return;
    _ifs.read(reinterpret_cast<char*>(data), sizeof(int32_t) * count);
    if (isNonNativeEndian())
        for (int i = 0; i < count; i++) swapBytes(&data[i]);
}

inline void BinaryReader::readFloats(float* data, size_t count)
{
    if (count <= 0) return;
    _ifs.read(reinterpret_cast<char*>(data), sizeof(float) * count);
    if (isNonNativeEndian())
        for (int i = 0; i < count; i++) swapBytes(&data[i]);
}

inline void BinaryReader::readDoubles(double* data, size_t count)
{
    if (count <= 0) return;
    _ifs.read(reinterpret_cast<char*>(data), sizeof(double) * count);
    if (isNonNativeEndian())
        for (int i = 0; i < count; i++) swapBytes(&data[i]);
}

inline std::istream& BinaryReader::read(char* str, std::streamsize count)
{
    _ifs.read(str, count);
    return _ifs;
}

inline void BinaryReader::skip(size_t count) { _ifs.seekg(count, _ifs.cur); }

////////////////////////////////////////////////////////////////////////////////

inline FortranReader::FortranReader(const char* fileName, Endian endian)
    : BinaryReader(fileName, endian)
{
    _lastHeader = 0;
    _totalBytes = 0;
}

inline int FortranReader::readHeaderAndDetectEndian(int expected)
{
    int32_t nbytes;
    _ifs.read(reinterpret_cast<char*>(&nbytes), sizeof(int32_t));
    detectEndian(nbytes, expected);
    if (isNonNativeEndian()) swapBytes(&nbytes);
    _lastHeader = nbytes;
    _totalBytes += 4;
    return int(nbytes);
}

inline int FortranReader::readHeader()
{
    int32_t nbytes;
    _ifs.read(reinterpret_cast<char*>(&nbytes), sizeof(int32_t));
    if (isNonNativeEndian()) swapBytes(&nbytes);
    _lastHeader = nbytes;
    _totalBytes += 4;
    return int(nbytes);
}

inline int FortranReader::readTrailer()
{
    int32_t nbytes;
    _ifs.read(reinterpret_cast<char*>(&nbytes), sizeof(int32_t));
    if (isNonNativeEndian()) swapBytes(&nbytes);
    if (nbytes != _lastHeader) {
        std::cerr << "[Error] Mismatch of record header and trailer."
                  << std::endl;
    }
    _totalBytes += nbytes + 4;
    return int(nbytes);
}

// detect the endianness
// return : {false (native endian), true (non-native endian)}
inline bool FortranReader::detectEndian(int test, int expected)
{
    bool isNative = true;
    if (test != expected) {
        swapBytes(&test);
        if (test == expected) // non-native endian, needs conversion
            isNative = false;
        else
            return false; // bad format
    }

    if (systemEndian() == V3D_LITTLE_ENDIAN) {
        if (isNative) {
            _endian = V3D_LITTLE_ENDIAN;
            std::cout << "[Info] Byte order: little-endian" << std::endl;
        }
        else {
            _endian = V3D_BIG_ENDIAN;
            std::cout << "[Info] Byte order: big-endian" << std::endl;
        }
    }
    else { // native is BIG_ENDIAN
        if (isNative) {
            _endian = V3D_BIG_ENDIAN;
            std::cout << "[Info] Byte order: big-endian" << std::endl;
        }
        else {
            _endian = V3D_LITTLE_ENDIAN;
            std::cout << "[Info] Byte order: little-endian" << std::endl;
        }
    }
    return true;
}

////////////////////////////////////////////////////////////////////////////////

/**
 * @brief PLOT3D/FAST format
 *
 *  * Single-precision (32-bit) floating point
 *  * endian: {LITTLE_ENDIAN, BIG_ENDIAN}
 *  * variableId: {0: density, 1: momentum, 2: energy}
 */
class FASTLoader {
public:
    enum VariableType { DENSITY = 0, RHO_U, RHO_V, RHO_W, ENERGY };

public:
    FASTLoader();

    std::string gridFileName() const { return _gridFileName; }
    std::string solutionFileName() const { return _solutionFileName; }
    Endian      gridFileEndian() const { return _gridByteOrder; }
    Endian      solutionFileEndian() const { return _solutionByteOrder; }

    void setGridFileName(const std::string& fileName)
    {
        _gridFileName = fileName;
    }
    void setSolutionFileName(const std::string& fileName)
    {
        _solutionFileName = fileName;
    }
    void setEndian(Endian endian)
    {
        _gridByteOrder = _solutionByteOrder = endian;
    }
    void setGridFile(const std::string& fileName, Endian byteOrder);
    void setSolutionFile(const std::string& fileName, Endian byteOrder);
    void setVariableType(VariableType varType);
    void setOutputTetraGridData(TetraGridData* data);

    void addOutputTetraGridData(TetraGridData* data, VariableType varType);
    void clearOutputList();

    void update();

private:
    std::string                 _gridFileName;
    std::string                 _solutionFileName;
    Endian                      _gridByteOrder;
    Endian                      _solutionByteOrder;
    std::vector<VariableType>   _variableType;
    std::vector<TetraGridData*> _outTetraData;
};

} // namespace v3d

#endif // V3D_DATA_FASTLOADER_H_
