#ifndef V3D_DATA_REGULARGRIDDATA_H_
#define V3D_DATA_REGULARGRIDDATA_H_

#include <cassert>
#include <memory>

#include "v3d/Data/DataUtil.h"
#include "v3d/Data/RegularGrid.h"
#include "v3d/Util/Histogram.h"
#include "v3d/Util/Vector.h"


namespace v3d {


/**
 * @brief Defines how the volumetric data is organized for a rectilinear uniform volume.
 */
class RegularGridData: public RegularGrid {
public:
    /**
     * @name Special Functions
     * @note The class is movable but not copyable
     */
    ///@{
    ~RegularGridData() override = default;
    RegularGridData(const RegularGridData &) = delete;
    RegularGridData &operator=(const RegularGridData &other) = delete;
    RegularGridData(RegularGridData &&) = default;
    RegularGridData &operator=(RegularGridData &&other) = default;
    RegularGridData();
    RegularGridData(const ivec3 &dim, Type type);
    ///@}

    /** @name Setter */
    ///@{
    /**
     * @brief Provide data to the volume class
     */
    void setData(std::shared_ptr<char> data, const ivec3 &dim, Type type);
    ///@}

    /** @name Getter */
    ///@{
    template<class T>
    Vector2<T> getScalarRange() const; //!< Access the volume scalar range
    size_t     getMemorySize()  const; //!< Access the size of memory taken
    Type       getDataType()    const { return _type; } //!< Access the volume type
    /** @brief Access the volume's histogram */
    Histogram  getHistogram() const;
    ///@}

    /**
     * @brief Check if data is empty
     */
    bool isValid() const { return (_data != nullptr); }

    /**
     * @brief Check if the data scalar range is valid
     */
    bool isScalarRangeValid() const;

    /** @brief Explicitly compute the data scalar range */
    void computeScalarRange();

    /**
     * @brief Access the volume scalar range
     */
    dvec2 getScalarRange() const { return _dataRange; }

    /**
     * @brief Special function to access the data value
     */
    template<class T = void>
    T *data() const { return reinterpret_cast<T *>(_data.get()); }

private:
    std::shared_ptr<char> _data; ///< The pointer that holds the data
    Type _type; ///< The data type
    dvec2 _dataRange{ 1.0, -1.0 }; // TODO will be initialized when referred or getScalarRange is being called.
};

} // namespace v3d

#endif // V3D_DATA_REGULARGRIDDATA_H_
