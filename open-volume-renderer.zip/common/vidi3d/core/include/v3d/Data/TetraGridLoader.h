#ifndef V3D_DATA_TETRAGRIDLOADER_H
#define V3D_DATA_TETRAGRIDLOADER_H

#include <string>

#include "TetraGridData.h"


namespace v3d {

class TetraGridLoader {
public:
    TetraGridLoader();

    std::string gridFileName() const { return _gridFileName; }
    std::string dataFileName() const { return _dataFileName; }
    int pointCount() const           { return _pointCount; }
    int cellCount() const            { return _cellCount; }
    size_t pointsOffset() const      { return _pointsOffset; }
    size_t cellsOffset() const       { return _cellsOffset; }
    size_t pointDataOffset() const   { return _pointDataOffset; }

    void setGridFileName(const std::string& fileName) { _gridFileName = fileName; }
    void setDataFileName(const std::string& fileName) { _dataFileName = fileName; }
    void setPointCount(int count)                     { _pointCount = count; }
    void setCellCount(int count)                      { _cellCount = count; }
    void setPointsOffset(size_t offset)               { _pointsOffset = offset; }
    void setCellsOffset(size_t offset)                { _cellsOffset = offset; }
    void setPointDataOffset(size_t offset)            { _pointDataOffset = offset; }
    void setMetadata(const std::string& gridFileName,
                     const std::string& dataFileName,
                     int pointCount,
                     int cellCount,
                     size_t pointsOffset,
                     size_t cellsOffset,
                     size_t pointDataOffset);
    void setOutputData(TetraGridData* data) { _outData = data; }

    void update();

private:
    std::string    _gridFileName;
    std::string    _dataFileName;
    int            _pointCount;
    int            _cellCount;
    size_t         _pointsOffset;
    size_t         _cellsOffset;
    size_t         _pointDataOffset;
    TetraGridData* _outData;
};

} // namespace v3d

#endif // V3D_DATA_TETRAGRIDLOADER_H
