#ifndef V3D_DATA_DATAUTILGL_H_
#define V3D_DATA_DATAUTILGL_H_

#include <cassert>

#include "v3d/Data/DataUtil.h"
#include "v3d/Util/GLConfig.h"

namespace v3d {

inline GLenum glType(Type type)
{
    switch (type) {
        case V3D_UNSIGNED_BYTE:  return GL_UNSIGNED_BYTE;
        case V3D_BYTE:           return GL_BYTE;
        case V3D_UNSIGNED_SHORT: return GL_UNSIGNED_SHORT;
        case V3D_SHORT:          return GL_SHORT;
        case V3D_UNSIGNED_INT:   return GL_UNSIGNED_INT;
        case V3D_INT:            return GL_INT;
        case V3D_FLOAT:          return GL_FLOAT;
        case V3D_DOUBLE:         return GL_DOUBLE;
        default:                 assert(false); return GL_UNSIGNED_BYTE;
    }
}

} // namespace v3d

#endif // V3D_DATA_DATAUTILGL_H_
