#ifndef V3D_DATA_REGULARGRID_H_
#define V3D_DATA_REGULARGRID_H_

#include "v3d/Util/Vector.h"

namespace v3d {

/**
 * @brief Defines geometric properties of a rectilinear uniform volume. This
 * class is being used by the v3d::RegularGridData class and the
 * v3d::RegularGridDataGL class.
 */
class RegularGrid {
public:
    /**
     * @name Special Functions
     * @note The class is movable and copyable
     */
    ///@{
    virtual ~RegularGrid();
    RegularGrid(const RegularGrid&);
    RegularGrid& operator=(const RegularGrid&);
    RegularGrid(RegularGrid&&) noexcept;
    RegularGrid& operator=(RegularGrid&& other) noexcept;
    RegularGrid();
    RegularGrid(const ivec3& dim, const vec3& origin, const vec3& spacing);
    ///@}

    /** @name Getter */
    ///@{
    vec3i dimensions() const;
    vec3f origin() const;
    vec3f spacing() const;
    vec3f extent() const;
    ///@}

    /** @name Setter */
    ///@{
    void setDimensions(const ivec3& dim);
    void setOrigin(const vec3& origin);
    void setSpacing(const vec3& spacing);
    ///@}

    /** @name Read-Only Information */
    ///@{
    /** @brief access the number of grid points */
    size_t pointCount() const;
    /** @brief access the number of grid cells */
    size_t cellCount() const;
    /** @brief access the number of voxels */
    size_t voxelCount() const;
    /**
     * @brief Check if the dimension is valid
     * @return True if the grid has non-zero dimensionality
     */
    bool hasValidDimension() const
    {
        return (_dim.x > 0) && (_dim.y > 0) && (_dim.z > 0);
    }
    /**
     * @brief Access medium bounding box
     * @return
     */
    box3f getBoundingBox() const { return { origin(), origin() + extent() }; }
    ///@}

protected:
    vec3i _dim;     ///< point dimension rather than cell dimension
    vec3f _origin;  ///< the coordinate of [0,0,0]
    vec3f _spacing; ///< the size of a voxel
};

inline void RegularGrid::setDimensions(const ivec3& dim) { _dim = dim; }
inline void RegularGrid::setOrigin(const vec3& origin) { _origin = origin; }
inline void RegularGrid::setSpacing(const vec3& spacing) { _spacing = spacing; }

inline vec3i RegularGrid::dimensions() const { return _dim; }
inline vec3f RegularGrid::origin() const { return _origin; }
inline vec3f RegularGrid::spacing() const { return _spacing; }
inline vec3f RegularGrid::extent() const
{
    return vec3(_dim - vec3i(1)) * _spacing;
}

} // namespace v3d

#endif // V3D_DATA_REGULARGRID_H_
