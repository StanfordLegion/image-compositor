#ifndef V3D_DATA_REGULARGRADIENTFILTER_H_
#define V3D_DATA_REGULARGRADIENTFILTER_H_

#include "v3d/Util/Vector.h"

namespace v3d {

class RegularGradientFilter {
public:
    RegularGradientFilter();

    static void filter(const float* data, const ivec3& dim,
                       const vec3& gridSpacing, bool normalized,
                       vec3* gradient);

    static void testFilter(const float* data, const ivec3& dim, vec3* gradient);

private:
    const float* _inData;

    vec3* _outGradient;
    ivec3 _dim;
    vec3  _gridSpacing;
    bool  _normalized;
};

////////////////////////////////////////////////////////////////////////////////

class RegularHessianFilter {
public:
    RegularHessianFilter();

    static void filter(const float* data, const ivec3& dim,
                       const vec3& gridSpacing, float* d2fdx2, float* d2fdxy,
                       float* d2fdxz, float* d2fdy2, float* d2fdyz,
                       float* d2fdz2);
};

} // namespace v3d

#endif // V3D_DATA_REGULARGRADIENTFILTER_H_
