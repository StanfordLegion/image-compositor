#ifndef V3D_DATA_TETRAGRID_H_
#define V3D_DATA_TETRAGRID_H_

#include <cassert>
#include <memory>

#include "v3d/Util/Box.h"
#include "v3d/Util/Vector.h"


namespace v3d {

class TetraGrid;
class TetraBoundaryMesh;
struct TetraGrid_InternalData;

////////////////////////////////////////////////////////////////////////////////

/**
  * @brief This class defines the internal data structure for v3d::TetraGrid. This class is not copyable but
  * v3d::TetraGrid holds a shared pointer to it to make itself copyable.
  */
struct TetraGrid_InternalData {
    /** @name Special Functions
     *  @note This class is a value class that can be moved but not copied
     */
    ///@{
    virtual ~TetraGrid_InternalData() = default;
    TetraGrid_InternalData(const TetraGrid_InternalData &) = delete;
    TetraGrid_InternalData &operator=(const TetraGrid_InternalData &other) = delete;
    TetraGrid_InternalData(TetraGrid_InternalData &&other) noexcept
        : _points{ std::move(other._points) },
          _cells{ std::move(other._cells) },
          _cellConns{ std::move(other._cellConns) }
    {
    }
    TetraGrid_InternalData &operator=(TetraGrid_InternalData &&other) noexcept
    {
        if (&other != this) {
            _points = std::move(other._points);
            _cells = std::move(other._cells);
            _cellConns = std::move(other._cellConns);
        }
        return *this;
    }
    ///@}

    /** @name Constructors */
    ///@{
    TetraGrid_InternalData() = default;
    ///@}

    std::unique_ptr<vec3[]> _points;     ///< point coordinates
    std::unique_ptr<ivec4[]> _cells;     ///< cell-to-point connectivity
    std::unique_ptr<ivec4[]> _cellConns; ///< cell-to-cell connectivity
};

////////////////////////////////////////////////////////////////////////////////

/**
 * @brief This class defines the basic geometry of a tetrahedron grid
 */
class TetraGrid: public std::enable_shared_from_this<TetraGrid> {
    friend class TetraBoundaryMesh;
public:
    /** @name Special Functions
     *  @note This class is a value class that can be moved and copied
     */
    ///@{
    virtual ~TetraGrid() = default;
    TetraGrid();
    TetraGrid(int pointCount, int cellCount);
    ///@}

    std::string toString() const { return "TetraGrid"; }

    /** @name Parameters */
    ///@{
    // TODO We should not change data using getter. Use setter instead
    vec3 *points()             { return _internal->_points.get(); } // TODO should not use raw pointers
    const vec3 *points() const { return _internal->_points.get(); }
    void setPoints(std::unique_ptr<vec3[]> &&points, int pointCount);
    ivec4 *cells()             { return _internal->_cells.get(); }
    const ivec4 *cells() const { return _internal->_cells.get(); }
    void setCells(std::unique_ptr<ivec4[]> &&cells, int cellCount);
    ///@}

    /** @name Read-Only Properties */
    ///@{
    size_t pointCount() const
    {
        assert(_pointCount >= 0);
        return size_t(_pointCount);
    }
    size_t cellCount() const
    {
        assert(_cellCount >= 0);
        return size_t(_cellCount);
    }
    const ivec4 *cellConnections() const { return _internal->_cellConns.get(); }
    const TetraBoundaryMesh *boundaryMesh() const { return _boundaryMesh.get(); }
    box3f getBoundingBox() const;
    ///@}
    
    /** @name Data Allocation Methods */
    ///@{
    void allocatePoints(int pointCount);
    void allocateCells(int cellCount);
    void allocateCellConnections();
    virtual void allocateBoundaryMesh(int triangleCount);
    ///@}
    
    /** 
     * @brief Correct the cells' vertex order.
     * Makes the vertex order of the cells following right hand rule.
     * If it is not sure if the orders are all correct, call this function
     * first.
     * Returns the number of corrected cells.
     */
    int correctVertexOrder();

    /** 
     * @brief Build cell-to-cell connectivity.
     * The cell-to-cell connections are constructed in the following format:
     * _cellConns[cid][f] is the the neighbor cell id of the cell cid, sharing
     * the face f of the cell cid. f is in [0, 3]. face f represents the face
     * that consists of the vertices of the cell excluding vertex f.
     */
    void buildCellToCellConnectivity();

    /** 
     * @brief Build the boundary triangular mesh of the grid.
     */
    void buildBoundaryMesh();

protected:
    /** @name Internal Setters */
    ///@{
    void setBoundaryMesh(std::shared_ptr<TetraBoundaryMesh> &&mesh)
    {
        _boundaryMesh = std::move(mesh);
    }
    ///@}

    /** 
     * @brief A shared reference to the TetraBoundaryMesh object since multiple
     * TetraGrids can share one single TetraBoundaryMesh object
     */
    std::shared_ptr<TetraBoundaryMesh> _boundaryMesh;

private:
    // TODO Workaround! It makes sense to use a shared_ptr, but this requires some advanced c17 features.
    std::shared_ptr<TetraGrid_InternalData> _internal;
    int _pointCount; // TODO change them to size_t to avoid potential data overflow
    int _cellCount;
};

////////////////////////////////////////////////////////////////////////////////

class TetraBoundaryMesh {
    friend class TetraGrid;
public:
    /** @name Special Functions
     *  @note This class is movable but not copyable because it contains data
     */
    ///@{
    virtual ~TetraBoundaryMesh() = default;
    TetraBoundaryMesh(const TetraBoundaryMesh &) = delete;
    TetraBoundaryMesh &operator=(const TetraBoundaryMesh &other) = delete;
    TetraBoundaryMesh(TetraBoundaryMesh &&other) noexcept;
    TetraBoundaryMesh &operator=(TetraBoundaryMesh &&other) noexcept;
    ///@}

    /** @name Constructors */
    ///@{
    explicit TetraBoundaryMesh(std::weak_ptr<TetraGrid> grid_);
    ///@}

    /** @name Read-Only Properties */
    ///@{
    const ivec3 *triangles() const { return _triangles.get(); }
    const int   *cellIds()   const { return _cellIds.get(); }
    const vec3  *vertices()  const { return _vertices.get(); }
    const vec3  *normals()   const { return _normals.get(); }
    int triangleCount()      const { return _triangleCount; }
    int vertexCount()        const { return _vertexCount; }
    ///@}

    /** @name Others */
    ///@{
    void allocateTriangles(int triangleCount);
    void allocateVertices(int vertexCount);
    void computeNormals() { computeNormalsSmooth(); }
    void computeNormalsFlat();
    void computeNormalsSmooth();
    ///@}

protected:
    /** @name Internal Getters */
    ///@{
    ivec3 *triangles() { return _triangles.get(); }
    int   *cellIds()   { return _cellIds.get(); }
    vec3  *vertices()  { return _vertices.get(); }
    vec3  *normals()   { return _normals.get(); }
    ///@}

private:
    std::weak_ptr<TetraGrid> _tetraGrid;
    std::unique_ptr<ivec3[]> _triangles; ///< use original point indices
    std::unique_ptr<int[]> _cellIds;   ///< per-triangle cell id
    std::unique_ptr<vec3[]> _vertices;
    std::unique_ptr<vec3[]> _normals;
    int _triangleCount;
    int _vertexCount;
};

} // namespace v3d

#endif // V3D_DATA_TETRAGRID_H_
