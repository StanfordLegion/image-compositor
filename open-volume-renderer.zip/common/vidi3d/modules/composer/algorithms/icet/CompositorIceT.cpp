#include "CompositorIceT.h"
#include <IceT.h>
#include <IceTMPI.h>
#include <map>
#include <vector>
#include <vidiBase.h>
#include <vidiMPI.h>

#define log vidi::lognull

using vidi::Exception;
using vidi::mpi::GetRank;
using vidi::mpi::GetSize;

static std::vector<v3d::Tile> globalTileList;

namespace v3d {
namespace composer {

class Compositor_IceT::impl /*: public Compositor*/ {
public:
    /// Constructor
    impl(int _mpiRank, int _mpiSize, const int& width, const int& height);
    impl(int _mpiRank, int _mpiSize);
    ~impl();

    /// Status
    bool isValid() const;

    /// Function to get final results
    const void* mapDepthBuffer() const;
    const void* mapColorBuffer() const;
    void        unmap(const void* mappedMem) const;

    /// Upload tile
    void setFrameSize(int w, int h);
    void setTile(Tile& tile);

    /// Clear (the specified channels of) this frame buffer
    void clear(uint32_t channelFlags);

    /// Begin frame
    void beginFrame();

    /// End frame
    void endFrame();

private:
    void initialize(uint32_t w, uint32_t h);
    void composite(float*& output);
    void addTile(const Tile& tile);
    void setBox(const Tile& tile);

    static void callback(const IceTDouble*,
                         const IceTDouble*,
                         const IceTFloat*,
                         const IceTInt*,
                         IceTImage img);

    static IceTEnum strategy();

private:
    int _mpiRank;
    int _mpiSize;
    //-----------------------------------------------------//
    uint32_t _fb_w, _fb_h;
    float*   _rgba  = nullptr;
    float*   _depth = nullptr; // TODO unused
    //-----------------------------------------------------//
    IceTInt          _icet_screen[2] = { 0, 0 };
    IceTContext      _icet_currContext, _icet_prevContext;
    IceTCommunicator _icet_comm;
    IceTImage        _icet_result = { nullptr };
    //-----------------------------------------------------//
    static const float* _icet_tileData;
    static int          _icet_tilePos[2];
    static int          _icet_tileDim[2];
    //-----------------------------------------------------//
};

const float* Compositor_IceT::impl::_icet_tileData   = nullptr;
int          Compositor_IceT::impl::_icet_tilePos[2] = { 0, 0 };
int          Compositor_IceT::impl::_icet_tileDim[2] = { 0, 0 };

IceTEnum
Compositor_IceT::impl::strategy()
{
    static IceTEnum ret;
    static bool     first = true;
    if (first)
    {
        long int    strategy          = 1;
        const char* env_icet_strategy = std::getenv("ICET_STRATEGY");
        if (env_icet_strategy)
        {
            strategy = strtol(env_icet_strategy, nullptr, 0);
        }
        switch (strategy)
        {
        case 0:
            ret = ICET_STRATEGY_REDUCE;
            break;
        case 1:
            ret = ICET_SINGLE_IMAGE_STRATEGY_TREE;
            break;
        case 2:
            ret = ICET_SINGLE_IMAGE_STRATEGY_RADIXK;
            break;
        default:
            ret = ICET_SINGLE_IMAGE_STRATEGY_BSWAP;
            break;
        }
        first = false;
    }
    return ret;
}

void
Compositor_IceT::impl::initialize(uint32_t w, uint32_t h)
{
    // Initialization
    if (_mpiRank == 0)
        log() << "[IceT] Init Start";
    _icet_screen[0] = w;
    _icet_screen[1] = h;

    // Setup IceT parameters
    icetCompositeMode(ICET_COMPOSITE_MODE_BLEND);
    icetSetColorFormat(ICET_IMAGE_COLOR_RGBA_FLOAT);
    icetSetDepthFormat(ICET_IMAGE_DEPTH_NONE);
    icetEnable(ICET_ORDERED_COMPOSITE);
    icetDisable(ICET_INTERLACE_IMAGES);

    // Safety
    MPI_Barrier(MPI_COMM_WORLD);
    if (_mpiRank == 0)
        log() << " ... Done" << std::endl;
}

void
Compositor_IceT::impl::composite(float*& output)
{
    static const IceTDouble identity[16] = { IceTDouble(1.0), IceTDouble(0.0), IceTDouble(0.0),
                                             IceTDouble(0.0), IceTDouble(0.0), IceTDouble(1.0),
                                             IceTDouble(0.0), IceTDouble(0.0), IceTDouble(0.0),
                                             IceTDouble(0.0), IceTDouble(1.0), IceTDouble(0.0),
                                             IceTDouble(0.0), IceTDouble(0.0), IceTDouble(0.0),
                                             IceTDouble(1.0) };
    static const IceTFloat  bgColor[4]   = {
        IceTFloat(0.0f), IceTFloat(0.0f), IceTFloat(0.0f), IceTFloat(0.0f)
    };
    if (_mpiRank == 0)
        log() << "[IceT] Composite";
    _icet_result = icetDrawFrame(identity, identity, bgColor);
    if (_mpiRank == 0)
        icetImageCopyColorf(_icet_result, output, ICET_IMAGE_COLOR_RGBA_FLOAT);
    if (_mpiRank == 0)
        log() << " ... Done" << std::endl;
}

void
Compositor_IceT::impl::addTile(const Tile& tile)
{
    // Gather depths
    std::vector<float>   all_depths(static_cast<size_t>(_mpiSize));
    std::vector<IceTInt> all_orders(static_cast<size_t>(_mpiSize));
    if (_mpiRank == 0)
        log() << "[IceT] SetTile Gather Depth";
    if (tile.isReducedDepth())
    {
        MPI_Allgather(tile._depth, 1, MPI_FLOAT, all_depths.data(), 1, MPI_FLOAT, MPI_COMM_WORLD);
    }
    else
    {
        throw Exception("Tile is not in reduced depth mode");
    }
    if (_mpiRank == 0)
        log() << " ... Done" << std::endl;

    // Sort depths in composition order
    if (_mpiRank == 0)
    {
        log() << "[IceT] SetTile Sort Depths";
    }
    std::multimap<float, int> ordered_depths;
    for (int i = 0; i < _mpiSize; i++)
    {
        ordered_depths.insert(std::pair<float, int>(all_depths[i], i));
    }
    int i = 0;
    for (auto&& it : ordered_depths)
    {
        all_orders[i] = it.second;
        i++;
    }
    icetCompositeOrder(all_orders.data());
    if (_mpiRank == 0)
    {
        log() << " ... Done" << std::endl;
    }

    // Set IceT Tile Information
    icetResetTiles();
    icetAddTile(0, 0, _icet_screen[0], _icet_screen[1], 0);
    icetPhysicalRenderSize(_icet_screen[0], _icet_screen[1]);

    // Composite Strategy
    const auto method = strategy();
    if (_mpiRank == 0)
    {
        switch (method)
        {
        case 0:
            log() << "[IceT] Strategy Reduce" << std::endl;
            break;
        case 1:
            log() << "[IceT] Strategy Tree" << std::endl;
            break;
        case 2:
            log() << "[IceT] Strategy Radix-k" << std::endl;
            break;
        default:
            log() << "[IceT] Strategy BSwap" << std::endl;
            break;
        }
    }
    if (method == ICET_STRATEGY_REDUCE)
    {
        icetStrategy(ICET_STRATEGY_REDUCE);
    }
    else
    {
        icetStrategy(ICET_STRATEGY_SEQUENTIAL);
        icetSingleImageStrategy(method);
    }
}

void
Compositor_IceT::impl::setBox(const Tile& tile)
{
    // Bounding Box
    icetBoundingBoxf(((float)tile._tilePos4i[0] / (_icet_screen[0] - 1) - 0.5f) * 2.f,
                     ((float)(tile._tilePos4i[2] - 1) / (_icet_screen[0] - 1) - 0.5f) * 2.f,
                     ((float)tile._tilePos4i[1] / (_icet_screen[1] - 1) - 0.5f) * 2.f,
                     ((float)(tile._tilePos4i[3] - 1) / (_icet_screen[1] - 1) - 0.5f) * 2.f,
                     0.0,
                     0.0);

    auto* ptr = new float[4 * _fb_w * _fb_h];
    for (auto i = 0; i < tile._tileSize; ++i)
    {
        ptr[4 * i + 0] = tile._r[i];
        ptr[4 * i + 1] = tile._g[i];
        ptr[4 * i + 2] = tile._b[i];
        ptr[4 * i + 3] = tile._a[i];
    }

    // Compose
    Compositor_IceT::impl::_icet_tileData   = ptr;
    Compositor_IceT::impl::_icet_tilePos[0] = tile._tilePos4i[0];
    Compositor_IceT::impl::_icet_tilePos[1] = tile._tilePos4i[1];
    Compositor_IceT::impl::_icet_tileDim[0] = tile._tileDim[0];
    Compositor_IceT::impl::_icet_tileDim[1] = tile._tileDim[1];
    icetDrawCallback(callback);
}

void
Compositor_IceT::impl::callback(const IceTDouble*,
                                const IceTDouble*,
                                const IceTFloat*,
                                const IceTInt*,
                                IceTImage img)
{
    float* o = icetImageGetColorf(img);

    const int outputStride = icetImageGetWidth(img);

    for (int j = 0; j < _icet_tileDim[1]; ++j)
    {
        for (int i = 0; i < _icet_tileDim[0]; ++i)
        {
            const int gIdx  = i + _icet_tilePos[0] + (j + _icet_tilePos[1]) * outputStride;
            const int lIdx  = i + j * _icet_tileDim[0];
            o[4 * gIdx + 0] = _icet_tileData[4 * lIdx + 0];
            o[4 * gIdx + 1] = _icet_tileData[4 * lIdx + 1];
            o[4 * gIdx + 2] = _icet_tileData[4 * lIdx + 2];
            o[4 * gIdx + 3] = _icet_tileData[4 * lIdx + 3];
        }
    }
}

///////////////////////////////////////////////////////////////////////////////

Compositor_IceT::impl::impl(int mpiRank, int mpiSize, const int& width, const int& height)
  : _mpiRank(mpiRank), _mpiSize(mpiSize)
{
    setFrameSize(width, height);
    _icet_prevContext = icetGetContext();
    _icet_comm        = icetCreateMPICommunicator(MPI_COMM_WORLD);
    _icet_currContext = icetCreateContext(_icet_comm);
    icetDestroyMPICommunicator(_icet_comm);
}

Compositor_IceT::impl::impl(int mpiRank, int mpiSize) : _mpiRank(mpiRank), _mpiSize(mpiSize)
{
    _icet_prevContext = icetGetContext();
    _icet_comm        = icetCreateMPICommunicator(MPI_COMM_WORLD);
    _icet_currContext = icetCreateContext(_icet_comm);
    icetDestroyMPICommunicator(_icet_comm);
}

Compositor_IceT::impl::~impl()
{
    // cleanup icet
    icetDestroyContext(_icet_currContext);
    icetSetContext(_icet_prevContext);
    // delete data
    if (_mpiRank == 0)
    {
        if (_rgba)
            delete[] _rgba;
    }
}

bool
Compositor_IceT::impl::isValid() const
{
    return true;
}

const void*
Compositor_IceT::impl::mapDepthBuffer() const
{
    return _depth;
}

const void*
Compositor_IceT::impl::mapColorBuffer() const
{
    return _rgba;
}

void
Compositor_IceT::impl::unmap(const void* mappedMem) const
{
}

void
Compositor_IceT::impl::clear(const uint32_t channelFlags)
{
}

void
Compositor_IceT::impl::beginFrame()
{
    initialize(_fb_w, _fb_h);
}

void
Compositor_IceT::impl::endFrame()
{
    composite(_rgba);
};

void
Compositor_IceT::impl::setFrameSize(int w, const int h)
{
    _fb_w = (uint32_t)w;
    _fb_h = (uint32_t)h;
    if (_mpiRank == 0)
    {
        _rgba = new float[4 * _fb_w * _fb_h]();
    }
}

void
Compositor_IceT::impl::setTile(Tile& tile)
{
    addTile(tile);
    setBox(tile);
    globalTileList.emplace_back(std::move(tile));
};

///////////////////////////////////////////////////////////////////////////////

Compositor_IceT::~Compositor_IceT() = default;

Compositor_IceT::Compositor_IceT(Compositor_IceT&&) noexcept = default;

Compositor_IceT& Compositor_IceT::operator=(Compositor_IceT&&) noexcept = default;

Compositor_IceT::Compositor_IceT(const Compositor_IceT& other)
  : Compositor(other), pimpl{ new impl(*(other.pimpl)) }
{
}

Compositor_IceT&
Compositor_IceT::operator=(const Compositor_IceT& rhs)
{
    if (this != &rhs)
    {
        pimpl.reset(new impl(*rhs.pimpl));
    }
    return *this;
}

Compositor_IceT::Compositor_IceT(const int& width, const int& height)
  : Compositor(), pimpl{ new impl(GetRank(), GetSize(), width, height) }
{
}

Compositor_IceT::Compositor_IceT() : Compositor(), pimpl{ new impl(GetRank(), GetSize()) }
{
}

bool
Compositor_IceT::isValid() const
{
    return pimpl->isValid();
}

const void*
Compositor_IceT::mapDepthBuffer() const
{
    return pimpl->mapDepthBuffer();
}

const void*
Compositor_IceT::mapColorBuffer() const
{
    return pimpl->mapColorBuffer();
}

void
Compositor_IceT::unmap(const void* mappedMem) const
{
    pimpl->unmap(mappedMem);
}

void
Compositor_IceT::setFrameSize(int w, int h)
{
    pimpl->setFrameSize(w, h);
}

void
Compositor_IceT::setTile(Tile& tile)
{
    pimpl->setTile(tile);
}

void
Compositor_IceT::clear(uint32_t channelFlags)
{
    pimpl->clear(channelFlags);
}

void
Compositor_IceT::beginFrame()
{
    pimpl->beginFrame();
}

void
Compositor_IceT::endFrame()
{
    pimpl->endFrame();
}

} // namespace composer
} // namespace v3d

V3D_REGISTER_COMPOSER(::v3d::composer::Compositor_IceT, icet)
