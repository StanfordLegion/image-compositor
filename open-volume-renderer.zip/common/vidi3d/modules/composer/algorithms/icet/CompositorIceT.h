#ifndef V3D_COMPOSER_ALGO_ICET_H
#define V3D_COMPOSER_ALGO_ICET_H

#include "Compositor.h"
#include <memory>

namespace v3d {
namespace composer {

class Compositor_IceT : public Compositor {
public:
    /**
     * @name Special Functions
     * @note The class is copyable and movable
     */
    ///@{
    ~Compositor_IceT() override;
    Compositor_IceT(const Compositor_IceT&);
    Compositor_IceT& operator=(const Compositor_IceT&);
    Compositor_IceT(Compositor_IceT&&) noexcept;
    Compositor_IceT& operator=(Compositor_IceT&&) noexcept;
    Compositor_IceT(const int& width, const int& height);
    Compositor_IceT();
    ///@}

    //! status
    bool isValid() const override;

    //! function to get final results
    const void* mapDepthBuffer() const override;
    const void* mapColorBuffer() const override;
    void        unmap(const void* mappedMem) const override;

    //! upload tile
    void setFrameSize(int, int) override;
    void setTile(Tile& tile) override;

    //! clear (the specified channels of) this frame buffer
    void clear(uint32_t channelFlags) override;

    //! begin frame
    void beginFrame() override;

    //! end frame
    void endFrame() override;

private:
    class impl;
    std::unique_ptr<impl> pimpl;
};

} // namespace composer
} // namespace v3d

#endif // V3D_COMPOSER_ALGO_ICET_H
