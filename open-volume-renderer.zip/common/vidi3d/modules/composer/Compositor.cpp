// ======================================================================== //
// Copyright SCI Institute, University of Utah, 2018
// ======================================================================== //

#include "Compositor.h"

namespace v3d {
Compositor::Compositor()  = default;
Compositor::~Compositor() = default;
} // namespace v3d

REGISTER_TYPE(_, ::v3d::Compositor, "v3d_composer")

std::shared_ptr<v3d::Compositor>
v3d::CreateComposer(const std::string& name, int width, int height)
{
    vidi::dynamic::LibraryRepository::GetInstance()->add("v3d_composer");
    auto composer = vidi::dynamic::details::objectFactory<Compositor>(name);
    composer->setFrameSize(width, height);
    return composer;
}
