// ======================================================================== //
// Copyright SCI Institute, University of Utah, 2018
// ======================================================================== //

#ifndef V3D_COMPOSER_TILE_H
#define V3D_COMPOSER_TILE_H

#include <vidiMath.h>

#include <array>
#include <cmath>

#define QCT_TILE_SHARED (1 << 0)
#define QCT_TILE_FORMAT_SOA (1 << 1)
#define QCT_TILE_REDUCED_DEPTH (1 << 2)
#define QCT_TILE_FLOATING_BBOX (1 << 4)

namespace v3d {

using vidi::vec2i;
using vidi::vec4f;
using vidi::vec4i;

class Tile {
public:
    //
    uint32_t _flag{ 0 };         ///< register flag
    vec2i    _screenDim{ 0, 0 }; ///< total frame buffer size, for the camera
    union {
        vec4i _tilePos4i; ///< screen region that this tile corresponds to
                          ///< x0 y0 x1 y1
        vec4f _tilePos4f; ///< screen region that this tile corresponds to
                          ///< x0 y0 x1 y1
    };
    vec2i    _tileDim{ 0, 0 }; ///< tile size
    uint32_t _tileSize{ 0 };   ///< number of pixels in this tile

    // 'rgba' component; in float.
    float* _rgba;
    float* _r;
    float* _g;
    float* _b;
    float* _a;
    // 'depth' component; in float.
    float* _depth = nullptr;

public:
    ~Tile();
    Tile(const vec4i& region,
         const vec2i& fbSize,
         float*       rptr,
         float*       gptr,
         float*       bptr,
         float*       aptr,
         float*       depth,
         uint32_t     flag = 0);
    Tile(const vec4i& region, const vec2i& fbSize, float* color, float* depth, uint32_t flag = 0);

    bool isReducedDepth() const;

private:
    Tile(const vec4i& region, const vec2i& fbSize, uint32_t flag);
    Tile(const vec4f& bounds, const vec2i& fbSize, uint32_t flag);

    void fromSeparateChannels(float* rptr, float* gptr, float* bptr, float* aptr);
    void fromMergedChannels(float* color);
    void allocateColor();
    void allocateDepth();
    void clean();
    void bind();
    void setDepth(float* depth);
};

};     // namespace v3d
#endif // V3D_COMPOSER_TILE_H
