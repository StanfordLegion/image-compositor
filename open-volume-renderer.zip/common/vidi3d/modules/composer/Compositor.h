// ======================================================================== //
// Copyright SCI Institute, University of Utah, 2018
// ======================================================================== //

#ifndef V3D_COMPOSER_COMPOSITOR_H
#define V3D_COMPOSER_COMPOSITOR_H

#include <v3d_composer_export.h>

#include "Tile.h"

#include <vidiDynamic.h>

namespace v3d {

/**
 * @brief Abstract API for image composition
 * */
class Compositor : public vidi::dynamic::TraitExternallyNamed {
public:
    //! constructor & destructor
    Compositor();
    virtual ~Compositor();

    //! status
    virtual bool isValid() const = 0;

    //! function to get final results
    virtual const void* mapDepthBuffer() const             = 0;
    virtual const void* mapColorBuffer() const             = 0;
    virtual void        unmap(const void* mappedMem) const = 0;

    //! upload tile
    virtual void setFrameSize(int, int) = 0;
    virtual void setTile(Tile& tile)    = 0;

    //! clear (the specified channels of) this frame buffer
    virtual void clear(uint32_t channelFlags) = 0;

    //! begin frame
    virtual void beginFrame() = 0;

    //! end frame
    virtual void endFrame() = 0;
};

std::shared_ptr<Compositor> CreateComposer(const std::string& name, int width, int height);

} // namespace v3d

#define V3D_REGISTER_COMPOSER(InternalClass, external_name) \
    VIDI_REGISTER_OBJECT(::v3d::Compositor, v3d_composer, InternalClass, external_name)

#endif // V3D_COMPOSER_COMPOSITOR_H
