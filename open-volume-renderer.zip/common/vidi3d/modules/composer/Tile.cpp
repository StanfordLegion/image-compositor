// ======================================================================== //
// Copyright SCI Institute, University of Utah, 2018
// ======================================================================== //

#include "Tile.h"
#include <iostream>
#include <vidiBase.h>

using vidi::warn;

namespace v3d {

///////////////////////////////////////////////////////////////////////////////

Tile::~Tile() = default;

Tile::Tile(const vec4i& region, const vec2i& fbSize, uint32_t flag)
  : _flag(flag)
  , _screenDim(fbSize)
  , _tilePos4i(region)
  , _tileDim(region[2] - region[0], region[3] - region[1])
  , _tileSize((uint32_t)_tileDim[0] * (uint32_t)_tileDim[1])
{
}

Tile::Tile(const vec4f& region, const vec2i& fbSize, uint32_t flag)
  : _flag(flag | QCT_TILE_FLOATING_BBOX)
  , _screenDim(fbSize)
  , _tilePos4f(region)
  , _tileDim((region[2] - region[0]) * fbSize[0], (region[3] - region[1]) * fbSize[1])
  , _tileSize((uint32_t)fbSize[0] * (uint32_t)fbSize[1])
{
}

///////////////////////////////////////////////////////////////////////////////

void
Tile::allocateColor()
{
    _rgba = new float[_tileSize * 4];
    bind();
}

void
Tile::allocateDepth()
{
    if (_flag & QCT_TILE_REDUCED_DEPTH)
    {
        _depth = new float();
    }
    else
    {
        _depth = new float[_tileSize];
    }
}

void
Tile::clean()
{
    if (!(_flag & QCT_TILE_SHARED))
    {
        if (_rgba)
            delete[] _rgba;
    }
    if (_flag & QCT_TILE_REDUCED_DEPTH)
    {
        if (_depth)
            delete _depth;
    }
    else
    {
        if (_depth)
            delete[] _depth;
    }
}

void
Tile::bind()
{
    _r = &(_rgba[0]);
    _g = &(_rgba[_tileSize]);
    _b = &(_rgba[_tileSize + _tileSize]);
    _a = &(_rgba[_tileSize + _tileSize + _tileSize]);
}

void
Tile::setDepth(float* d)
{
    /**
     * We support two modes here, one mode stores only one float
     * as tile depth, the other mode stores an depth buffer since
     * each pixel can have different depths
     */
    if (_flag & QCT_TILE_REDUCED_DEPTH)
    {
        _depth = new float(*d);
    }
    else
    { // per-pixel depth
        _depth = new float[_tileSize];
        std::copy(d, d + _tileSize, _depth);
    }
}

void
Tile::fromSeparateChannels(float* rptr, float* gptr, float* bptr, float* aptr)
{
    /** Check if we need to do deep copy of the image data */
    if (_flag & QCT_TILE_SHARED)
    {
        warn() << "The tile cannot be shared because an RGBA image in an SOA "
                  "is required"
               << std::endl;
        _flag ^= QCT_TILE_SHARED; // remove flag
    }
    allocateColor();
    // we hope the compiler is smart enough here
    std::copy(rptr, rptr + _tileSize, _rgba + 0);
    std::copy(gptr, gptr + _tileSize, _rgba + _tileSize);
    std::copy(bptr, bptr + _tileSize, _rgba + _tileSize * 2);
    std::copy(aptr, aptr + _tileSize, _rgba + _tileSize * 3);
}

void
Tile::fromMergedChannels(float* color)
{
    /**
     * Because we are having different data structures, we have to do deep
     * copy here
     */
    if (_flag & QCT_TILE_FORMAT_SOA)
    {
        if (_flag & QCT_TILE_SHARED)
        {
            this->_rgba = color;
        }
        else
        {
            allocateColor();
            std::copy(color, color + _tileSize * 4, _rgba);
        }
    }
    else
    {
        allocateColor();
        for (auto i = 0; i < _tileSize; ++i)
        { // TODO parallel this loop
            _rgba[i]                 = color[4 * i + 0];
            _rgba[_tileSize + i]     = color[4 * i + 1];
            _rgba[_tileSize * 2 + i] = color[4 * i + 2];
            _rgba[_tileSize * 3 + i] = color[4 * i + 3];
        }
    }
}

///////////////////////////////////////////////////////////////////////////////

Tile::Tile(const vec4i& region,
           const vec2i& fbSize,
           float*       rptr,
           float*       gptr,
           float*       bptr,
           float*       aptr,
           float*       depth,
           uint32_t     opt)
  : Tile(region, fbSize, opt)
{
    fromSeparateChannels(rptr, gptr, bptr, aptr);
    setDepth(depth);
}

Tile::Tile(const vec4i& region, const vec2i& fbSize, float* color, float* depth, uint32_t opt)
  : Tile(region, fbSize, opt)
{
    fromMergedChannels(color);
    setDepth(depth);
}

///////////////////////////////////////////////////////////////////////////////

bool
Tile::isReducedDepth() const
{
    return bool(_flag & QCT_TILE_REDUCED_DEPTH);
}

} // namespace v3d
