//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "Util/DXGL.h"

#include "v3d/Util/GLConfig.h"

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <cstdio>
#include <cstdlib>
#include <stdexcept>

static void
glfw_error_callback(int error, const char* description)
{
    fprintf(stderr, "Error: %s\n", description);
}

namespace v3d {

static GLFWwindow* handle{ nullptr };

int
DXGL_init(int argc, char* argv[])
{
    glfwSetErrorCallback(glfw_error_callback);
#if __APPLE__
    glfwInitHint(GLFW_COCOA_MENUBAR, GLFW_FALSE);
#endif

    if (!glfwInit())
        exit(EXIT_FAILURE);

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);

    /* dummy window */
    glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
    handle = glfwCreateWindow(100, 100, "", NULL, NULL);
    if (!handle) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwSetWindowUserPointer(handle, NULL);
    glfwMakeContextCurrent(handle);
    glfwSwapInterval(1);

    initGL();

    return 0;
}

int
DXGL_exit()
{
    glfwDestroyWindow(handle);
    glfwTerminate();
    return 0;
}

} // namespace v3d
