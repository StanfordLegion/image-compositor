//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson), Min Shih                                //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "DXGL.h"

#include "v3d/Renderer/Shader/Config.h"
#include "v3d/Util/Log.h"
#include "v3d/Util/SourceCodeManager.h"

#include <vidiBase.h>
#include <vidiDynamic.h>

#include <algorithm>
#include <fstream>
#include <string>
#include <vector>

using namespace v3d;

static std::string
path(std::string path)
{
#ifdef WIN32
    std::replace(path.begin(), path.end(), '/', '\\');
#else
    std::replace(path.begin(), path.end(), '\\', '/');
#endif
    return path;
}

static std::string
load_file(const std::string& fileName)
{
    std::ifstream ifs;
    // search for the shader file in both build directory and install directory
    ifs.open(path(std::string(ShaderBaseDir1) + "/" + fileName));
    if (!ifs.good()) {
        ifs.open(path(std::string(ShaderBaseDir0) + "/" + fileName));
    }
    if (!ifs.is_open()) {
        throw Exception("[error] Cannot open shader file \"" + fileName + "\"");
    }
    return std::string((std::istreambuf_iterator<char>(ifs)),
                       (std::istreambuf_iterator<char>()));
}

void
load_shaders()
{
    std::vector<std::string> fileNames = {
        "Shader/AdvancedRayCast.frag",
        "Shader/ModularRayCast.frag",
        "Shader/Occlusion.comp",
        "Shader/occlusionMake.comp",
        "Shader/PolyLighting.frag",
        "Shader/PolyLighting.vert",
        "Shader/PolySingleColor.frag",
        "Shader/PolySingleColor.vert",
        "Shader/Position.frag",
        "Shader/RayIntersect.frag",
        "Shader/RayIntersect.vert",
        "Shader/RegularGridRayCast.frag",
        "Shader/RegularGridRayCast.vert",
        "Shader/RegularGridSlice.frag",
        "Shader/RegularGridSlice.vert",
        "Shader/SimpleRegularGridRayCast.frag",
        "Shader/SimpleRegularGridRayCast.vert",
        "Shader/skipMake.comp",
        "Shader/TetraCellWalk.frag",
        "Shader/TetraCellWalk.vert",
        "Shader/TetraEntryExit.frag",
        "Shader/TetraEntryExit.vert",
        "Shader/TetraExit.frag",
        "Shader/TetraExit.vert",
        "Shader/TetraFar.frag",
        "Shader/TetraFar.vert",
        "Shader/TetraFirstEntry.frag",
        "Shader/TetraFirstEntry.vert",
        "Shader/TetraGridRayCast.frag",
        "Shader/TetraGridRayCast.vert",
        "Shader/parts/castRay.frag",
        "Shader/parts/castRay_emptySpaceSkipping.frag",
        "Shader/parts/exAmbOcclusion.frag",
        "Shader/parts/exAOasShadow.frag",
        "Shader/parts/exBPhong.frag",
        "Shader/parts/exLight.frag",
        "Shader/parts/exLightless.frag",
        "Shader/parts/exNoAO.frag",
        "Shader/parts/exNoShadow.frag",
        "Shader/parts/exPhong.frag",
        "Shader/parts/exSampling.frag",
        "Shader/parts/exShading.frag",
        "Shader/parts/exShadow.frag",
        "Shader/parts/Shadow_LightVolume.glsl",
        "Shader/parts/skip_homogeneous.comp",
        "Shader/parts/skip_transparent.comp",
        "Shader/parts/testShader.frag",
        "Shader/parts/TF_preint.frag",
        "Shader/parts/TF_regular.frag",
        "Shader/parts/TF_TF2D.glsl",
        "Shader/parts/TFelem_none.frag",
        "Shader/parts/TFelem_Phong.frag",
        "Shader/Module/CastRay.glsl",
        "Shader/Module/CastRay_EmptySpaceSkip.glsl",
        "Shader/Module/Classify_Preint.glsl",
        "Shader/Module/Classify_PreintShade.glsl",
        "Shader/Module/Classify_Shade.glsl",
        "Shader/Module/Classify_TF2D.glsl",
        "Shader/Module/Classify_TF2DShade.glsl",
        "Shader/Module/Data.glsl",
        "Shader/Module/Data_2D.glsl",
        "Shader/Module/Light.glsl",
        "Shader/Module/LightVolume.glsl",
        "Shader/Module/OcclusionVolume.glsl",
        "Shader/Module/RayStartDist_Preint.glsl",
        "Shader/Module/Shade.glsl",
        "Shader/Module/Shade_Preint.glsl",
        "Shader/Module/TF.glsl",
        "Shader/Module/TF_2D.glsl",
        "Shader/Module/TF_Preint.glsl",
        "Shader/Module/TricubicInterp.glsl"
    };
    for (auto& fn : fileNames) {
        auto srcCode = load_file(fn);
        v3d::SourceCodeManager::get().setSourceCode(fn, srcCode);
    }
}

int
v3d::DXGL_create()
{
    load_shaders();
    return 0;
}
