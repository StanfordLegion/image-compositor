//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson), Min Shih                                //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

// TODO expose our thread abstraction here ?

#ifndef DXSERVER_DXGL_H
#define DXSERVER_DXGL_H

#include <cstddef>
#include <functional>

namespace v3d {
int DXGL_create();
int DXGL_init(int argc, char* argv[]);
int DXGL_createLocalContext(int&);
int DXGL_lockContext(const int&);
int DXGL_unlockContext(const int&);
int DXGL_exit();
} // namespace v3d

#endif // DXSERVER_DXGL_H
