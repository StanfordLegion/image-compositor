//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "Util/DXGL.h"

#include "v3d/Util/GLConfig.h"

#define EGL_EGLEXT_PROTOTYPES
#include <EGL/egl.h>
#include <EGL/eglext.h>

#include <cstdio>
#include <cstdlib>

static const EGLint configAttribs[] = { EGL_SURFACE_TYPE,
                                        EGL_PBUFFER_BIT,
                                        EGL_BLUE_SIZE,
                                        8,
                                        EGL_GREEN_SIZE,
                                        8,
                                        EGL_RED_SIZE,
                                        8,
                                        EGL_DEPTH_SIZE,
                                        8,
                                        EGL_RENDERABLE_TYPE,
                                        EGL_OPENGL_BIT,
                                        EGL_NONE };

static const int pbufferWidth  = 9;
static const int pbufferHeight = 9;

static const EGLint pbufferAttribs[] = {
    EGL_WIDTH, pbufferWidth, EGL_HEIGHT, pbufferHeight, EGL_NONE,
};

namespace v3d {

static EGLDisplay eglDpy;
static EGLint     major, minor;
static EGLint     numConfigs;
static EGLConfig  eglCfg;
static EGLSurface eglSurf;
static EGLContext eglCtx;

void get_display(int i)
{
  static const int MAX_DEVICES = 4;
  EGLDeviceEXT eglDevs[MAX_DEVICES];
  EGLint numDevices;
  PFNEGLQUERYDEVICESEXTPROC eglQueryDevicesEXT =
    (PFNEGLQUERYDEVICESEXTPROC)eglGetProcAddress("eglQueryDevicesEXT");
  eglQueryDevicesEXT(MAX_DEVICES, eglDevs, &numDevices);
  printf("Detected %d Devices\n", numDevices);
  if (i >= numDevices)
  {
    printf("Incorrect device index %d, fallback to default device\n", i);
    i = 0;
  }
  printf("Using Device %d\n", i);
  PFNEGLGETPLATFORMDISPLAYEXTPROC eglGetPlatformDisplayEXT =
    (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
  eglDpy = eglGetPlatformDisplayEXT(EGL_PLATFORM_DEVICE_EXT, eglDevs[i], 0);
}
  
int
DXGL_init(int argc, char* argv[])
{
    // 1. Initialize EGL
    // https://github.com/Kitware/VTK/blob/master/Rendering/OpenGL2/vtkEGLRenderWindow.cxx
    int device_index = -1;
    if(const char* env_p = std::getenv("EGL_CURRENT_DEVICE"))
    {
      try
      {
        int index = std::atoi(env_p);
        if (index >= 0)
        {
          device_index = index;
        }
      }
      catch (const std::out_of_range&)
      {
      }
      catch(const std::invalid_argument&)
      {
      }
    }
    if (device_index >= 0)
      get_display(device_index);
    else
      eglDpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);

    // eglDpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(eglDpy, &major, &minor);

    // 2. Select an appropriate configuration
    eglChooseConfig(eglDpy, configAttribs, &eglCfg, 1, &numConfigs);

    // 3. Create a surface
    eglSurf = eglCreatePbufferSurface(eglDpy, eglCfg, pbufferAttribs);

    // 4. Bind the API
    eglBindAPI(EGL_OPENGL_API);

    // 5. Create a context and make it current
    eglCtx = eglCreateContext(eglDpy, eglCfg, EGL_NO_CONTEXT, NULL);
    eglMakeCurrent(eglDpy, eglSurf, eglSurf, eglCtx);

    // from now on use your OpenGL context
    // if (!gladLoadGL()) {
    //     printf("Something went wrong!\n");
    //     exit(-1);
    // }
    initGL();

    return 0;
}

int
DXGL_exit()
{
    // 6. Terminate EGL when finished
    eglTerminate(eglDpy);

    return 0;
}

} // namespace v3d
