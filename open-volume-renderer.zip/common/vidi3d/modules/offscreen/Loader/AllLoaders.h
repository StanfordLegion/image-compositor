//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#ifndef V3D_OFFSCREEN_ALLLOADERS_H
#define V3D_OFFSCREEN_ALLLOADERS_H

#include "Loader/Common.h"
#include "v3d/Util/JsonParser.h"

namespace v3d {

void RegularGridPtr(const JsonValue& json, vidi::Any);
void RegularGridRaw(const JsonValue& json, vidi::Any);

void TetraGridRaw(const JsonValue& json, vidi::Any);
void TetraGridHo(const JsonValue& json, vidi::Any);

} // namespace v3d

#endif // V3D_ALLLOADERS_H
