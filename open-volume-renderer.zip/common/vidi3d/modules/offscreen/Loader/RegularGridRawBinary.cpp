//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "AllLoaders.h"
#include "Common.h"
#include "OffScreenDictionary.h"

#include "v3d/Data/RegularGridLoader.h"
#include "v3d/Serializer/VectorSerializer.h"
#include "v3d/Serializer/VolumeSerializer.h"

using v3d::JsonParser;
using v3d::JsonValue;
using vidi::anyCast;

namespace v3d {

void
RegularGridRaw(const JsonValue& json, vidi::Any out)
{
    using namespace v3d::serializer;

    auto loader = std::make_shared<RegularGridLoader>();
    loader->setFileName(json.fetch(FILE_NAME).toString());
    loader->setOffset(size_t(json.fetch(OFFSET).toInt64()));
    loader->setDimensions(fromJson<ivec3>(json.fetch(DIMENSIONS)));
    loader->setType(typeFromJson(json.fetch(TYPE)));
    loader->setEndian(endianFromJson(json.fetch(ENDIAN)));
    loader->setFileUpperLeft(json.contains(FILE_UPPER_LEFT) ? json[FILE_UPPER_LEFT].toBool()
                                                            : false);

    auto* data = anyCast<RegularGridDataGL*>(out);
    loader->setOutputData(data);
    if (!loader->update())
        throw std::runtime_error("failed to load json " + json.fetch(FILE_NAME).toString());
}

// v3d::MetaData RegularGridRaw(const JsonValue &json, std::string jsonFileName)
//{
//    // get common name and id
//    using namespace v3d::serializer;
//
//    // get data id and name
//    int         model_id;   // might be useless
//    std::string model_name; // might be useless
//    if (json.contains(ID))   { model_id   = json[ID].toInt();      }
//    if (json.contains(NAME)) { model_name = json[NAME].toString(); }
//
//    // load file
//    auto fileName = PathRelToAbs(json.requires(FILE_NAME).toString(),
//    std::move(jsonFileName)); auto data =
//    std::make_shared<RegularGridDataGL>(); RegularGridRaw(json, fileName,
//    data.get());
//
//    // return
//    return { data, model_name, model_id };
//}

} // namespace v3d
