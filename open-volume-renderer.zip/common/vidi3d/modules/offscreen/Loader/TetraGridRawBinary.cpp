//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "AllLoaders.h"
#include "Common.h"
#include "OffScreenDictionary.h"

#include "v3d/Data/TetraGridDataGL.h"
#include "v3d/Data/TetraGridLoader.h"
#include "v3d/Serializer/VectorSerializer.h"
#include "v3d/Serializer/VolumeSerializer.h"

using vidi::anyCast;
using vidi::Exception;

namespace v3d {

void
TetraGridRaw(const JsonValue& json, vidi::Any out)
{
    using namespace v3d::serializer;

    auto loader = std::make_shared<TetraGridLoader>();
    loader->setGridFileName(json.fetch(GRID_FILE_NAME).toString());
    loader->setDataFileName(json.fetch(DATA_FILE_NAME).toString());
    loader->setPointCount(json.fetch(POINT_COUNT).toInt());
    loader->setCellCount(json.fetch(CELL_COUNT).toInt());
    loader->setPointsOffset(size_t(json.fetch(POINTS_OFFSET).toInt64()));
    loader->setCellsOffset(size_t(json.fetch(CELLS_OFFSET).toInt64()));
    loader->setPointDataOffset(size_t(json.fetch(POINT_DATA_OFFSET).toInt64()));

    auto* data = anyCast<TetraGridDataGL*>(out);
    loader->setOutputData(data);
    loader->update();

    data->grid()->correctVertexOrder();
    data->grid()->buildCellToCellConnectivity();
    data->grid()->buildBoundaryMesh();
    data->computePointGradient();
}

// v3d::MetaData TetraGridRaw(const JsonValue &json, std::string jsonFileName)
//{
//    // get common name and id
//    using namespace v3d::serializer;
//
//    // get data id and name
//    int         model_i; // might be useless
//    std::string model_n; // might be useless
//
//    if (json.contains(ID))
//        model_i   = json[ID].toInt();
//
//    if (json.contains(NAME))
//        model_n = json[NAME].toString();
//
//    auto gridFile = PathRelToAbs(json.requires(GRID_FILE_NAME).toString(),
//    jsonFileName); auto dataFile =
//    PathRelToAbs(json.requires(DATA_FILE_NAME).toString(), jsonFileName);
//
//
//    // load
//    auto data = std::make_shared<TetraGridDataGL>();
//
//    data->grid()->correctVertexOrder();
//    data->grid()->buildCellToCellConnectivity();
//    data->grid()->buildBoundaryMesh();
//    data->computePointGradient();
//
//    // return
//    return { data, model_name, model_id };;
//}

} // namespace v3d
