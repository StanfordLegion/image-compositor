//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "AllLoaders.h"
#include "Common.h"
#include "OffScreenDictionary.h"

#include "v3d/Data/TetraGridDataGL.h"
#include "v3d/Data/TetraGridLoader.h"
#include "v3d/Serializer/VectorSerializer.h"

/*

 * This is just to prove that we can read the Nissan dataset. If there is a
 need, we can implement the loader
 * and make it readable interactively.

 {
     "dataSource": [{
         "gridFileName"     :
 "/home/qadwu/Work/data/sshfs/vis.ucdavis.edu/SciVis/UnstructuredGrid/Nissan/nissan.fgrid",
         "solutionFileName" :
 "/home/qadwu/Work/data/sshfs/vis.ucdavis.edu/SciVis/UnstructuredGrid/Nissan/nissan.fsolu",
         "format"           : "HO_TETRA_GRID_MESH",
         "name"             : "nissa.mesh",
         "id"               : 1
     }]
 }

 */

using vidi::anyCast;
using vidi::Exception;

namespace v3d {

void
TetraGridHo(const JsonValue& json, vidi::Any out)
{
    // get common name and id
    using namespace v3d::serializer;

    // get data id and name
    int         model_id;   // might be useless
    std::string model_name; // might be useless
    if (json.contains(ID))
    {
        model_id = json[ID].toInt();
    }
    if (json.contains(NAME))
    {
        model_name = json[NAME].toString();
    }

    // create data
    auto data = anyCast<TetraGridDataGL*>(out);
    auto grid = data->grid();

    // parse filename
    std::string fgrid = json.fetch(GRID_FILE_NAME).toString();
    std::string fsolu = json.fetch(SOLUTION_FILE_NAME).toString();

    // load grid
    size_t vertexCount, faceCount, tetraCount;
    {
        std::cout << "[Info] Reading Chris Ho's grid file \"" << fgrid.c_str() << "\"..."
                  << std::endl;
        std::ifstream ifs;
        ifs.open(fgrid.c_str(), std::ios::in | std::ios::binary);

        if (ifs.fail())
        {
            std::cerr << "[Error] Cannot open file \"" << fgrid.c_str() << "\"" << std::endl;
        }

        int _vertexCount, _faceCount, _tetraCount;
        ifs.read((char*)&_vertexCount, sizeof(int));
        ifs.read((char*)&_faceCount, sizeof(int)); // dummy
        ifs.read((char*)&_tetraCount, sizeof(int));
        vertexCount = size_t(_vertexCount);
        faceCount   = size_t(_faceCount);
        tetraCount  = size_t(_tetraCount);

        std::cout << "vertexCount = " << vertexCount << std::endl;
        std::cout << "tetraCount = " << tetraCount << std::endl;

        data->allocateGrid(_vertexCount, _tetraCount);

        vec3* vertexList = grid->points(); // TetrahedralData will take over this array
        auto* xList      = new float[vertexCount];
        auto* yList      = new float[vertexCount];
        auto* zList      = new float[vertexCount];
        ifs.read((char*)xList, sizeof(float) * vertexCount);
        ifs.read((char*)yList, sizeof(float) * vertexCount);
        ifs.read((char*)zList, sizeof(float) * vertexCount);
        for (int i = 0; i < vertexCount; i++)
            vertexList[i] = vec3(xList[i], yList[i], zList[i]);
        delete[] xList;
        delete[] yList;
        delete[] zList;

        ivec4* tetraList = grid->cells(); // TetrahedralData will take over this array
        ifs.read((char*)tetraList, sizeof(ivec4) * tetraCount);

        /*/
        int minId = tetraList[0].x;
        int maxId = minId;
        for (int i = 0; i < tetraCount; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (minId > tetraList[i][j])
                    minId = tetraList[i][j];
                if (maxId < tetraList[i][j])
                    maxId = tetraList[i][j];
            }
        }
        std::cout << "ID range: " << minId << ", " << maxId << std::endl;
        /*/

        ifs.close();
    }

    // load solution
    {
        std::cout << "[Info] Reading Chris Ho's solution file \"" << fsolu.c_str() << "\"..."
                  << std::endl;

        std::ifstream ifs;
        ifs.open(fsolu.c_str(), std::ios::in | std::ios::binary);

        if (ifs.fail())
        {
            std::cerr << "[Error] Cannot open file \"" << fsolu.c_str() << "\"" << std::endl;
        }

        ifs.seekg(28); // why 28? see Chris Ho's code (in mesh.cpp, line 404)

        data->allocatePointData();
        auto* scalarList = data->pointData(); // TetrahedralData will take over this array
        ifs.read((char*)scalarList, sizeof(float) * vertexCount);

        ifs.close();
    }

    std::cout << "[debug] ~TetraGridLoader::load()" << std::endl;

    data->grid()->correctVertexOrder();
    data->grid()->buildCellToCellConnectivity();
    data->grid()->buildBoundaryMesh();
    data->computePointGradient();
}

} // namespace v3d
