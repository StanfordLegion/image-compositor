//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "AllLoaders.h"
#include "Common.h"
#include "OffScreenDictionary.h"

#include "v3d/Serializer/VectorSerializer.h"
#include "v3d/Serializer/VolumeSerializer.h"

#include <vidiBase.h>
#include <vidiSerializable.h>

using vidi::anyCast;
using vidi::Exception;

namespace v3d {

void
RegularGridPtr(const JsonValue& json, vidi::Any out)
{
  using namespace v3d::serializer;

  auto*      data = anyCast<RegularGridDataGL*>(out);
  const auto path = json.fetch("url").toString();
  const auto addr = path.substr(path.find("://") + 3);
  const auto dims = fromJson<ivec3>(json.fetch(DIMENSIONS));
  const auto type = fromJson<Type>(json.fetch(TYPE));

  switch (type) {
  case V3D_BYTE: {
    auto* ptr
      = reinterpret_cast<char*>(vidi::serializable::castStrToPtr<char>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  case V3D_UNSIGNED_BYTE: {
    auto* ptr = reinterpret_cast<char*>(
      vidi::serializable::castStrToPtr<unsigned char>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  case V3D_SHORT: {
    auto* ptr
      = reinterpret_cast<char*>(vidi::serializable::castStrToPtr<short>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  case V3D_UNSIGNED_SHORT: {
    auto* ptr = reinterpret_cast<char*>(
      vidi::serializable::castStrToPtr<unsigned short>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  case V3D_INT: {
    auto* ptr
      = reinterpret_cast<char*>(vidi::serializable::castStrToPtr<int>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  case V3D_UNSIGNED_INT: {
    auto* ptr = reinterpret_cast<char*>(
      vidi::serializable::castStrToPtr<unsigned int>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  case V3D_FLOAT: {
    auto* ptr
      = reinterpret_cast<char*>(vidi::serializable::castStrToPtr<float>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  case V3D_DOUBLE: {
    auto* ptr
      = reinterpret_cast<char*>(vidi::serializable::castStrToPtr<double>(addr));
    data->setData(std::shared_ptr<char>(ptr, [](char*) {}), dims, type);
  } break;
  default: throw Exception("Unrecognized Data Type " + std::to_string(type));
  }
}

} // namespace v3d
