//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#ifndef V3D_OFFSCREEN_DXSERVER_COMMON_H
#define V3D_OFFSCREEN_DXSERVER_COMMON_H

#include <vidiAny.h>

#include <limits.h>
#include <stdlib.h>

#include <algorithm>
#include <memory>
#include <stdexcept>
#include <string>

namespace v3d {

inline std::string
FixSlash(std::string path)
{
#ifdef WIN32
    std::replace(path.begin(), path.end(), '/', '\\');
#else
    std::replace(path.begin(), path.end(), '\\', '/');
#endif
    return path;
}

inline std::string
PathRelToAbs(std::string filename, std::string headername)
{
#ifdef WIN32
    // https://docs.microsoft.com/en-us/cpp/c-runtime-library/reference/fullpath-wfullpath?view=msvc-170
    char full[_MAX_PATH];
    if (_fullpath(full, filename.c_str(), _MAX_PATH) == NULL)
        throw std::runtime_error("Invalid path: " +  filename);
    return std::string(full);
#else
    char full[PATH_MAX];
    if (realpath(filename.c_str(), full) == NULL)
        throw std::runtime_error("Invalid path: " +  filename);
    return std::string(full);
#endif
}

inline std::string
GetPathDirectory(const std::string& path)
{
    size_t found = path.find_last_of("/\\");
    return FixSlash(path.substr(0, found));
}

inline bool
IsPathRelative(const std::string& path)
{
    if (path[0] == '/') { /* unix like */
        return false;
    }
    else if (path.length() > 1) { /* windows */
        size_t found = path.find_first_of('\\');
        return found == 0 ? true /* not sure what is this */
                          : (path[found - 1] == ':');
    }
    else {
        return true;
    }
}

} // namespace v3d

#endif // V3D_OFFSCREEN_DXSERVER_COMMON_H
