//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "RegularGridEngine.h"
#include <vidiBase.h>

using vidi::Exception;

namespace v3d {

void
RegularGridEngine::_setup()
{
    // 0. frame size
    _defineParameter<vec2i>("fbSize", [=](vec2i v) { setFrameBufferSize(v); });

    // 1. setup camera
    _defineParameter<mat4f>(
      "cameraMVP", [=]() { return mat4f(_camera->viewProjectionMatrix()); });
    _defineParameter<box3f>("cameraFocusBox",
                            [=](box3f v) { setCameraFocusBox(v); });
    _defineParameter<vec3f>("cameraCenter", // where to look at
                            [=]() { return _camera->center(); },
                            [=](vec3f v) { _camera->setCenter(v); });
    _defineParameter<vec3f>("cameraEye", // location of the camera
                            [=]() { return _camera->eye(); },
                            [=](vec3f v) { _camera->setEye(v); });
    _defineParameter<vec3f>("cameraUp", // up vector
                            [=]() { return _camera->up(); },
                            [=](vec3f v) { _camera->setUp(v); });
    _defineParameter<float>("cameraFovy", // field of view on Y direction
                            [=]() { return _camera->fovy(); },
                            [=](float v) { _camera->setFovy(v); });
    _defineParameter<float>("cameraZNear", // near clip plane
                            [=]() { return _camera->zNear(); },
                            [=](float v) { _camera->setNear(v); });
    _defineParameter<float>("cameraZFar", // far clip plane
                            [=]() { return _camera->zFar(); },
                            [=](float v) { _camera->setFar(v); });
    _defineParameter<std::string>(
      "cameraProjectionMode",
      [=]() {
          return _camera->projectionMode() == Camera::ORTHO ? "ORTHO"
                                                            : "PERSPECTIVE";
      },
      [=](std::string v) {
          _camera->setProjectionMode(v == "ORTHO" ? Camera::ORTHO
                                                  : Camera::PERSPECTIVE);
      });

    _defineParameter<box3f>("boundingBox", [=](box3f v) { setBoundingBox(v); });
    _defineParameter<box3f>("clippingBox", [=](box3f v) { setClippingBox(v); });
    _defineParameter<box3f>("textureBox", [=](box3f v) { setTextureBox(v); });
    _defineParameter<vec2d>("scalarValueRange",
                            [=]() { return _volume->scalarMappingRange(); },
                            [=](vec2d v) { setScalarMappingRange(v); });
    _defineParameter<vec2d>("dataValueRange", [=]() { return getDataRange(); });
    _defineParameter<JsonValue>("transferFunction", [=](JsonValue v) {
        configTransferFunction(v);
    });
}

RegularGridEngine::RegularGridEngine()
{
    _setup();
}

void
RegularGridEngine::resize(int x, int y)
{
    setFrameBufferSize(vec2i(x, y));
}

void
RegularGridEngine::initGPU()
{
    // assume we have loaded the data
    assert(_data != nullptr);

    // avoid multiple initialization
    if (_initialized) {
        return;
    }

    // the framebuffer is own by the class, thus we have to resize after initialization
    auto fbo = std::make_shared<FramebufferGL>(1, 1);

    // okay, initialize everything
    initGPU(fbo);

    // finally resize image
    setFrameBufferSize(vec2i(1, 1));
}

void
RegularGridEngine::initGPU(std::shared_ptr<FramebufferGL> fbo)
{
    // assume we have loaded the data
    assert(_data != nullptr);

    // avoid multiple initialization
    if (_initialized) {
        return;
    }
    _initialized = true;

    // create objects
    _volume            = std::make_shared<RegularGridVolumeGL>();
    _scene             = std::make_shared<RegularGridSceneGL>();
    _renderer          = std::make_shared<RegularGridPipelineGL>();
    _camera            = std::make_shared<Camera>();
    _transferFunction  = std::move(TransferFunction::fromRainbowMap());
    _occlusionFunction = std::make_shared<OcclusionTransferFunction>();
    _framebuffer       = std::move(fbo);

    // setup relationship
    _volume->setData(_data);
    _volume->setTransferFunction(_transferFunction);
    _volume->setTransferFunction2D(_occlusionFunction);
    _scene->setVolume(_volume);
    _scene->setCamera(_camera);
    _renderer->setScene(_scene);
    _renderer->setFramebufferObject(_framebuffer->sharedFramebufferObject());

    // cache some data
    const vec3f origin              = _data->origin();
    const vec3f spacing             = _data->spacing();
    const vec3f extent              = _data->extent();
    const box3f bbox                = _data->getBoundingBox();
    const vec3f center              = bbox.center();
    const float opacityUnitDistance = length(spacing) / std::sqrt(3.0f);
    const float samplingStep        = opacityUnitDistance / 4.f;

    // setup default parameters
    setClippingBox(bbox);
    setBoundingBox(bbox);
    setTextureBox(box3f(bbox.minimum() + spacing * 1.0f, bbox.maximum() - spacing * 1.0f));
    setScalarMappingRange(getDataRange());
    setBoundingBoxVisible(false);
    _volume->setOpacityUnitDistance(opacityUnitDistance);
    _volume->setSampleDistance(samplingStep);
    _volume->setXSlicePosition(center.x);
    _volume->setYSlicePosition(center.y);
    _volume->setZSlicePosition(center.z);
    _volume->setInterpolationType(v3d::V3D_CUBIC_INTERPOLATION);
    _volume->setSampleDistance(0.025f);
    _scene->setBackgroundColor(vec4(0.0f, 0.0f, 0.0f, 0.0f));
    _scene->setTFPreIntegration(false);
    _scene->setLighting(false);
    _scene->setEmptySpaceSkipping(false);
    _camera->setFovy(45.0);
    _camera->setAspect(_camera->aspect());
    _camera->setProjectionMode(Camera::PERSPECTIVE);
    setCameraFocusBox(bbox);
}


void
RegularGridEngine::loadGPU()
{
    _data->loadGL();
}

void
RegularGridEngine::freeGPU()
{
    _data->unloadGL();
}

void
RegularGridEngine::render()
{
    glFinish();
    _renderer->render();
    glFinish();
}

void
RegularGridEngine::bindFBO()
{
    _framebuffer->bind();
}


} // namespace v3d

V3D_REGISTER_ENGINE(v3d::RegularGridEngine, regular_grid)
