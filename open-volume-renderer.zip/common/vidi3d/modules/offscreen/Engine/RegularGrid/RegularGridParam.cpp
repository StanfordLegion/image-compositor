//
// Created by Qi Wu on 2019-09-28.
//

#include "RegularGridEngine.h"
#include <vidiBase.h>

using vidi::Exception;

namespace v3d {

vec2d
RegularGridEngine::getDataRange() const
{
    _data->computeScalarRange();
    return _data->getScalarRange();
}

vec2i
RegularGridEngine::getFrameBufferSize() const
{
    return vec2i(_renderer->width(), _renderer->height());
}

void
RegularGridEngine::setBoundingBox(vidi::box3f box)
{
    _volume->setBoundingBox(box);

    /* also update clipping box if clipping box is larger */
    if (!box.contains(_volume->clippingBox())) {
        _volume->setClippingBox(box);
    }
}

void
RegularGridEngine::setClippingBox(vidi::box3f box)
{
    _volume->setClippingBox(box);
}

void
RegularGridEngine::setTextureBox(vidi::box3f box)
{
    _volume->setTextureBox(box);
}

void
RegularGridEngine::setFrameBufferSize(vidi::vec2i size)
{
    _renderer->resize(size.x, size.y);
    _framebuffer->resize(size.x, size.y);
}

void
RegularGridEngine::setBoundingBoxVisible(bool visible)
{
    _volume->setBoundingBoxVisible(visible);
}

void
RegularGridEngine::setScalarMappingRange(vidi::vec2d range)
{
    _volume->setScalarMappingRange(range);
}

void
RegularGridEngine::setCameraFocusBox(vidi::box3f box)
{
    const vec3   boxDim = box.size();
    const vec3   boxCen = box.center();
    const double maxDim = max(max(boxDim.x, boxDim.y), boxDim.z);
    _camera->setEye(dvec3(boxCen) + dvec3(boxDim) * dvec3(0.0, 0.0, 2.5));
    _camera->setCenter(dvec3(boxCen));
    _camera->setUp(dvec3(0.0, 1.0, 0.0));
    _camera->setNear(maxDim * 0.001);
    _camera->setFar(maxDim * 10.0);
}

}
