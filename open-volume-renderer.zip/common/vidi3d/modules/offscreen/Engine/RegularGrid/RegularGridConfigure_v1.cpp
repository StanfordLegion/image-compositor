//
// Created by Qi Wu on 2019-09-28.
//
#include "Loader/AllLoaders.h"
#include "Loader/OffScreenDictionary.h"
#include "RegularGridEngine.h"

#include "v3d/Serializer/CameraSerializer.h"
#include "v3d/Serializer/TransferFunctionSerializer.h"
#include "v3d/Serializer/VectorSerializer.h"
#include "v3d/Serializer/VolumeSceneSerializer.h"
#include "v3d/Serializer/VolumeSerializer.h"

#include <vidiBase.h>
#include <vidiSerializable.h>

using vidi::Exception;
using vidi::serializable::JsonValue;
using namespace v3d::serializer;

namespace v3d {

void
RegularGridEngine::_readData(const vidi::serializable::JsonValue& input)
{
  /* make a copy of the json data because we might need to fix it. */
  JsonValue  dataSource   = input;
  const auto fileLocation = input.fetch(FILE_LOCATION).toString();

  assert(!dataSource.isArray() && "only accept one data source");

  const std::string format = dataSource.fetch(FORMAT).toString();

  bool valid_format = false;
  valid_format |= format == REGULAR_GRID_RAW_BINARY;
  valid_format |= format == REGULAR_GRID_POINTER;
#ifdef V3D_USE_PVM
  valid_format |= format == REGULAR_GRID_PVM;
#endif
  assert(valid_format && "invalid data format");

  std::string type; /* = 'disk', 'memory' or ... */
  if (dataSource.contains(URL)) {
    const auto url   = dataSource[URL].toString();
    const auto found = url.find("://");
    assert(found != url.npos && "invalid URL format");

    type = url.substr(0, found);

    if (type == "disk" && dataSource.contains(FILE_NAME)) {
      const auto f1 = PathRelToAbs(url.substr(found + 3), fileLocation);
      const auto f2 = PathRelToAbs(dataSource.fetch(FILE_NAME).toString(), fileLocation);
      assert(f1 == f2);
    }
    else if (!dataSource.contains(FILE_NAME)) {
      dataSource[FILE_NAME] = PathRelToAbs(url.substr(found + 3), "");
    }
  }

  /* this is to make sure the JSON is compatible with legacy vidi3d systems */
  else {
    auto dataFileName = PathRelToAbs(dataSource.fetch(FILE_NAME).toString(), fileLocation);

    type = "disk";

    dataSource[URL] = type + "://" + dataFileName;
  }

  /* now we load the data */
  if (!_data)
    _data = std::make_shared<RegularGridDataGL>();

  if (format == REGULAR_GRID_RAW_BINARY) {
    RegularGridRaw(dataSource, _data.get());
  }
  else if (format == REGULAR_GRID_POINTER) {
    RegularGridPtr(dataSource, _data.get());
  }
#ifdef VIDI_USE_PVM
  else if (format == REGULAR_GRID_PVM) {
    ERROR_UNIMPLEMENTED;
  }
#endif
  else {
    ERROR_UNIMPLEMENTED;
  }
}

void
RegularGridEngine::readData(const JsonValue& dataSource)
{
  _jsonDataSource = dataSource;
  _readData(_jsonDataSource);
}

void
RegularGridEngine::configVolume(const JsonValue& jsonView)
{
  if (jsonView.contains(VOLUME)) {
    fromJson(jsonView[VOLUME], *_volume);
  }
}

void
RegularGridEngine::configTransferFunction(const vidi::serializable::JsonValue& jsonView)
{
  if (jsonView.contains(VOLUME)) {
    const auto& jsonVolume = jsonView[VOLUME];
    if (jsonVolume.contains(SCALAR_MAPPING_RANGE)) {
      _volume->setScalarMappingRange(rangeFromJson(jsonVolume[SCALAR_MAPPING_RANGE]));
    }
    if (jsonVolume.contains(TRANSFER_FUNCTION)) {
      fromJson(jsonVolume[TRANSFER_FUNCTION], *_transferFunction);
      _transferFunction->updateColorMap();
      _volume->setTransferFunctionDirty(true);
      _volume->setTransferFunctionDirtyCoarse(true);
    }
    if (jsonVolume.contains(OCCLUSION_TRANSFER_FUNCTION)) {
      fromJson(jsonVolume[OCCLUSION_TRANSFER_FUNCTION], *_occlusionFunction);
      _occlusionFunction->update();
      _volume->setTransferFunction2DDirty(true);
    }
  }
}

void
RegularGridEngine::configCamera(const JsonValue& jsonView)
{
  if (jsonView.contains(CAMERA)) {
    fromJson<Camera>(jsonView[CAMERA], *_camera);
  }
}

void
RegularGridEngine::fromJsonView(const JsonValue& jsonView)
{
  fromJson(jsonView, *_scene);
  configVolume(jsonView);
  configCamera(jsonView);
  configTransferFunction(jsonView);
}

void
RegularGridEngine::toJsonView(JsonValue& jsonView)
{
  jsonView[METHOD_] = "REGULAR_GRID_VOLUME_RAY_CASTING";
  jsonView[CAMERA]  = toJson(*_camera);
  jsonView[VOLUME]  = toJson(*_volume);
  switch (_volume->tfType()) {
  case IRegularGridVolumeGL::TRANSFER_FUNCTION_2D:
  case IRegularGridVolumeGL::OCCLUSION_TRANSFER_FUNCTION:
  case IRegularGridVolumeGL::CUSTOM_TRANSFER_FUNCTION_2D:
    jsonView[VOLUME][OCCLUSION_TRANSFER_FUNCTION] = toJson(*_occlusionFunction);
    // no break on purpose ... //
  default: jsonView[VOLUME][TRANSFER_FUNCTION] = toJson(*_transferFunction); break;
  }
  toJson2(*_scene, jsonView);
}

} // namespace v3d
