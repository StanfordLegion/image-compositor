//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#pragma once

#include "Engine/AbstractRenderEngine.h"

#include "v3d/Data/RegularGridDataGL.h"
#include "v3d/Renderer/RegularGridPipelineGL.h"
#include "v3d/Renderer/RegularGridSceneGL.h"
#include "v3d/Renderer/RegularGridVolumeGL.h"
#include "v3d/Util/Camera.h"
#include "v3d/Util/JsonParser.h"
#include "v3d/Util/OcclusionTransferFunction.h"
#include "v3d/Util/TransferFunction.h"

namespace v3d {

class RegularGridEngine : public AbstractRenderEngine {
public:
    RegularGridEngine();

    void resize(int, int) override;
    void initGPU() override;
    void initGPU(std::shared_ptr<FramebufferGL>) override;
    void loadGPU() override;
    void freeGPU() override;
    void render() override;
    void bindFBO() override;

    void readData(const JsonValue& dataSource) override;
    void configVolume(const JsonValue& jsonView) override;
    void configCamera(const JsonValue& jsonView) override;
    void configTransferFunction(const JsonValue& jsonView) override;
    void fromJsonView(const JsonValue& jsonView) override;
    void toJsonView(JsonValue& jsonView) override;

    vec2i getFrameBufferSize() const override;

private:
    vec2d getDataRange() const;
    void  setFrameBufferSize(vec2i);
    void  setBoundingBox(box3f);
    void  setClippingBox(box3f);
    void  setTextureBox(box3f);
    void  setBoundingBoxVisible(bool);
    void  setScalarMappingRange(vec2d);
    void  setCameraFocusBox(box3f);
    void  _readData(const JsonValue& dataSource);
    void  _setup() override;

private:
    bool                                       _initialized = false;
    JsonValue                                  _jsonDataSource;
    std::shared_ptr<RegularGridDataGL>         _data              = nullptr;
    std::shared_ptr<RegularGridVolumeGL>       _volume            = nullptr;
    std::shared_ptr<RegularGridSceneGL>        _scene             = nullptr;
    std::shared_ptr<RegularGridPipelineGL>     _renderer          = nullptr;
    std::shared_ptr<Camera>                    _camera            = nullptr;
    std::shared_ptr<TransferFunction>          _transferFunction  = nullptr;
    std::shared_ptr<OcclusionTransferFunction> _occlusionFunction = nullptr;
    std::shared_ptr<FramebufferGL>             _framebuffer       = nullptr;
};

} // namespace v3d
