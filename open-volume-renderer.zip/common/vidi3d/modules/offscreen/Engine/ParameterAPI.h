//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#pragma once

#include <v3d_offscreen_export.h>

#include "AbstractRenderEngine.h"

#include "v3d/Util/JsonParser.h"

#include <vidiPlatform.h>

#include <string>
#include <vector>

namespace v3d {

class ParameterAPI {
public:

    void createAndLoad(JsonValue json, std::string project = "");

    __forceinline void create(std::string target)
    {
        _engine = CreateRenderEngine(target); // error handling
    }

    __forceinline void initialize()
    {
        assert(_engine);
        _engine->initGPU();
    }

    __forceinline void resize(int W, int H)
    {
        assert(_engine);
        _engine->resize(W, H);
    }

    __forceinline void render()
    {
        assert(_engine);
        _engine->render();
    }

    __forceinline void setData(JsonValue json)
    {
        assert(_engine);
        _engine->readData(json);
    }

    __forceinline void loadGPU()
    {
        assert(_engine);
        _engine->loadGPU();
    }

    __forceinline void freeGPU()
    {
        assert(_engine);
        _engine->freeGPU();
    }

    __forceinline std::vector<uint8_t> getRenderedFrameRGBA8(bool solidAlpha = true)
    {
        return _engine->getRenderedFrameRGBA8(solidAlpha);
    }

    __forceinline std::vector<float> getRenderedFrameVec4f(bool solidAlpha = true)
    {
        return _engine->getRenderedFrameVec4f(solidAlpha);
    }

    template<typename T>
    __forceinline void setParameter(const std::string& name, const T& val)
    {
        assert(_engine);
        _engine->setParameter<T>(name, val);
    }

private:
    std::string _type;
    std::shared_ptr<AbstractRenderEngine> _engine;
};

} // namespace v3d
