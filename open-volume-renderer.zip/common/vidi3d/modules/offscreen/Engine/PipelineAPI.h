//===========================================================================//
//                                                                           //
// Daxian Server                                                             //
// Copyright(c) 2018 Qi Wu, Yiran Li, Wenxi Lu                               //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#pragma once

#include <v3d_offscreen_export.h>

#include "AbstractRenderEngine.h"

#include <v3d/Util/JsonParser.h>

#include <string>

namespace v3d {

///////////////////////////////////////////////////////////////////////////////

/**
 * Implementation details. Usually we should not directly access a class inside
 * a details namespace. We should either use a corresponding shared pointer
 * creater, or a list manipulator.
 */
namespace details {
}

/**
 * This is an internal class for rendering
 */
class PipelineAPI {
public:
    using ImageRGBA8 = AbstractRenderEngine::ImageRGBA8;
    using ImageVec4f = AbstractRenderEngine::ImageVec4f;

    /**
     * @name Special Functions
     * @note The class is copyable and movable
     */
    ///@{
    /**
     * @brief Destructor
     */
    virtual ~PipelineAPI();
    /**
     * @brief Copy constructor
     */
    PipelineAPI(const PipelineAPI&);
    /**
     * @brief Copy assignment operator
     * @return
     */
    PipelineAPI& operator=(const PipelineAPI&);
    /**
     * @brief Move constructor
     */
    PipelineAPI(PipelineAPI&&) noexcept;
    /**
     * @brief Move assignment operator
     * @return
     */
    PipelineAPI& operator=(PipelineAPI&&) noexcept;
    /**
     * Default Constructor
     */
    PipelineAPI();
    PipelineAPI(int w, int h, const JsonValue&);
    PipelineAPI(int w, int h, const std::string&);
    ///@}

    /**
     * @brief Update the view configuration
     * @param input
     */
    void configureFromJson(const JsonValue& input = JsonValue{});

    /**
     * @brief This function will open the JSON configuration file from disk
     */
    void configureFromDisk(const std::string& project);

    /**
     * @brief Resize the engine's framebuffer
     * @param w
     * @param h
     */
    void resize(int w, int h);

    /**
     * @brief Load data into the CPU memory
     */
    void loadCPU();

    /**
     * @brief Load data into the GPU memory
     */
    void loadGPU();

    /**
     * @brief Free data from the CPU memory
     */
    void unloadCPU();

    /**
     * @brief Free data from the GPU memory
     */
    void unloadGPU();

    /**
     * @param Commit data changes on GPU. This should be called if data has been
     * updated
     */
    void commitDataGPU();

    /**
     * @param Commit data changes on CPU. This should be called if data has been
     * updated
     */
    void commitDataCPU();

    /**
     * @brief Commit view changes. This function should be called if
     * configuration has been updated
     */
    void commitViewCPU();

    /**
     * @brief Commit view changes. This function should be called if
     * configuration has been updated
     */
    void commitViewGPU();

    /**
     * @brief Does the rendering
     */
    void render();

    JsonValue serializeView() const;
    JsonValue serializeData() const;

    ImageRGBA8 getFrameAsBufferRGBA8(bool opaque_background) const;
    void getFrameAsBufferRGBA8(ImageRGBA8& output, bool auto_resize, bool opaque_background) const;
    ImageVec4f getFrameAsBufferVec4f(bool opaque_background) const;
    void getFrameAsBufferVec4f(ImageVec4f& output, bool auto_resize, bool opaque_background) const;

private:
    class impl;
    std::unique_ptr<impl> pimpl;
};

// we do not expose anything in the dx namespace
using engine_t = std::shared_ptr<PipelineAPI>;

///////////////////////////////////////////////////////////////////////////////

} // namespace v3d
