//===========================================================================//
//                                                                           //
// Daxian Server                                                             //
// Copyright(c) 2018 Qi Wu, Yiran Li, Wenxi Lu                               //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "PipelineAPI.h"

#include "Engine/AbstractRenderEngine.h"
#include "Loader/AllLoaders.h"
#include "Loader/OffScreenDictionary.h"

#include <v3d/Serializer/CameraSerializer.h>
#include <v3d/Serializer/TransferFunctionSerializer.h>
#include <v3d/Serializer/VectorSerializer.h>
#include <v3d/Serializer/VolumeSceneSerializer.h>
#include <v3d/Serializer/VolumeSerializer.h>
#include <v3d/Util/Log.h>

#include <vidiBase.h>
#include <vidiMPI.h>
#include <vidiMemory.h>

#include <unordered_map>

using vidi::Exception;
using namespace v3d::serializer;

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//                                                                           //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

namespace v3d {

class PipelineAPI::impl {
private:
    friend class Engine;

public:
    // resize the frame buffer. this needs to be called once before rendering.
    void resize(int w = -1, int h = -1);

    void readFromDisk(
      const std::string&); // simply read the JSON, do not load data

    void readFromJson(const JsonValue&); // same

    void render(); // rendering

    // load data, this will also reset the camera position for a data
    void loadDataToCPU();

    // delete the data
    void unloadFromCPU();

    // loadGL for data
    void loadDataToGPU();

    // unload data fpr GL
    void unloadFromGPU();

    // retrieve framebuffer
    PipelineAPI::ImageRGBA8 getFrameAsBufferRGBA8(bool opaque_background) const;
    void getFrameAsBufferRGBA8(ImageRGBA8& output, bool auto_resize, bool opaque_background) const;
    PipelineAPI::ImageVec4f getFrameAsBufferVec4f(bool opaque_background) const;
    void getFrameAsBufferVec4f(ImageVec4f& output, bool auto_resize, bool opaque_background) const;

    // produce a view file
    JsonValue serializeView() const;

    // configure based on the view file
    void deserializeView();

private:
    std::shared_ptr<v3d::AbstractRenderEngine> _renderer;
    Property<JsonValue>                        _jsonData;
    Property<JsonValue>                        _jsonView;
    std::string                                _jsonFile;

    vec2i _size = ivec2(0, 0);
};

///////////////////////////////////////////////////////////////////////////////

void
PipelineAPI::impl::resize(int w, int h)
{
    if (w > 0)
        _size.x = w;
    if (h > 0)
        _size.y = h;
    if (_size.x > 0 && _size.y > 0 && _renderer) {
        _renderer->resize(_size.x, _size.y);
    }
}

// read the JSON file from disk
void
PipelineAPI::impl::readFromDisk(const std::string& project)
{
    _jsonFile = project;
    JsonValue json;
    JsonParser().load(project, json);
    readFromJson(json);
}

void
PipelineAPI::impl::readFromJson(const JsonValue& input)
{
    // load the data source if present
    if (input.contains(DATA_SOURCE)) {
        _jsonData.setValue(input[DATA_SOURCE]);
        _jsonData.setDirty(true);
    }
    else {
        warn() << "[PipelineAPI] The project JSON does not contain a data specification." << std::endl;
    }

    // load the view if present
    if (input.contains(VIEW)) {
        _jsonView.setValue(input[VIEW]);
        _jsonView.setDirty(true);
    }
    else {
        warn() << "[PipelineAPI] The project JSON does not contain a view specification." << std::endl;
    }
}

void
PipelineAPI::impl::render()
{
    _renderer->render();
}

///////////////////////////////////////////////////////////////////////////////

void
PipelineAPI::impl::loadDataToGPU()
{
    _renderer->loadGPU();
}

void
PipelineAPI::impl::unloadFromGPU()
{
    _renderer->freeGPU();
}

void
PipelineAPI::impl::loadDataToCPU()
{
    // analysis json file
    if (_jsonData.value().isNull()) {
        throw Exception("[Error] empty json data");
    }
    else {
        if (!_jsonData.isDirty())
            warn() << "Reloading a clean data" << std::endl;
        auto& input = _jsonData.value();
        if (!input.isArray()) {
            throw Exception("[Error] In PipelineAPI::impl::loadDataToCPU(): "
                            "Bad JSON format, DATA_SOURCE should be an array.");
        }
        if (input.size() != 1) {
            throw Exception(
              "[Error] In PipelineAPI::impl::loadDataToCPU(): "
              "Bad JSON format, DATA_SOURCE has more than one entry,"
              "current size is " +
              std::to_string(input.size()));
        }
        // Here we iterate over all data and load all of them. The first data
        // will be the current data.
        auto& jsonData = input[0];
        auto  format   = jsonData.fetch(FORMAT).toString();
        if (format == REGULAR_GRID_RAW_BINARY) {
            _renderer = CreateRenderEngine("regular_grid");
        }
        else if (format == REGULAR_GRID_POINTER) {
            _renderer = CreateRenderEngine("regular_grid");
        }
#ifdef VIDI_USE_PVM
        else if (format == REGULAR_GRID_PVM) {
            _renderer = CreateRenderEngine("regular_grid");
        }
#endif
        else if (format == TETRAHEDRAL_GRID_RAW_BINARY) {
            _renderer = CreateRenderEngine("tetra_grid");
        }
        else if (format == TETRAHEDRAL_GRID_FAST) {
            _renderer = CreateRenderEngine("tetra_grid");
        }
        else if (format == TETRAHEDRAL_HO_MESH) {
            _renderer = CreateRenderEngine("tetra_grid");
        }
        else if (format == MULTI_BLOCKS) {
            _renderer = CreateRenderEngine("multi_blocks");
        }
        else {
            ERROR_UNIMPLEMENTED;
        }
        jsonData[FILE_LOCATION] = _jsonFile;
        _renderer->readData(jsonData);
        _jsonData.setDirty(false);
    }
}

void
PipelineAPI::impl::unloadFromCPU()
{
    _renderer.reset();
    _jsonData.setValue(JsonValue{});
    _jsonData.setDirty(false);
}

///////////////////////////////////////////////////////////////////////////////

void
PipelineAPI::impl::deserializeView()
{
    _renderer->initGPU();
    resize(_size.x, _size.y);
    if (_jsonView.value().isNull()) {
        warn() << "[Error] empty json view" << std::endl;
    }
    else {
        const JsonValue& view = _jsonView.value();
        _renderer->fromJsonView(view);
        _jsonView.setDirty(false);
    }
}

JsonValue
PipelineAPI::impl::serializeView() const
{
    JsonValue json;
    _renderer->toJsonView(json);
    return std::move(json);
}

///////////////////////////////////////////////////////////////////////////////

PipelineAPI::ImageRGBA8
PipelineAPI::impl::getFrameAsBufferRGBA8(bool opaque_background) const
{
    return std::move(_renderer->getRenderedFrameRGBA8(opaque_background));
}

void
PipelineAPI::impl::getFrameAsBufferRGBA8(ImageRGBA8& output, bool auto_resize, bool opaque_background) const
{
    _renderer->getRenderedFrameRGBA8(output, auto_resize, opaque_background);
}

PipelineAPI::ImageVec4f
PipelineAPI::impl::getFrameAsBufferVec4f(bool opaque_background) const
{
    return std::move(_renderer->getRenderedFrameVec4f(opaque_background));
}

void
PipelineAPI::impl::getFrameAsBufferVec4f(ImageVec4f& output, bool auto_resize, bool opaque_background) const
{
    _renderer->getRenderedFrameVec4f(output, auto_resize, opaque_background);
}

// TODO provide an implementation without Qt //
// std::string
// PipelineAPI::impl::getFrameAsString(bool solidAlpha) const
// {
//     const auto raw = getFrameAsBuffer(solidAlpha);
//     if (!raw.empty())
//     {
// #if 0
//         QImage img =
//           QImage(&(raw[0]), _size.x, _size.y,
//           QImage::Format_RGB32).mirrored(false, true);
//         QByteArray base64;
//         QByteArray ba;
//         QBuffer    buf(&ba);
//         buf.open(QIODevice::WriteOnly);
//         img.save(&buf, "JPG");
//         buf.close();
//         base64 = ba.toBase64();
//         return std::move(base64.toStdString());
// #endif
//     }
//     else
//     {
//         throw Exception("The received frame is empty.");
//     }
// }

///////////////////////////////////////////////////////////////////////////////

PipelineAPI::~PipelineAPI() = default;

PipelineAPI::PipelineAPI(PipelineAPI&&) noexcept = default;

PipelineAPI&
PipelineAPI::operator=(PipelineAPI&&) noexcept = default;

PipelineAPI::PipelineAPI(const PipelineAPI& other)
  : pimpl{ new impl(*(other.pimpl)) }
{
}

PipelineAPI&
PipelineAPI::operator=(const PipelineAPI& rhs)
{
    if (this != &rhs) {
        pimpl.reset(new impl(*rhs.pimpl));
    }
    return *this;
}

PipelineAPI::PipelineAPI()
  : pimpl{ new impl() }
{
}

PipelineAPI::PipelineAPI(int w, int h, const JsonValue& json)
  : pimpl{ new impl() }
{
    pimpl->readFromJson(json);
    pimpl->resize(w, h);
}

PipelineAPI::PipelineAPI(int w, int h, const std::string& file)
  : pimpl{ new impl() }
{
    pimpl->readFromDisk(file);
    pimpl->resize(w, h);
}

void
PipelineAPI::configureFromJson(const JsonValue& json)
{
    pimpl->readFromJson(json);
}
void
PipelineAPI::configureFromDisk(const std::string& file)
{
    pimpl->readFromDisk(file);
}

void
PipelineAPI::render()
{
    pimpl->render();
}

void
PipelineAPI::resize(int w, int h)
{
    pimpl->resize(w, h);
}

void
PipelineAPI::commitDataCPU()
{
}
void
PipelineAPI::commitViewCPU()
{
}

void
PipelineAPI::commitDataGPU()
{
}

void
PipelineAPI::commitViewGPU()
{
    pimpl->deserializeView();
    pimpl->resize();
}

void
PipelineAPI::loadCPU()
{
    pimpl->loadDataToCPU();
}
void
PipelineAPI::loadGPU()
{
    pimpl->loadDataToGPU();
}

void
PipelineAPI::unloadCPU()
{
    pimpl->unloadFromCPU();
}
void
PipelineAPI::unloadGPU()
{
    pimpl->unloadFromGPU();
}

JsonValue
PipelineAPI::serializeView() const
{
    return pimpl->serializeView();
}
JsonValue
PipelineAPI::serializeData() const
{
    return JsonValue(); /* TODO */
}

PipelineAPI::ImageRGBA8
PipelineAPI::getFrameAsBufferRGBA8(bool opaque_background) const
{
    return std::move(pimpl->getFrameAsBufferRGBA8(opaque_background));
}

void
PipelineAPI::getFrameAsBufferRGBA8(ImageRGBA8& output, bool auto_resize, bool opaque_background) const
{
    pimpl->getFrameAsBufferRGBA8(output, auto_resize, opaque_background);
}

PipelineAPI::ImageVec4f
PipelineAPI::getFrameAsBufferVec4f(bool opaque_background) const
{
    return std::move(pimpl->getFrameAsBufferVec4f(opaque_background));
}

void
PipelineAPI::getFrameAsBufferVec4f(ImageVec4f& output, bool auto_resize, bool opaque_background) const
{
    pimpl->getFrameAsBufferVec4f(output, auto_resize, opaque_background);
}

///////////////////////////////////////////////////////////////////////////////

} // namespace v3d
