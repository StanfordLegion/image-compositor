//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#pragma once

#include <v3d_offscreen_export.h>

#include "AbstractRenderEngine.h"

namespace v3d {

class DistributedEngine : public AbstractRenderEngine {
private:
    struct Region {
        float   depth;
        range2f size;
        box3f   logicBounds;
        box3f   ghostBounds;
        // actual data
        std::shared_ptr<AbstractRenderEngine> volume;
    };

public:
    DistributedEngine();
    void resize(int, int) override;
    void initGPU() override;
    void initGPU(std::shared_ptr<FramebufferGL>) override { ERROR_UNIMPLEMENTED };
    void loadGPU() override;
    void freeGPU() override;
    void render() override;
    void bindFBO() override;

    void readData(const JsonValue&) override;
    void configVolume(const JsonValue& jsonView) override;
    void configCamera(const JsonValue& jsonView) override;
    void configTransferFunction(const JsonValue& jsonView) override;
    void fromJsonView(const JsonValue& jsonView) override;
    void toJsonView(JsonValue& jsonView) override;

    vec2i getFrameBufferSize() const override;
    image getRenderedFrame(bool solidAlpha = true) override;

private:
    void setFrameBufferSize(vec2i);
    void _computeTiles(Region&);
    void _setup() override;
    void _checkIfScalarMappingRangeHasBeenSet(const JsonValue& jsonView);
private:
    std::vector<Region> _regions;
    JsonValue           _jsonDataSource;
    // common fields
    vec3i _dimensions;
    bool  _initialized = false;
    int   _forceVRange = 0;
    // framebuffer
    std::shared_ptr<FramebufferGL> _framebuffer; // add more for multi-GPU
};

} // namespace v3d
