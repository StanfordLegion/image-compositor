//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "DistributedEngine.h"
#include "Compositor.h"
#include "Loader/AllLoaders.h"
#include "Loader/OffScreenDictionary.h"

#include "v3d/Serializer/CameraSerializer.h"
#include "v3d/Serializer/TransferFunctionSerializer.h"
#include "v3d/Serializer/VectorSerializer.h"
#include "v3d/Serializer/VolumeSceneSerializer.h"
#include "v3d/Serializer/VolumeSerializer.h"

#include <vidiMPI.h>
#include <vidiMath.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STBI_MSC_SECURE_CRT
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

static_assert(VIDI_USE_MPI);

// helper functions to write the rendered image as PPM file
static void
writePPM(const std::string& fileName,
         const uint32_t     width,
         const uint32_t     height,
         const uint32_t*    pixel);
static void
writePPM(const std::string& fileName,
         const uint32_t     width,
         const uint32_t     height,
         const float*       pixel);

#define SetAll(regions, x)           \
    for (auto&& region : _regions) { \
        region.x;                    \
    }

using namespace v3d::serializer;
using namespace vidi::math;

namespace v3d {

void
DistributedEngine::_setup()
{
    _defineParameter<vec2i>("fbSize", [=](vec2i v) { setFrameBufferSize(v); });
    _defineParameter<vec2d>("scalarValueRange", [=](vec2d v) {
        _forceVRange = 1;
        SetAll(_regions, volume->setParameter("scalarValueRange", v));
    });
    _defineParameter<JsonValue>("transferFunction", [=](JsonValue v) {
        _checkIfScalarMappingRangeHasBeenSet(v);
        SetAll(_regions, volume->setParameter("transferFunction", v));
    });
}

void
DistributedEngine::_computeTiles(Region& region)
{
    const auto mvp = region.volume->getParameter<mat4f>("cameraMVP");
    const auto eye = region.volume->getParameter<vec3f>("cameraEye");
    const auto cen = region.volume->getParameter<vec3f>("cameraCenter");
    const auto dir = normalize(cen - eye);

    // compute coordinates of 8 vertices
    const auto& bound          = region.logicBounds;
    const dvec3 coordinates[8] = {
        dvec3(bound.minimum()),
        dvec3(bound.maximum().x, bound.minimum().y, bound.minimum().z),
        dvec3(bound.minimum().x, bound.maximum().y, bound.minimum().z),
        dvec3(bound.minimum().x, bound.minimum().y, bound.maximum().z),
        dvec3(bound.minimum().x, bound.maximum().y, bound.maximum().z),
        dvec3(bound.maximum().x, bound.minimum().y, bound.maximum().z),
        dvec3(bound.maximum().x, bound.maximum().y, bound.minimum().z),
        dvec3(bound.maximum())
    };

    // compute screen plane projection
    auto& size       = region.size;
    size.minimum().x = 1.f;
    size.minimum().y = 1.f;
    size.maximum().x = -1.f;
    size.maximum().y = -1.f;
    for (int i = 0; i < 8; i++) {
        vec4f coord(coordinates[i].x, coordinates[i].y, coordinates[i].z, 1.0);
        vec4f screen = mvp * coord;
        screen /= screen.w;
        size.minimum().x = min(screen.x, size.minimum().x);
        size.minimum().y = min(screen.y, size.minimum().y);
        size.maximum().x = max(screen.x, size.maximum().x);
        size.maximum().y = max(screen.y, size.maximum().y);
    }

    const auto target = bound.center();
    region.depth      = length(target - eye);

    size.maximum() = 0.5f * size.maximum() + vec2f(0.5);
    size.minimum() = 0.5f * size.minimum() + vec2f(0.5);
}

DistributedEngine::DistributedEngine()
{
    _regions.resize(1);
    _setup();
}

void
DistributedEngine::resize(int x, int y)
{
    setFrameBufferSize(vec2i(x, y));
}

void
DistributedEngine::readData(const JsonValue& jsonData)
{
    // retrieve MPI information
    int mpiRank = vidi::mpi::GetRank(), mpiSize = vidi::mpi::GetSize();

    // setup global bounding box for distributed volume.
    // the lower bound is (0, 0, 0) by default.
    _dimensions = fromJson<vec3i>(jsonData.fetch(GLOBAL_DIMENSIONS));

    // read the blocks and corresponding ghost region information
    const auto& data = jsonData.fetch(BLOCKS).toArray();
    const auto& meta = jsonData.fetch(GHOST_REGIONS).toArray();

    if (data.size() == mpiSize || mpiSize == 1 /* debug */) {

        auto  b = data[mpiRank];
        auto& m = meta[mpiRank];

        b[FILE_LOCATION] = jsonData[FILE_LOCATION].toString();

        Region& region = _regions[0];
        if (!region.volume) {
            const auto format = b.fetch(FORMAT).toString();
            if (format == REGULAR_GRID_POINTER ||
                format == REGULAR_GRID_RAW_BINARY
#ifdef VIDI_USE_PVM
                || format == REGULAR_GRID_PVM
#endif
            ) {
                region.volume = CreateRenderEngine("regular_grid");
            }
            else if (format == TETRAHEDRAL_GRID_RAW_BINARY ||
                     format == TETRAHEDRAL_GRID_FAST ||
                     format == TETRAHEDRAL_HO_MESH) {
                region.volume = CreateRenderEngine("tetra_grid");
            }
            else {
                ERROR_UNIMPLEMENTED;
            }
        }
        region.volume->readData(b);
        region.logicBounds = fromJson<box3f>(m.fetch(LOGIC_BOUNDS));
        region.ghostBounds = fromJson<box3f>(m.fetch(GHOST_BOUNDS));
    }
} // namespace v3d

void
DistributedEngine::initGPU()
{
    // assume we have loaded the data
    assert(!_regions.empty());

    // avoid multiple initialization
    if (_initialized)
        return;
    _initialized = true;

    // create a framebuffer and share it with the volume
    _framebuffer = std::make_shared<FramebufferGL>(1, 1);
    for (auto&& region : _regions) {
        region.volume->initGPU(_framebuffer);
    }

    // setup subvolume bounding boxes
    auto bbox = box3f(vec3f(0), _dimensions);
    for (auto&& region : _regions) {
        region.volume->setParameter("boundingBox", bbox);
        region.volume->setParameter("clippingBox", region.logicBounds);
        region.volume->setParameter("textureBox", region.ghostBounds);
    }

    // sync value range
    SetAll(_regions, volume->setParameter("cameraFocusBox", bbox));

    // resize it
    setFrameBufferSize(vec2i(600, 600));
}

void
DistributedEngine::loadGPU()
{
    SetAll(_regions, volume->loadGPU());
}

void
DistributedEngine::freeGPU()
{
    SetAll(_regions, volume->freeGPU());
}

void
DistributedEngine::bindFBO()
{
    _framebuffer->bind();
}

void
DistributedEngine::render()
{
    if (_forceVRange == 0) {
        for (auto&& region : _regions) {
            auto dataRange = // this computes the actual data range
              region.volume->getParameter<vec2d>("dataValueRange");
            auto vmin = std::min(dataRange.x, dataRange.y);
            auto vmax = std::max(dataRange.x, dataRange.y);
            MPI_Allreduce(
              &vmin, &dataRange.x, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
            MPI_Allreduce(
              &vmax, &dataRange.y, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
            // set data value range as tfn mapping range
            region.volume->setParameter("scalarValueRange", dataRange);
            // debug message
            if (vidi::mpi::GetRank() == 0)
                std::cout << "recomputing range " << dataRange.x << " "
                          << dataRange.y << std::endl;
        }
    }

    SetAll(_regions, volume->render());
}

void
DistributedEngine::configVolume(const JsonValue& jsonView)
{
    _checkIfScalarMappingRangeHasBeenSet(jsonView);
    SetAll(_regions, volume->configVolume(jsonView));
}

void
DistributedEngine::configCamera(const JsonValue& jsonView)
{
    _checkIfScalarMappingRangeHasBeenSet(jsonView);
    SetAll(_regions, volume->configCamera(jsonView));
}

void
DistributedEngine::configTransferFunction(const JsonValue& jsonView)
{
    _checkIfScalarMappingRangeHasBeenSet(jsonView);
    SetAll(_regions, volume->configTransferFunction(jsonView));
}

void
DistributedEngine::fromJsonView(const JsonValue& jsonView)
{
    _checkIfScalarMappingRangeHasBeenSet(jsonView);
    for (auto&& region : _regions) {
        region.volume->fromJsonView(jsonView);
    }
    configVolume(jsonView);
    configCamera(jsonView);
    configTransferFunction(jsonView);
}

void
DistributedEngine::toJsonView(JsonValue& jsonView)
{
}

vec2i
DistributedEngine::getFrameBufferSize() const
{
    return vec2i(_framebuffer->width(), _framebuffer->height());
}

static void
writeArray(const std::string& filename,
           int                width,
           int                height,
           float              depth,
           const uint32_t*    pixel)
{
    FILE* file = fopen(filename.c_str(), "wb");
    if (!file) {
        fprintf(
          stderr, "fopen('%s', 'wb') failed: %d", filename.c_str(), errno);
        return;
    }
    fprintf(file, "P6\n%i %i\n255\n", width, height);
    unsigned char* out = (unsigned char*)alloca(4 * width);
    for (int y = 0; y < height; y++) {
        const unsigned char* in =
          (const unsigned char*)&pixel[(height - 1 - y) * width];
        for (int x = 0; x < width; x++) {
            out[4 * x + 0] = in[4 * x + 0];
            out[4 * x + 1] = in[4 * x + 1];
            out[4 * x + 2] = in[4 * x + 2];
            out[4 * x + 3] = in[4 * x + 3];
        }
        fwrite(out, 4 * width, sizeof(char), file);
    }
    fprintf(file, "\n");
    fprintf(file, "DEPTH\n%f\n", depth);
    fclose(file);
}

DistributedEngine::image
DistributedEngine::getRenderedFrame(bool solidAlpha)
{
    int mpiRank = vidi::mpi::GetRank();
    int mpiSize = vidi::mpi::GetSize();

    auto rendered = _regions[0].volume->getRenderedFrame(false);

    const auto& tileSize  = _regions[0].size;
    const vec2i frameSize = getFrameBufferSize();

    const int w = frameSize.x;
    const int h = frameSize.y;

    writeArray("tile-" + std::to_string(mpiRank) + ".dat",
               w,
               h,
               _regions[0].depth,
               (uint32_t*)rendered.data());

#if 0
    std::stringstream tilename;
    tilename << "tile-" << mpiRank << ".dat";
    FILE* file = fopen(tilename.str().c_str(), "rb");
    if (!file) {
      fprintf(stderr, "fopen('%s', 'rb') failed: %d", tilename.str().c_str(),
	      errno);
      exit(1);
    }
    int width, height;
    fscanf(file, "P6\n%i %i\n255\n", &width, &height);
    uint8_t* pixels = new uint8_t[width * height * 4];
    for (int y = 0; y < height; y++) {
      unsigned char* in = &pixels[4 * (height - 1 - y) * width];
      fread(in, sizeof(char), 4 * width, file);
    }
    float ddepth;
    fscanf(file, "\nDEPTH\n%f\n", &ddepth);
    fclose(file);
    std::cout << "w " << width << " h " << height << " d " << ddepth << std::endl;
#endif

    // writePPM("tile-" + std::to_string(mpiRank) + ".ppm", w, h,
    // (uint32_t*)rendered.data());

    if (!rendered.empty()) {
        // QImage img = QImage(&(rendered[0]), w, h, QImage::Format_RGBA8888)
        //                .mirrored(false, true);
        std::string filename = "tile" + std::to_string(mpiRank) + ".jpg";
        // img.save(filename.c_str(), nullptr, -1);
        stbi_write_jpg(filename.c_str(), w, h, 4, &(rendered[0]), 100);
    }

    const auto   x0 = clamp((int)(tileSize.minimum().x * w), 0, w);
    const auto   y0 = clamp((int)(tileSize.minimum().y * h), 0, w);
    const auto   x1 = clamp((int)(tileSize.maximum().x * w), 0, w);
    const auto   y1 = clamp((int)(tileSize.maximum().y * h), 0, w);
    const size_t tW = (size_t)(x1 - x0);
    const size_t tH = (size_t)(y1 - y0);

    std::cout << x0 << " " << y0 << " " << x1 << " " << y1 << std::endl;

    auto rgba = std::vector<float>(tW * tH * 4);
    for (int y = 0; y < tH; y++) {
        for (int x = 0; x < tW; x++) {
            const auto i    = x0 + x + (y0 + y) * w;
            const auto j    = x + y * tW;
            rgba[j * 4 + 0] = rendered[i * 4 + 0] / 255.f;
            rgba[j * 4 + 1] = rendered[i * 4 + 1] / 255.f;
            rgba[j * 4 + 2] = rendered[i * 4 + 2] / 255.f;
            rgba[j * 4 + 3] = rendered[i * 4 + 3] / 255.f;
            // rgba[j * 4 + 0] = pixels[i * 4 + 0] / 255.f;
            // rgba[j * 4 + 1] = pixels[i * 4 + 1] / 255.f;
            // rgba[j * 4 + 2] = pixels[i * 4 + 2] / 255.f;
            // rgba[j * 4 + 3] = pixels[i * 4 + 3] / 255.f;
        }
    }

    // verified image here
    auto depth = _regions[0].depth;
    auto range = vec4i(x0, y0, x1, y1);
    auto tile =
      v3d::Tile(range, frameSize, rgba.data(), &depth, QCT_TILE_REDUCED_DEPTH);
    auto comp = CreateComposer("icet", w, h);

    comp->beginFrame();
    comp->setTile(tile);
    comp->endFrame();

    if (mpiRank == 0) {
        image buffer((size_t)w * (size_t)h * (size_t)4);
        auto* mapped = (const float*)comp->mapColorBuffer();
        if (solidAlpha) {
            for (int i = 0; i < w * h; i++) {
                const float alpha = mapped[i * 4 + 3];
                buffer[i * 4 + 0] = uint8_t(alpha * mapped[i * 4 + 0] * 255.0);
                buffer[i * 4 + 1] = uint8_t(alpha * mapped[i * 4 + 1] * 255.0);
                buffer[i * 4 + 2] = uint8_t(alpha * mapped[i * 4 + 2] * 255.0);
                buffer[i * 4 + 3] = uint8_t(255);
            }
        }
        else {
            for (int i = 0; i < w * h; i++) {
                buffer[i * 4 + 0] = uint8_t(mapped[i * 4 + 0] * 255.0);
                buffer[i * 4 + 1] = uint8_t(mapped[i * 4 + 1] * 255.0);
                buffer[i * 4 + 2] = uint8_t(mapped[i * 4 + 2] * 255.0);
                buffer[i * 4 + 3] = uint8_t(mapped[i * 4 + 3] * 255.0);
            }
        }
        return std::move(buffer);
    }
    else {
        return std::move(std::vector<uint8_t>());
    }
}

void
DistributedEngine::setFrameBufferSize(vec2i v)
{
    for (auto&& region : _regions) {
        region.volume->resize(v.x, v.y);
        _computeTiles(region);
    }
    _framebuffer->resize(v.x, v.y);
}

void
DistributedEngine::_checkIfScalarMappingRangeHasBeenSet(
  const JsonValue& jsonView)
{
    //    std::cout << JsonParser().stringify(jsonView) << std::endl;
    if (jsonView.contains(VOLUME)) {
        const auto& jsonVolume = jsonView[VOLUME];
        if (jsonVolume.contains(SCALAR_MAPPING_RANGE)) {
            _forceVRange = 1;
        }
    }
    // debug
    int gvalue;
    MPI_Allreduce(&_forceVRange, &gvalue, 1, MPI_INT, MPI_BAND, MPI_COMM_WORLD);
    assert(gvalue == _forceVRange);
}

} // namespace v3d

void
writePPM(const std::string& fileName,
         const uint32_t     width,
         const uint32_t     height,
         const uint32_t*    pixel)
{
    FILE* file = fopen(fileName.c_str(), "wb");
    if (!file) {
        fprintf(
          stderr, "fopen('%s', 'wb') failed: %d", fileName.c_str(), errno);
        return;
    }
    fprintf(file, "P6\n%i %i\n255\n", width, height);
    unsigned char* out = (unsigned char*)alloca(3 * width);
    for (int y = 0; y < height; y++) {
        const unsigned char* in =
          (const unsigned char*)&pixel[(height - 1 - y) * width];
        for (int x = 0; x < width; x++) {
            out[3 * x + 0] = in[4 * x + 0];
            out[3 * x + 1] = in[4 * x + 1];
            out[3 * x + 2] = in[4 * x + 2];
        }
        fwrite(out, 3 * width, sizeof(char), file);
    }
    fprintf(file, "\n");
    fclose(file);
}
void
writePPM(const std::string& fileName,
         const uint32_t     width,
         const uint32_t     height,
         const float*       pixel)
{
    FILE* file = fopen(fileName.c_str(), "wb");
    if (!file) {
        fprintf(
          stderr, "fopen('%s', 'wb') failed: %d", fileName.c_str(), errno);
        return;
    }
    fprintf(file, "P6\n%i %i\n255\n", width, height);
    unsigned char* out = (unsigned char*)alloca(3 * width);
    for (int y = 0; y < height; y++) {
        const float* in = &pixel[(height - 1 - y) * width * 4];
        for (int x = 0; x < width; x++) {
            out[3 * x + 0] = (unsigned char)(in[4 * x + 0] * 255.f);
            out[3 * x + 1] = (unsigned char)(in[4 * x + 1] * 255.f);
            out[3 * x + 2] = (unsigned char)(in[4 * x + 2] * 255.f);
        }
        fwrite(out, 3 * width, sizeof(char), file);
    }
    fprintf(file, "\n");
    fclose(file);
}

V3D_REGISTER_ENGINE(::v3d::DistributedEngine, multi_blocks)
