//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#pragma once

#include <v3d_offscreen_export.h>

#include "v3d/Renderer/FramebufferGL.h"
#include "v3d/Util/JsonParser.h"
#include "v3d/Util/Vector.h"

#include <vidiBase.h>
#include <vidiDynamic.h>

namespace v3d {

class AbstractRenderEngine
  : public vidi::dynamic::TraitParameterized
  , public vidi::dynamic::TraitExternallyNamed {
public:
    using ImageRGBA8 = std::vector<uint8_t>;
    using ImageVec4f = std::vector<float>;

public:
    virtual void resize(int, int)                        = 0;
    virtual void initGPU(std::shared_ptr<FramebufferGL>) = 0;
    virtual void initGPU()                               = 0;
    virtual void loadGPU()                               = 0;
    virtual void freeGPU()                               = 0;
    virtual void render()                                = 0;

    virtual void readData(const JsonValue& jsonData)               = 0;
    virtual void configVolume(const JsonValue& jsonView)           = 0;
    virtual void configCamera(const JsonValue& jsonView)           = 0;
    virtual void configTransferFunction(const JsonValue& jsonView) = 0;
    virtual void fromJsonView(const JsonValue& jsonView)           = 0;
    virtual void toJsonView(JsonValue& jsonView)                   = 0;

    virtual vec2i getFrameBufferSize() const = 0;

    virtual ImageRGBA8 getRenderedFrameRGBA8(bool opaque_background);
    virtual void       getRenderedFrameRGBA8(ImageRGBA8& output,
                                             bool auto_resize,
                                             bool opaque_background);
    virtual ImageVec4f getRenderedFrameVec4f(bool opaque_background);
    virtual void       getRenderedFrameVec4f(ImageVec4f& output,
                                             bool auto_resize,
                                             bool opaque_background);

protected:
    virtual void bindFBO() = 0;
};

std::shared_ptr<AbstractRenderEngine>
CreateRenderEngine(const std::string&);

} // namespace v3d

#define V3D_REGISTER_ENGINE(ic, en) \
    VIDI_REGISTER_OBJECT(           \
      v3d::AbstractRenderEngine, v3d_offscreen_engine, ic, en);
