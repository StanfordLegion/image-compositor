//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "ParameterAPI.h"
#include "Loader/OffScreenDictionary.h"

using vidi::Exception;
using namespace v3d::serializer;

namespace v3d {

void
ParameterAPI::createAndLoad(JsonValue input, std::string project)
{
    auto& jsonData = input.toArray()[0];
    auto  format   = jsonData.fetch(FORMAT).toString();

    if (!project.empty()) {
        jsonData[FILE_LOCATION] = project;
    }
    else {
        jsonData[FILE_LOCATION] = ""; // create the entry in case not exists
    }

    std::string type;
    if (format == REGULAR_GRID_POINTER || format == REGULAR_GRID_RAW_BINARY
#ifdef VIDI_USE_PVM
        || format == REGULAR_GRID_PVM
#endif
    ) {
        type = "regular_grid";
    }
    else if (format == TETRAHEDRAL_GRID_RAW_BINARY ||
             format == TETRAHEDRAL_GRID_FAST || format == TETRAHEDRAL_HO_MESH) {
        type = "tetra_grid";
    }
    else if (format == MULTI_BLOCKS) {
        type = "multi_blocks";
    }
    else {
        ERROR_UNIMPLEMENTED
    }

    if (type != _type) { // avoid frequently recreate engine
        _type   = type;
        _engine = CreateRenderEngine(_type);
    }

    _engine->readData(jsonData);
}

} // namespace v3d
