//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "AbstractRenderEngine.h"

#include <v3d/Renderer/FramebufferGL.h>
#include <vidiBase.h>

using vidi::Exception;

namespace v3d {

AbstractRenderEngine::ImageRGBA8
AbstractRenderEngine::getRenderedFrameRGBA8(bool opaque_background)
{
    ImageRGBA8 buffer;
    getRenderedFrameRGBA8(buffer, true, opaque_background);
    return std::move(buffer);
}

void
AbstractRenderEngine::getRenderedFrameRGBA8(ImageRGBA8& buffer,
                                       bool   auto_resize,
                                       bool   opaque_background)
{

    const auto size = getFrameBufferSize();
    const auto prev = GLFramebufferObject::currentDrawBinding();
    bindFBO();
    V3D_GL_PRINT_ERRORS();

    if (buffer.size() != size_t(size.x) * size_t(size.y) * size_t(4)) {
        if (auto_resize)
            buffer.resize(size_t(size.x) * size_t(size.y) * size_t(4));
        else
            throw Exception("incorrect output buffer size");
    }

    V3D_GL_PRINT_ERRORS();
    GLint rb;
    glGetIntegerv(GL_READ_BUFFER, &rb);
    glReadBuffer(GL_COLOR_ATTACHMENT0);
    glReadPixels(0, 0, size.x, size.y, GL_RGBA, GL_UNSIGNED_BYTE, &(buffer[0]));
    glReadBuffer(GLenum(rb));
    V3D_GL_PRINT_ERRORS();

    GLFramebufferObject::bind(prev);
    V3D_GL_PRINT_ERRORS();

    // TODO multithreading //
    if (opaque_background) {
        for (int i = 0; i < size.x * size.y; i++)
            buffer[i * 4 + 3] = 255;
    }
}

AbstractRenderEngine::ImageVec4f
AbstractRenderEngine::getRenderedFrameVec4f(bool opaque_background)
{
    ImageVec4f buffer;
    getRenderedFrameVec4f(buffer, true, opaque_background);
    return std::move(buffer);
}

void
AbstractRenderEngine::getRenderedFrameVec4f(ImageVec4f& buffer,
                                       bool   auto_resize,
                                       bool   opaque_background)
{

    const auto size = getFrameBufferSize();
    const auto prev = GLFramebufferObject::currentDrawBinding();
    bindFBO();
    V3D_GL_PRINT_ERRORS();

    if (buffer.size() != size_t(size.x) * size_t(size.y) * size_t(4)) {
        if (auto_resize)
            buffer.resize(size_t(size.x) * size_t(size.y) * size_t(4));
        else
            throw Exception("incorrect output buffer size");
    }

    V3D_GL_PRINT_ERRORS();
    GLint rb;
    glGetIntegerv(GL_READ_BUFFER, &rb);
    glReadBuffer(GL_COLOR_ATTACHMENT0);
    glReadPixels(0, 0, size.x, size.y, GL_RGBA, GL_FLOAT, &(buffer[0]));
    glReadBuffer(GLenum(rb));
    V3D_GL_PRINT_ERRORS();

    GLFramebufferObject::bind(prev);
    V3D_GL_PRINT_ERRORS();

    // TODO multithreading //
    if (opaque_background) {
        for (int i = 0; i < size.x * size.y; i++)
            buffer[i * 4 + 3] = 1.f;
    }
}

std::shared_ptr<AbstractRenderEngine>
CreateRenderEngine(const std::string& name)
{
    vidi::dynamic::LibraryRepository::GetInstance()->add("v3d_offscreen");
    return vidi::dynamic::details::objectFactory<AbstractRenderEngine>(name);
}

} // namespace v3d

// TODO remove this //
REGISTER_TYPE(_, ::v3d::AbstractRenderEngine, "v3d_offscreen_engine")
