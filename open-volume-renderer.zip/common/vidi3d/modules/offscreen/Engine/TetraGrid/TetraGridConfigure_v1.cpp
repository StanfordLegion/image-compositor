//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "Loader/AllLoaders.h"
#include "Loader/OffScreenDictionary.h"
#include "TetraGridEngine.h"

#include "v3d/Serializer/CameraSerializer.h"
#include "v3d/Serializer/TransferFunctionSerializer.h"
#include "v3d/Serializer/VectorSerializer.h"
#include "v3d/Serializer/VolumeSceneSerializer.h"
#include "v3d/Serializer/VolumeSerializer.h"

#include <vidiMemory.h>

using vidi::dCastTo;
using vidi::Exception;
using namespace v3d::serializer;

namespace v3d {

void
TetraGridEngine::_readData(const JsonValue& input)
{
    // make a copy of the json data because we might need to fix it.
    JsonValue  dataSource   = input;
    const auto fileLocation = dataSource.fetch(FILE_LOCATION).toString();

    // There might be multiple data inside one scene.
    if (dataSource.isArray()) {
        throw Exception("[Error] TetraGridEngine constructor only accept one "
                        "data source at a time.");
    }
    const std::string format = dataSource.fetch(FORMAT).toString();

    // fix path and load the data
    if (!_data)
        _data = std::make_shared<TetraGridDataGL>();
    if (format == TETRAHEDRAL_GRID_RAW_BINARY) {
        dataSource[GRID_FILE_NAME] = PathRelToAbs(
          dataSource.fetch(GRID_FILE_NAME).toString(), fileLocation);
        dataSource[DATA_FILE_NAME] = PathRelToAbs(
          dataSource.fetch(DATA_FILE_NAME).toString(), fileLocation);
        TetraGridRaw(dataSource, _data.get());
    }
    else if (format == TETRAHEDRAL_HO_MESH) {
        dataSource[GRID_FILE_NAME] = PathRelToAbs(
          dataSource.fetch(GRID_FILE_NAME).toString(), fileLocation);
        dataSource[SOLUTION_FILE_NAME] = PathRelToAbs(
          dataSource.fetch(SOLUTION_FILE_NAME).toString(), fileLocation);
        TetraGridHo(dataSource, _data.get());
    }
    else {
        ERROR_UNIMPLEMENTED
    }
    _dataValueRange = _data->getScalarRange<float>();
}

void
TetraGridEngine::configVolume(const JsonValue& jsonView)
{
    if (jsonView.contains(VOLUME)) {
        fromJson(jsonView[VOLUME], *_volume);
    }
}

void
TetraGridEngine::configTransferFunction(const JsonValue& jsonView)
{
    if (jsonView.contains(VOLUME)) {
        const auto& jsonVolume = jsonView[VOLUME];
        if (jsonVolume.contains(SCALAR_MAPPING_RANGE)) {
            _volume->setScalarMappingRange(
              rangeFromJson(jsonVolume[SCALAR_MAPPING_RANGE]));
        }
        if (jsonVolume.contains(TRANSFER_FUNCTION)) {
            fromJson(jsonVolume[TRANSFER_FUNCTION], *_transferFunction);
            _transferFunction->updateColorMap();
            _volume->setTransferFunctionDirty(true);
            _volume->setTransferFunctionDirtyCoarse(true);
        }
    }
}

void
TetraGridEngine::configCamera(const JsonValue& jsonView)
{
    if (jsonView.contains(CAMERA)) {
        fromJson<Camera>(jsonView[CAMERA], *_camera);
    }
}

void
TetraGridEngine::fromJsonView(const JsonValue& jsonView)
{
    fromJson(jsonView, *_scene);
    configVolume(jsonView);
    configCamera(jsonView);
    configTransferFunction(jsonView);
}

void
TetraGridEngine::toJsonView(JsonValue& jsonView)
{
    jsonView[METHOD_] = "TETRAHEDRAL_GRID_VOLUME_RAY_CASTING";
    jsonView[CAMERA]  = toJson(*_camera);
    jsonView[VOLUME]; /* do nothing */
    jsonView[VOLUME][TRANSFER_FUNCTION] = toJson(*_transferFunction);
    toJson2(*_scene, jsonView);
}

}
