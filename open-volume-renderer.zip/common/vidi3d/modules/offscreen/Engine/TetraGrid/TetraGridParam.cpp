//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "TetraGridEngine.h"
#include <vidiMemory.h>

using vidi::dCastTo;

namespace v3d {

vec2d
TetraGridEngine::getDataRange() const
{
    return _dataValueRange;
}

vec2i
TetraGridEngine::getFrameBufferSize() const
{
    return vec2i(_renderer->width(), _renderer->height());
}

void
TetraGridEngine::setBoundingBox(vidi::box3f box)
{
    _volume->setBoundingBox(box);
    if (!_boundaryGeometry->clippingBox().contains(box)) {
        _boundaryGeometry->setClippingBox(box);
    }
}

void
TetraGridEngine::setClippingBox(vidi::box3f box)
{
    _boundaryGeometry->setClippingBox(box);
}

void
TetraGridEngine::setFrameBufferSize(vidi::vec2i size)
{
    _renderer->resize(size.x, size.y);
    _framebuffer->resize(size.x, size.y);
}

void
TetraGridEngine::setScalarMappingRange(vidi::vec2d range)
{
    _volume->setScalarMappingRange(range);
}

void
TetraGridEngine::setCameraFocusBox(vidi::box3f box)
{
    const vec3   boxDim = box.size();
    const vec3   boxCen = box.center();
    const double maxDim = max(max(boxDim.x, boxDim.y), boxDim.z);
    _camera->setEye(dvec3(boxCen) + dvec3(boxDim) * dvec3(0.0, 0.0, 2.5));
    _camera->setCenter(dvec3(boxCen));
    _camera->setUp(dvec3(0.0, 1.0, 0.0));
    _camera->setNear(maxDim * 0.001);
    _camera->setFar(maxDim * 10.0);
}

}
