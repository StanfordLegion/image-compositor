//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#pragma once

#include "Engine/AbstractRenderEngine.h"

#include "v3d/Data/TetraGridDataGL.h"
#include "v3d/Renderer/GeometryProperty.h"
#include "v3d/Renderer/TetraGridPipelineGL.h"
#include "v3d/Renderer/TetraGridSceneGL.h"
#include "v3d/Renderer/TetraGridVolumeGL.h"
#include "v3d/Util/Camera.h"
#include "v3d/Util/JsonParser.h"
#include "v3d/Util/OcclusionTransferFunction.h"
#include "v3d/Util/TransferFunction.h"

namespace v3d {

class TetraGridEngine : public AbstractRenderEngine {
public:
    TetraGridEngine();

    void resize(int, int) override;
    void initGPU() override;
    void initGPU(std::shared_ptr<FramebufferGL>) override;
    void loadGPU() override;
    void freeGPU() override;
    void render() override;
    void bindFBO() override;

    void readData(const JsonValue& dataSource) override;
    void configVolume(const JsonValue& jsonView) override;
    void configCamera(const JsonValue& jsonView) override;
    void configTransferFunction(const JsonValue& jsonView) override;
    void fromJsonView(const JsonValue& jsonView) override;
    void toJsonView(JsonValue& jsonView) override;

    vec2i getFrameBufferSize() const override;

private:
    vec2d getDataRange() const;
    void  setFrameBufferSize(vec2i);
    void  setBoundingBox(box3f);
    void  setClippingBox(box3f);
    void  setScalarMappingRange(vec2d);
    void  setCameraFocusBox(box3f);
    void  _readData(const JsonValue& dataSource);
    void  _setup() override;

private:
    bool                                 _initialized = false;
    JsonValue                            _jsonDataSource;
    vec2f                                _dataValueRange;
    std::shared_ptr<TetraGridDataGL>     _data             = nullptr;
    std::shared_ptr<TetraGridVolumeGL>   _volume           = nullptr;
    std::shared_ptr<TetraGridSceneGL>    _scene            = nullptr;
    std::shared_ptr<TetraGridPipelineGL> _renderer         = nullptr;
    std::shared_ptr<Camera>              _camera           = nullptr;
    std::shared_ptr<TransferFunction>    _transferFunction = nullptr;
    std::shared_ptr<GeometryProperty>    _boundaryGeometry = nullptr;
    std::shared_ptr<FramebufferGL>       _framebuffer      = nullptr;
};

} // namespace v3d
