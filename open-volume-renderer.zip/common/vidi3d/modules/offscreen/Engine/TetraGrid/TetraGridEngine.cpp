//===========================================================================//
//                                                                           //
// LibViDi3D                                                                 //
// Copyright(c) 2018 Qi Wu (Wilson)                                          //
// University of California, Davis                                           //
// MIT Licensed                                                              //
//                                                                           //
//===========================================================================//

#include "TetraGridEngine.h"
#include "Loader/AllLoaders.h"
#include "Loader/OffScreenDictionary.h"

#include "v3d/Serializer/CameraSerializer.h"
#include "v3d/Serializer/TransferFunctionSerializer.h"
#include "v3d/Serializer/VolumeSceneSerializer.h"
#include "v3d/Serializer/VolumeSerializer.h"

#include <vidiMemory.h>

using vidi::dCastTo;
using vidi::Exception;
using namespace v3d::serializer;

namespace v3d {

void
TetraGridEngine::_setup()
{
    _defineParameter<vec2i>("fbSize", [=](vec2i v) { setFrameBufferSize(v); });
}

TetraGridEngine::TetraGridEngine()
{
    _setup();
}

void
TetraGridEngine::resize(int x, int y)
{
    setFrameBufferSize(vec2i(x, y));
}

void
TetraGridEngine::initGPU()
{
    // assume we have loaded the data
    assert(_data != nullptr);

    // avoid multiple initialization
    if (_initialized) {
        return;
    }

    // the framebuffer is own by the class, thus we have to resize after
    // initialization
    auto fbo = std::make_shared<FramebufferGL>(1, 1);

    // okay, initialize everything
    initGPU(fbo);

    // finally resize image
    setFrameBufferSize(vec2i(600, 600));
}

void
TetraGridEngine::initGPU(std::shared_ptr<FramebufferGL> fbo)
{
    // assume we have loaded the data
    assert(_data != nullptr);

    // avoid multiple initialization
    if (_initialized) {
        return;
    }
    _initialized = true;

    // create members
    _volume           = std::make_shared<TetraGridVolumeGL>();
    _scene            = std::make_shared<TetraGridSceneGL>();
    _renderer         = std::make_shared<TetraGridPipelineGL>();
    _camera           = std::make_shared<Camera>();
    _transferFunction = std::move(TransferFunction::fromRainbowMap());
    _boundaryGeometry = std::make_shared<GeometryProperty>();
    _framebuffer      = std::move(fbo);

    // setup relationship
    _volume->setData(_data);
    _volume->setTransferFunction(_transferFunction);
    _scene->setVolume(_volume);
    _scene->setCamera(_camera);
    _renderer->setScene(_scene);
    _renderer->setBoundaryGeometryProperty(_boundaryGeometry);
    _renderer->setFramebufferObject(_framebuffer->sharedFramebufferObject());

    // processing data
    const box3f bbox   = _data->getBoundingBox();
    const vec3f boxDim = bbox.size();
    const vec3f boxCen = bbox.center();
    const box3f cbox =
      box3f(bbox.minimum() - boxDim * 0.01f, bbox.maximum() + boxDim * 0.01f);
    const double maxDim   = max(max(boxDim.x, boxDim.y), boxDim.z);
    const float  stepSize = (float)maxDim / 256.f;

    // boundary geometry
    auto geomMat = Material();
    geomMat.setAmbient(
      vec4(0.2f, 0.2f, 0.2f, 1.0f)); // transparent geometry does not work
    geomMat.setDiffuse(vec4(0.8f, 0.8f, 0.8f, 1.0f));

    // setup
    _volume->setScalarMappingRange(_dataValueRange); // sync for distributed
    _volume->setBoundingBox(bbox);
    _volume->setSampleDistance(stepSize);
    _volume->setOpacityUnitDistance(stepSize);
    _volume->setSamplesPerCell(2);
    _scene->setTFPreIntegration(true);
    _scene->setBackgroundColor(vec4(0.0f, 0.0f, 0.0f, 0.0f));
    _scene->setLighting(true);
    _boundaryGeometry->setVisible(false); // enable this to display the geometry
    _boundaryGeometry->setFrontMaterial(geomMat);
    _boundaryGeometry->setClippingBox(cbox);
}

void
TetraGridEngine::readData(const JsonValue& dataSource)
{
    _jsonDataSource = dataSource;
    _readData(_jsonDataSource);
}

void
TetraGridEngine::loadGPU()
{
    _data->grid()->loadGL();
    _data->loadGL();
}

void
TetraGridEngine::freeGPU()
{
    _data->grid()->unloadGL();
    _data->unloadGL();
}

void
TetraGridEngine::render()
{
    glFinish();
    _renderer->render();
    glFinish();
}

void
TetraGridEngine::bindFBO()
{
    _framebuffer->bind();
}

} // namespace v3d

V3D_REGISTER_ENGINE(v3d::TetraGridEngine, tetra_grid)
