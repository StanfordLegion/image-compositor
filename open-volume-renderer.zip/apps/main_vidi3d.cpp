//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "common/imageio.h"
#include "common/vidi_fps_counter.h"
#include "renderer.h"

#include <Engine/ParameterAPI.h>
#include <Engine/PipelineAPI.h>
#include <Engine/RegularGrid/RegularGridEngine.h>
#include <Util/DXGL.h>
#include <v3d/Renderer/FramebufferGL.h>

#include <3rdparty/json.hpp>
#include <glfwapp/camera_frame.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <fstream>
#include <iostream>
#include <string>

using namespace ovr::math;
using ovr::Camera;
using ovr::MainRenderer;

using vidi::FPSCounter;

struct EngineVidi3d {
  using client_t = std::shared_ptr<v3d::PipelineAPI>;

  client_t engine;
  int W = 3840, H = 2160;

  EngineVidi3d(int W, int H, std::string data) : W(W), H(H)
  {
    engine = std::make_shared<v3d::PipelineAPI>(W, H, data);
    engine->loadCPU();
    engine->commitDataCPU();
    engine->loadGPU();
    engine->commitDataGPU();
    engine->commitViewCPU();
    engine->commitViewGPU();
  }

  ~EngineVidi3d()
  {
    engine->unloadGPU();
    engine->unloadCPU();
  }

  void update(std::string file)
  {
    v3d::JsonValue json;
    v3d::JsonParser().load(file, json);
    engine->configureFromJson(json);
    engine->commitViewCPU();
    engine->commitViewGPU();
  }

  void update_str(std::string str)
  {
    v3d::JsonValue json = v3d::JsonParser().parse(str);
    engine->configureFromJson(json);
    engine->commitViewCPU();
    engine->commitViewGPU();
  }

  void render(std::string filename)
  {
    engine->render();

    // auto buffer = engine->getFrameAsBufferRGBA8(true);
    // ovr::save_image(filename, (uint32_t*)buffer.data(), W, H);

    auto buffer = engine->getFrameAsBufferVec4f(true);
    ovr::save_image(filename, (vec4f*)buffer.data(), W, H);
  }
};

using json = nlohmann::json;

vec3f
json_to_vec3f(const json& in)
{
  return vec3f(in["x"].get<float>(), in["y"].get<float>(), in["z"].get<float>());
}

json
vec3f_to_json(const vec3f& in)
{
  json out;
  out["x"] = in.x;
  out["y"] = in.y;
  out["z"] = in.z;
  return out;
}

int
execute_libvidi3d(int max_num_frames, std::string fname)
{
  json root;
  {
    std::ifstream rs(fname);
    rs >> root;
  }

  EngineVidi3d engine(1920, 1080, fname);
  engine.render(fname + ".reference.exr");

  Camera camera = { /*from*/ json_to_vec3f(root["view"]["camera"]["eye"]),
                    /* at */ json_to_vec3f(root["view"]["camera"]["center"]),
                    /* up */ json_to_vec3f(root["view"]["camera"]["up"]) };
  auto camera_frame = glfwapp::CameraFrame(100.f);
  camera_frame.setOrientation(camera.from, camera.at, camera.up);

  /* generate secret number between 1 and 10: */
  auto R = camera_frame.get_focal_length();
  auto M = linear3f(camera_frame.get_frame_x(), camera_frame.get_frame_y(), camera_frame.get_frame_z());

  float t = 0;
  for (int frame_index = 0; frame_index < max_num_frames; ++frame_index) {
    const vec3f poi = camera_frame.get_poi();
    float theta = sin(7.f * t + 0.1f) * 0.5f * M_PI;
    float phi = sin(6.f * t) * M_PI;
    float r = R * (1 + 0.1f * sin(5.f * t));
    float x = r * cos(phi) * sin(theta);
    float y = r * sin(phi) * sin(theta);
    float z = r * cos(theta);
    auto c = xfmVector(M, vec3f(x, y, z));
    camera_frame.setOrientation(c + poi, poi, camera_frame.get_accurate_up());
    t += 2.f * M_PI / max_num_frames;

    root["view"]["camera"]["eye"] = vec3f_to_json(camera_frame.get_position());
    root["view"]["camera"]["center"] = vec3f_to_json(camera_frame.get_poi());
    root["view"]["camera"]["up"] = vec3f_to_json(camera_frame.get_accurate_up());

    auto s = root.dump();

    // std::ofstream out("tmp.json");
    // out << s;
    // out.close();

    // auto exe = std::string("C:\\Users\\wilson\\Work\\project\\vidi-libvidi3d\\cmdline\\build\\Debug\\vidi3d.exe");
    // auto cmd = exe + " tmp.json --no-gui --screenshot ";
    // cmd += fname + "." + std::to_string(frame_index) + ".png --image-size 3840 2160 --batch";
    // std::cout << cmd << std::endl;
    // system(cmd.c_str());

    // engine.update("tmp.json");
    engine.update_str(s);

    engine.render(fname + "." + std::to_string(frame_index) + ".exr");
  }

  return 0;
}

/*! main entry point to this example - initially optix, print hello
  world, then exit */
extern "C" int
main(int ac, const char** av)
{
  v3d::DXGL_create();             // load modules, load all shaders
  v3d::DXGL_init(ac, (char**)av); // we should actually call this in the GPU thread

  for (int i = 2; i < ac; ++i) {
    execute_libvidi3d(std::stoi(av[1]), std::string(av[i]));
  }

  v3d::DXGL_exit();
  return 0;
}
