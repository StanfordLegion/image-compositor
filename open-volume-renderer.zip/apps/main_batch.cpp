//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "common/imageio.h"
#include "common/vidi_fps_counter.h"
#include "renderer.h"

#include <3rdparty/json.hpp>
#include <glfwapp/camera_frame.h>

#include <colormap.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <fstream>
#include <iostream>
#include <random>
#include <string>

using namespace ovr::math;
using ovr::Camera;
using ovr::MainRenderer;

using vidi::FPSCounter;

ovr::Scene
create_vorts_scene(int i)
{
  using namespace ovr;

  static std::random_device rng_device;  // Will be used to obtain a seed for the random number engine
  static std::mt19937 rng(rng_device()); // Standard mersenne_twister_engine seeded with rng()
  static std::uniform_int_distribution<> index(0, colormap::name.size() - 1ULL);

  scene::TransferFunction tfn;

  /* 0.0070086f, 12.1394f */
  scene::Volume volume;
  volume.type = scene::Volume::STRUCTURED_REGULAR_VOLUME;
  volume.structured_regular.data = CreateArray3DScalarFromFile(
    std::string("../vortices/vorts") + std::to_string(i) + ".data", vec3i(128, 128, 128), VALUE_TYPE_FLOAT, 0, false);
  volume.structured_regular.grid_origin = -vec3i(128, 128, 128) * 2.f;
  volume.structured_regular.grid_spacing = 4.f;
  tfn.value_range = vec2f(0.0, 12.0);
  tfn.color = CreateColorMap("sequential2/summer");
  tfn.opacity = CreateArray1DScalar(std::vector<float>{ 0.f, 0.f, 0.01f, 0.2f, 0.01f, 0.f, 0.f });

  scene::Model model;
  model.type = scene::Model::VOLUMETRIC_MODEL;
  model.volume_model.volume = volume;
  model.volume_model.transfer_function = tfn;

  scene::Instance instance;
  instance.models.push_back(model);
  instance.transform = affine3f::translate(vec3f(0));

  scene::Scene scene;
  scene.instances.push_back(instance);

  return scene;
}

void
render_a_frame(std::shared_ptr<MainRenderer> ren_ospray,
               std::shared_ptr<MainRenderer> ren_optix7,
               vec2i frame_size,
               int frame_index,
               float max_variance,
               int max_spp,
               glfwapp::CameraFrame camera)
{
  MainRenderer::FrameBufferData pixels;
  float variance;

  ren_optix7->set_camera(camera.get_position(), camera.get_poi(), camera.get_accurate_up());
  ren_optix7->commit();
  ren_optix7->render();
  ren_optix7->mapframe(&pixels);
  ovr::save_image("output" + std::to_string(frame_index) + "grad.exr", (vec3f*)pixels.grad->to_cpu()->data(), /**/
                  frame_size.x, frame_size.y);

  ren_ospray->set_camera(camera.get_position(), camera.get_poi(), camera.get_accurate_up());

  ren_ospray->set_sample_per_pixel(1);
  ren_ospray->commit();
  ren_ospray->render();
  ren_ospray->mapframe(&pixels);
  ovr::save_image("input" + std::to_string(frame_index) + "spp1.exr", (vec4f*)pixels.rgba->to_cpu()->data(),
                  /**/ frame_size.x, frame_size.y);

  ren_ospray->set_sample_per_pixel(2);
  ren_ospray->commit();
  ren_ospray->render();
  ren_ospray->mapframe(&pixels);
  ovr::save_image("input" + std::to_string(frame_index) + "spp2.exr", (vec4f*)pixels.rgba->to_cpu()->data(),
                  /**/ frame_size.x, frame_size.y);

  ren_ospray->set_sample_per_pixel(4);
  ren_ospray->commit();
  ren_ospray->render();
  ren_ospray->mapframe(&pixels);
  ovr::save_image("input" + std::to_string(frame_index) + "spp4.exr", (vec4f*)pixels.rgba->to_cpu()->data(),
                  /**/ frame_size.x, frame_size.y);

  ren_ospray->set_sample_per_pixel(8);
  ren_ospray->commit();
  ren_ospray->render();
  ren_ospray->mapframe(&pixels);
  ovr::save_image("input" + std::to_string(frame_index) + "spp8.exr", (vec4f*)pixels.rgba->to_cpu()->data(),
                  /**/ frame_size.x, frame_size.y);

  ren_ospray->set_sample_per_pixel(max_spp);
  ren_ospray->commit();
  do {
    ren_ospray->render();
    variance = ren_ospray->unsafe_get_variance();
    std::cout << " - " << variance << std::endl;
  } while (variance > max_variance);

  ren_ospray->mapframe(&pixels);
  ovr::save_image("output" + std::to_string(frame_index) + ".var" + std::to_string(variance) + ".exr",
                  (vec4f*)pixels.rgba->to_cpu()->data(), frame_size.x, frame_size.y);
}

void
render_a_frame(std::shared_ptr<MainRenderer> ren,
               vec2i frame_size,
               int frame_index,
               glfwapp::CameraFrame camera,
               int max_num_focuses)
{
  static std::random_device rng_device;  // Will be used to obtain a seed for the random number engine
  static std::mt19937 rng(rng_device()); // Standard mersenne_twister_engine seeded with rng()
  static std::uniform_real_distribution<float> coordinate(0.f, 1.f);

  MainRenderer::FrameBufferData pixels;

  auto render_it = [&](int i) {
    ren->commit();
    ren->render();
    ren->mapframe(&pixels);
    ovr::save_image("output" + std::to_string(frame_index) + "-" + std::to_string(i) + "-rgba.png", //
                    (vec4f*)pixels.rgba->to_cpu()->data(), frame_size.x, frame_size.y);             //
    // ovr::save_image("output" + std::to_string(frame_index) + "-" + std::to_string(i) + "-grad.png", //
    //                 (vec3f*)pixels.grad->to_cpu()->data(), frame_size.x, frame_size.y);             //
  };

  ren->set_camera(camera.get_position(), camera.get_poi(), camera.get_accurate_up());
  ren->set_sparse_sampling(false);
  render_it(0);
  
  if (max_num_focuses == 0) return;

  if (max_num_focuses == 0) return;

  ren->set_sparse_sampling(true);
  {
    std::ofstream log;
    log.open("output" + std::to_string(frame_index) + "-camera.txt");

    auto render_it_sparsely = [&](int i, vec2f c, double s) {
      log << "(" << c.x << ", " << c.y << ")\t" << s << "\t" << 0.1f << std::endl;
      ren->set_focus(c, (float)s, 0.05f);
      render_it(i);
    };

    vec2f center;
    double scale;

    for (int i = 0; i < max_num_focuses; ++i) {
      /* generate secret number between 1 and 10: */
      center.x = coordinate(rng);
      center.y = coordinate(rng);
      scale = 0.2 + 0.2 * (coordinate(rng) - 0.5);
      render_it_sparsely(1 + i, center, scale);
    }

    log.close();
  }
}

/*! main entry point to this example - initially optix, print hello world, then exit */
extern "C" int
main(int ac, const char** av)
{
  int max_num_frames = 2;
  int max_num_focuses = 2;
  int max_spp = 1;
  float max_variance = 12.0f;

  std::string scene_name;
  std::string render_mode;

  ovr::Scene scene;
  bool scene_created = false;

  int ai = 1;
  while (ai < ac) {
    std::string arg(av[ai++]);

    if (arg == "--max-num-frames") {
      if (ac < ai + 1) {
        throw std::runtime_error("improper --max-num-frames arguments");
      }
      max_num_frames = std::stoi(av[ai++]);
    }

    else if (arg == "--max-num-focuses") {
      if (ac < ai + 1) {
        throw std::runtime_error("improper --max-num-focuses arguments");
      }
      max_num_focuses = std::stoi(av[ai++]);
    }

    else if (arg == "--max-spp") {
      if (ac < ai + 1) {
        throw std::runtime_error("improper --max-spp arguments");
      }
      max_spp = std::stoi(av[ai++]);
    }

    else if (arg == "--max-variance") {
      if (ac < ai + 1) {
        throw std::runtime_error("improper --max-variance arguments");
      }
      max_variance = std::stoi(av[ai++]);
    }

    else if (arg == "--scene-vorts") {
      if (ac < ai + 1) {
        throw std::runtime_error("improper --scene-vorts arguments");
      }
      scene = create_vorts_scene(std::stoi(av[ai++]));
      scene_created = true;
    }

    else if (arg == "--scene-vidi3d") {
      if (ac < ai + 1) {
        throw std::runtime_error("improper --scene-vidi3d arguments");
      }
      scene = ovr::scene::create_json_scene(std::string(av[ai++]));
      scene_created = true;
    }

    else if (arg == "--render-ospray") {
      render_mode = "ospray";
    }

    else {
      std::cerr << "unknown argument " << arg << std::endl;
      throw std::runtime_error("unknown switch argument '" + arg + "'");
    }
  }

  Camera camera = { /*from*/ vec3f(0.f, 0.f, -800.f),
                    /* at */ vec3f(0.f, 0.f, 0.f),
                    /* up */ vec3f(0.f, 1.f, 0.f) };
  
  if (!scene_created) {
    scene = create_example_scene();
  }
  else {
    camera = scene.camera;
  }

  vec2i fbsize(800, 800);

  auto camera_frame = glfwapp::CameraFrame(100.f);
  camera_frame.setOrientation(camera.from, camera.at, camera.up);

  // auto ren_optix7 = create_renderer("optix7");
  // ren_optix7->init(ac, av, scene, camera);
  // ren_optix7->set_fbsize(fbsize);

  // auto ren_ospray = create_renderer("ospray");
  // ren_ospray->init(ac, av, scene, camera);
  // ren_ospray->set_fbsize(fbsize);

  auto ren = create_renderer("ospray");
  ren->set_fbsize(fbsize);
  ren->set_frame_accumulation(false);
  ren->set_path_tracing(false);
  // ren->set_sample_per_pixel(1);
  // ren->set_volume_sampling_rate(5.f);
  ren->init(ac, av, scene, camera);

  ren->commit();

  // render_a_frame(ren_ospray, ren_optix7, fbsize, 0, max_variance, camera_frame);
  render_a_frame(ren, fbsize, 0, camera_frame, 0);

#if 0
  /* generate secret number between 1 and 10: */
  auto R = camera_frame.get_focal_length();
  auto M = linear3f(camera_frame.get_frame_x(), camera_frame.get_frame_y(), camera_frame.get_frame_z());

  float t = 0;
  for (int frame_index = 0; frame_index < max_num_frames; ++frame_index) {
    const vec3f poi = camera_frame.get_poi();
    float theta = sin(13.f * t) * M_PI;
    float phi = cos(5.f * t) * M_PI;
    float r = R * (0.6 + 0.1f * sin(6.f * t));
    float x = r * cos(phi) * sin(theta);
    float y = r * sin(phi) * sin(theta);
    float z = r * cos(theta);
    auto c = xfmVector(M, vec3f(x, y, z));
    std::cout << "camera pos = " << c.x << " " << c.y << " " << c.z << std::endl;
    camera_frame.setOrientation(c + poi, poi, camera_frame.get_accurate_up());
    t += 16.f * M_PI / max_num_frames;

    // render_a_frame(ren_ospray, ren_optix7, fbsize, frame_index, max_variance, camera_frame);
    render_a_frame(ren, fbsize, frame_index, camera_frame, max_num_focuses);
  }
#endif

  return 0;
}
