#!/bin/bash

tar czvf open-volume-renderer.tar.gz \
    apps  \
    CMakeLists.txt \
    create_package.sh \
    experiment \
    extern \
    ovr \
    data/noise \
    LICENSE \
    README.md
