//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "volume.h"
#include "cuda_functions.h"

namespace ovr::nncache {

// ------------------------------------------------------------------
//
// ------------------------------------------------------------------

void
StructuredRegularVolume::transform(float transform[12]) const
{
  transform[0]  = matrix.l.row0().x;
  transform[1]  = matrix.l.row0().y;
  transform[2]  = matrix.l.row0().z;
  transform[3]  = matrix.p.x;
  transform[4]  = matrix.l.row1().x;
  transform[5]  = matrix.l.row1().y;
  transform[6]  = matrix.l.row1().z;
  transform[7]  = matrix.p.y;
  transform[8]  = matrix.l.row2().x;
  transform[9]  = matrix.l.row2().y;
  transform[10] = matrix.l.row2().z;
  transform[11] = matrix.p.z;
}

// ------------------------------------------------------------------
//
// ------------------------------------------------------------------

// ------------------------------------------------------------------
//
// ------------------------------------------------------------------

void
StructuredRegularVolume::set_transfer_function(Array1DFloat4CUDA c, Array1DScalarCUDA a, vec2f r)
{
  self.tfn.color = c;
  self.tfn.opacity = a;

  set_value_range(r.x, r.y);

  CUDA_SYNC_CHECK();
}

void
StructuredRegularVolume::set_transfer_function(array_1d_float4_t c, array_1d_scalar_t a, vec2f r)
{
  set_transfer_function(CreateArray1DFloat4CUDA(c), CreateArray1DScalarCUDA(a), r);
}

void
StructuredRegularVolume::set_transfer_function(const std::vector<float>& c, const std::vector<float>& o, const vec2f& r)
{
  tfn_colors_data.resize(c.size() / 3);
  for (int i = 0; i < tfn_colors_data.size(); ++i) {
    tfn_colors_data[i].x = c[3 * i + 0];
    tfn_colors_data[i].y = c[3 * i + 1];
    tfn_colors_data[i].z = c[3 * i + 2];
    tfn_colors_data[i].w = 1.f;
  }
  tfn_alphas_data.resize(o.size() / 2);
  for (int i = 0; i < tfn_alphas_data.size(); ++i) {
    tfn_alphas_data[i] = o[2 * i + 1];
  }

  if (!tfn_colors_data.empty() && !tfn_alphas_data.empty())
    set_transfer_function(CreateArray1DFloat4CUDA(tfn_colors_data), CreateArray1DScalarCUDA(tfn_alphas_data), r);

  CUDA_SYNC_CHECK();
}

void
StructuredRegularVolume::set_value_range(float data_value_min, float data_value_max)
{
  Array3DScalarCUDA& volume = self.volume;

  if (data_value_max >= data_value_min) {
    float normalized_max = integer_normalize(data_value_max, volume.type);
    float normalized_min = integer_normalize(data_value_min, volume.type);
    // volume.upper.v = min(original_value_range.y, normalized_max);
    // volume.lower.v = max(original_value_range.x, normalized_min);
    volume.upper.v = normalized_max; // should use the transfer function value range here
    volume.lower.v = normalized_min;    
  }

  volume.scale.v = 1.f / (volume.upper.v - volume.lower.v);

  // Need calculation on max opacity
  auto r_x = max(original_value_range.x, volume.lower.v);
  auto r_y = min(original_value_range.y, volume.upper.v);

  self.tfn.value_range.y = r_y;
  self.tfn.value_range.x = r_x;
  self.tfn.range_rcp_norm = 1.f / (self.tfn.value_range.y - self.tfn.value_range.x);
}

void
StructuredRegularVolume::set_sampling_rate(float r)
{
  sampling_rate = r;
}

void*
StructuredRegularVolume::get_device_pointer(cudaStream_t stream)
{
  return (void*)self_buffer.d_pointer();
}

void
StructuredRegularVolume::commit(cudaStream_t stream)
{
  self.step = 1.f / sampling_rate;
  self.step_rcp = sampling_rate;
  self.grad_step = vec3f(1.f / vec3f(self.volume.dims));

  self.transform = matrix;

  self_buffer.resize(sizeof(self));
  self_buffer.upload_async(&self, 1, stream);
}

void
StructuredRegularVolume::load_from_array3d_scalar(array_3d_scalar_t array, float data_value_min, float data_value_max)
{
  Array3DScalarCUDA& output = self.volume;

  output = CreateArray3DScalarCUDA(array);
  original_value_range.x = output.lower.v;
  original_value_range.y = output.upper.v;
  std::cout << "[nncache] volume range = " << original_value_range.x << " " << original_value_range.y << std::endl;

  set_value_range(data_value_min, data_value_max);
}

}
