#pragma once

#include "ovr/common/cuda_buffer.h"
#include "ovr/common/math.h"

#include "volume.h"

namespace ovr {
namespace nncache {

using DeviceVolume = DeviceStructuredRegularVolume;

struct Ray {
  vec3f org{};
  vec3f dir{};
  float tnear{};
  float tfar {};
  bool shadow{false};
  uint32_t pidx{0};
};

struct PhongMaterial {
  float ambient;
  float diffuse;
  float specular;
  float shininess;
};

struct LaunchParams { // shared global data
  struct DeviceFrameBuffer {
    vec4f* rgba;
    vec2i size;
  } frame;
  vec4f* accumulation;
  int32_t frame_index{ 0 };

  struct DeviceCamera {
    vec3f position;
    vec3f direction;
    vec3f horizontal;
    vec3f vertical;
  } camera;

  bool enable_sparse_sampling{ false };
  bool enable_path_tracing{ false };
  bool enable_frame_accumulation{ false };

  vec3f light_directional_pos{ -907.108f, 2205.875f, -400.0267f };
  vec3f light_directional_intensity{ 1.f };
  float light_ambient_intensity{ 1.f };

  PhongMaterial mat_scivis{ .6f, .9f, .4f, 40.f };
};

class Renderer {
public:
  void render_path_tracing(cudaStream_t stream, LaunchParams& params, void* volume, bool reset_accumulation);
  void render_ray_marching(cudaStream_t stream, LaunchParams& params, void* volume, bool reset_accumulation);
  void pre_render(cudaStream_t stream, LaunchParams& params, void* volume, bool reset_accumulation);

private:
  CUDABuffer params_buffer;
  CUDABuffer accumulation_buffer;
};

}
} // namespace ovr
