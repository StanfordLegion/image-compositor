#include "device.h"
#include "array.h"
#include "framebuffer.h"
#include "cuda_functions.h"

#include <string>
#include <thread>

namespace ovr::nncache {

using HostVolume   = StructuredRegularVolume;
using DeviceVolume = DeviceStructuredRegularVolume;
using FrameBuffer  = DoubleBufferObject<vec4f>;

// ------------------------------------------------------------------
// ------------------------------------------------------------------

struct DeviceNNCache::Impl {
  DeviceNNCache* parent{ nullptr };

  int buffer_index = 0;

  FrameBuffer framebuffer;
  cudaStream_t framebuffer_stream{};
  bool framebuffer_size_updated{ false };
  bool framebuffer_reset{ false };

  HostVolume volume;
  bool volumes_changed{ true };

  LaunchParams params;

  Renderer renderer;

public:
  ~Impl() {}

  Impl() {}

  void init(int argc, const char** argv, DeviceNNCache* p)
  {
    if (parent) throw std::runtime_error("[nncache] device already initialized!");
    parent = p;

    framebuffer.create();
    const auto& scene = parent->current_scene;
    assert(scene.instances.size() == 1 && "[nncache] only accept one instance");
    assert(scene.instances[0].models.size() == 1 && "[nncache] only accept one model");
    assert(scene.instances[0].models[0].type == scene::Model::VOLUMETRIC_MODEL && "[nncache] only accept volume");
    assert(scene.instances[0].models[0].volume_model.volume.type == scene::Volume::STRUCTURED_REGULAR_VOLUME && "[nncache] only accept structured regular volume");

    auto& st = scene.instances[0].models[0].volume_model.transfer_function;
    auto& sv = scene.instances[0].models[0].volume_model.volume.structured_regular;

    vec3f scale = sv.grid_spacing * vec3f(sv.data->dims);
    vec3f translate = sv.grid_origin;

    volume.matrix = affine3f::translate(translate) * affine3f::scale(scale);
    volume.load_from_array3d_scalar(sv.data);
    volume.set_sampling_rate(scene.volume_sampling_rate);
    volume.set_transfer_function(CreateArray1DFloat4CUDA(st.color), CreateArray1DScalarCUDA(st.opacity), st.value_range);
    parent->params.tfn.assign([&](TransferFunctionData& d) {
      d.tfn_value_range = st.value_range;
    });
  }

  void swap()
  {
    buffer_index = (buffer_index + 1) % 2;
  }

  void commit()
  {
    if (parent->params.fbsize.update()) {
      CUDA_SYNC_CHECK(); /* stio all async rendering */
      params.frame.size = parent->params.fbsize.ref();
      framebuffer.resize(parent->params.fbsize.ref());
      framebuffer_size_updated = true;
      framebuffer_reset = true;
    }

    /* commit other data */
    if (parent->params.camera.update() || framebuffer_size_updated) {
      Camera camera = parent->params.camera.ref();

      /* the factor '2.f' here might be unnecessary, but I want to match ospray's implementation */
      const float fovy = camera.perspective.fovy;
      const float t = 2.f /* (note above) */ * tan(fovy * 0.5f * M_PI / 180.f);
      const float aspect = params.frame.size.x / float(params.frame.size.y);

      params.camera.position = camera.from;
      params.camera.direction = normalize(camera.at - camera.from);
      params.camera.horizontal = t * aspect * normalize(cross(params.camera.direction, camera.up));
      params.camera.vertical = cross(params.camera.horizontal, params.camera.direction) / aspect;

      framebuffer_reset = true;
    }

    if (parent->params.tfn.update()) {
      const auto& tfn = parent->params.tfn.ref();
      volume.set_transfer_function(tfn.tfn_colors, tfn.tfn_alphas, tfn.tfn_value_range);
      volumes_changed = true;
      framebuffer_reset = true;
    }

    if (parent->params.path_tracing.update()) {
      params.enable_path_tracing = parent->params.path_tracing.ref();
      framebuffer_reset = true;
    }

    if (parent->params.sparse_sampling.update()) {
      params.enable_sparse_sampling = parent->params.sparse_sampling.ref();
      framebuffer_reset = true;
    }

    if (parent->params.frame_accumulation.update()) {
      params.enable_frame_accumulation = parent->params.frame_accumulation.ref();
      framebuffer_reset = true;
    }

    if (parent->params.volume_sampling_rate.update()) {
      volume.set_sampling_rate(parent->params.volume_sampling_rate.get());
      volumes_changed = true;
      framebuffer_reset = true;
    }
  }

  void render()
  {
    framebuffer_size_updated = false;
    if (framebuffer_reset) {
      framebuffer.reset();
    }

    if (volumes_changed) {
      volume.commit(framebuffer_stream);
      volumes_changed = false;
    }

    params.frame.rgba = (vec4f*)framebuffer.device_pointer(/*layout=*/0);
    params.frame_index = framebuffer_reset ? 1 : params.frame_index + 1;
    if (params.frame.size.x <= 0 || params.frame.size.y <= 0) return;

    // renderer.render_path_tracing(framebuffer_stream, params, volume.get_device_pointer(framebuffer_stream), framebuffer_reset);
    renderer.render_ray_marching(framebuffer_stream, params, volume.get_device_pointer(framebuffer_stream), framebuffer_reset);

    /* post rendering */
    parent->variance = 0.f;
    framebuffer_reset = false;
  }

  void mapframe(FrameBufferData* fb)
  {
    const size_t num_bytes = framebuffer.size().long_product();
    fb->rgba->set_data(framebuffer.device_pointer(0), num_bytes * sizeof(vec4f), CrossDeviceBuffer::DEVICE_CUDA);
  }
};

DeviceNNCache::~DeviceNNCache()
{
  pimpl.reset();
}

DeviceNNCache::DeviceNNCache() 
  : MainRenderer(), pimpl(new Impl()) 
{
}

void
DeviceNNCache::init(int argc, const char** argv)
{
  pimpl->init(argc, argv, this);
  commit();
}

void
DeviceNNCache::swap()
{
  pimpl->swap();
}

void
DeviceNNCache::commit()
{
  pimpl->commit();
}

void
DeviceNNCache::render()
{
  pimpl->render();
}

void
DeviceNNCache::mapframe(FrameBufferData* fb)
{
  return pimpl->mapframe(fb);
}

}
