#pragma once
#ifndef OVR_NNCACHE_DEVICE_H
#define OVR_NNCACHE_DEVICE_H

#include "ovr/renderer.h"
#include <memory>

namespace ovr::nncache {

class DeviceNNCache : public MainRenderer {
public:
  ~DeviceNNCache() override;
  DeviceNNCache();
  DeviceNNCache(const DeviceNNCache& other) = delete;
  DeviceNNCache(DeviceNNCache&& other) = delete;
  DeviceNNCache& operator=(const DeviceNNCache& other) = delete;
  DeviceNNCache& operator=(DeviceNNCache&& other) = delete;

  /*! constructor - performs all setup, including initializing ospray, creates scene graph, etc. */
  void init(int argc, const char** argv) override;

  /*! render one frame */
  void swap() override;
  void commit() override;
  void render() override;
  void mapframe(FrameBufferData* fb) override;

private:
  struct Impl;
  std::unique_ptr<Impl> pimpl; // pointer to the internal implementation
};

} // namespace ovr::nncache

#endif // OVR_NNCACHE_DEVICE_H
