// Copyright 2021 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "ovr/common/math.h"
#include <rkcommon/containers/AlignedVector.h>
#include <mutex>
#include <chrono>

namespace ovr::openvkl {

  class Framebuffer
  {
    public:

      Framebuffer() {
        buffers.resize(num_buffers);
      }

      class Buffer
      {
        public:
          Buffer();
          Buffer(const Buffer &) = delete;
          Buffer& operator=(const Buffer &) = delete;
          Buffer(Buffer &&other);
          Buffer& operator=(Buffer &&other);
          ~Buffer();

          size_t getWidth() const { return w; }
          size_t getHeight() const { return h; }

          vec4f *getRgba() { return bufRgba.data(); }
          const vec4f *getRgba() const { return bufRgba.data(); }

          float *getWeight() { return bufWeight.data(); }
          const float *getWeight() const { return bufWeight.data(); }

          void copy(const Buffer &other);

        private:
          friend class Framebuffer;
          void resize(size_t _w, size_t _h);

        private:
          size_t w{0};
          size_t h{0};
          rkcommon::containers::AlignedVector<vec4f> bufRgba;
          rkcommon::containers::AlignedVector<float> bufWeight;
      };

      Buffer &getActiveBuffer() {
        return buffers[active_buffer_index];
      }
      const Buffer &getActiveBuffer() const {
        return buffers[active_buffer_index];
      }

      void swap() {
        active_buffer_index = (active_buffer_index + 1) % num_buffers;
      }

      void resize(size_t w, size_t h)
      {
        for (auto& buffer : buffers)
          buffer.resize(w, h);
        width = w;
        height = h;
      }

      size_t getWidth() const {
        return width;
      }

      size_t getHeight() const {
        return height;
      }

    private:
      size_t width{0};
      size_t height{0};
      int num_buffers{2};
      int active_buffer_index{0};
      std::vector<Buffer> buffers;
  };

}  // namespace ovr::openvkl
