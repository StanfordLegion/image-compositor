// Copyright 2021 Intel Corporation
// SPDX-License-Identifier: Apache-2.0

#include "framebuffer.h"

#include <rkcommon/tasking/parallel_for.h>

#include <algorithm>
#include <chrono>
#include <sstream>

namespace ovr::openvkl {

    // -------------------------------------------------------------------------

    Framebuffer::Buffer::Buffer() {}

    Framebuffer::Buffer::Buffer(Buffer &&other)
    {
      using std::swap;
      swap(w, other.w);
      swap(h, other.h);
      swap(bufRgba, other.bufRgba);
      swap(bufWeight, other.bufWeight);
    }

    Framebuffer::Buffer &Framebuffer::Buffer::operator=(Buffer &&other)
    {
      if (&other != this) {
        using std::swap;
        swap(w, other.w);
        swap(h, other.h);
        swap(bufRgba, other.bufRgba);
        swap(bufWeight, other.bufWeight);
      }
      return *this;
    }

    Framebuffer::Buffer::~Buffer() = default;

    void Framebuffer::Buffer::resize(size_t _w, size_t _h)
    {
      const size_t numPixels = _w * _h;

      bufRgba.resize(numPixels);
      std::fill(bufRgba.begin(), bufRgba.end(), vec4f(0.f));

      bufWeight.resize(numPixels);
      std::fill(bufWeight.begin(), bufWeight.end(), 0.f);

      w = _w;
      h = _h;
    }

    void Framebuffer::Buffer::copy(const Buffer &other)
    {
      assert(w == other.w);
      assert(h == other.h);

      bufRgba = other.bufRgba;
      bufWeight = other.bufWeight;
    }

}  // namespace ovr::openvkl
