#pragma once

#include "ovr/common/math.h"
#include <rkcommon/math/box.h>
#include <rkcommon/math/vec.h>


namespace ovr::openvkl {

    struct Ray
    {
        rkcommon::math::vec3f org;
        rkcommon::math::vec3f dir;
        rkcommon::math::range1f t;

        void setOrg(vec3f org) {
            this->org.x = org.x;
            this->org.y = org.y;
            this->org.z = org.z;
        }

        void setDir(vec3f dir) {
            this->dir.x = dir.x;
            this->dir.y = dir.y;
            this->dir.z = dir.z;
        }

        ovr::vec3f getOVROrg() {
            return {
                org.x, org.y, org.z
            };
        }

        ovr::vec3f getOVRDir() {
            return {
                dir.x, dir.y, dir.z
            };
        }
    };
}