#pragma once

#include "ovr/common/math.h"
#include "ovr/scene.h"
#include "ovr/devices/openvkl/ray.h"
#include <openvkl/openvkl.h>
#include <rkcommon/math/box.h>



namespace ovr::openvkl {

// Forward declarations from ../device_impl.h
struct DeviceVolume;
struct DeviceRenderParams;
    
namespace integrators {

using rkcommon::math::box3f;
using rkcommon::math::range1f;

class Integrator {

    public:
        Integrator(std::shared_ptr<DeviceVolume> volume, std::shared_ptr<DeviceRenderParams> params) :
            volume(volume), params(params) {};
        virtual void init() {};
        virtual void beforeFrame() {};
        virtual vec4f renderPixel(Ray& ray) = 0;

    protected:
        vec4f sampleTransferFunction(float value);

    protected:
        std::shared_ptr<DeviceRenderParams> params;
        std::shared_ptr<DeviceVolume> volume;
};

} // namespace integrators

} // namespace ovr::openvkl