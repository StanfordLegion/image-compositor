#pragma once

#include "../integrator.h"
#include "../../device_impl.h"
#include "ovr/common/math.h"
#include "../../random.h"

namespace ovr::openvkl::integrators {

class Pathtracer : public Integrator {

    public:
        Pathtracer(std::shared_ptr<DeviceVolume> volume, std::shared_ptr<DeviceRenderParams> params, int spp = 8) : Integrator(volume, params), spp(spp), sigma_s_scale(1.0f), sigma_t_scale(1.0f), max_num_scatter(8) {};

        virtual void init() override;

        virtual void beforeFrame() override { pixel_count = 0; };

        virtual vec4f renderPixel(Ray& ray) override;

    protected:
        vec3f integrate(RNG &rng, 
                        Ray& ray, 
                        int scatter_index, 
                        int& max_scatter_index);

        bool sampleWoodcock(RNG& rng, 
                            const Ray& ray, 
                            const range1f& hits, 
                            float& t, 
                            vec4f& albedo, 
                            float& transmittance);

    protected:
        int spp;
        float sigma_s_scale;
        float sigma_t_scale;
        int max_num_scatter;

        int pixel_count;
};

} // namespace ovr::openvkl::integrators