#include "pathtracer.h"

namespace ovr::openvkl::integrators {

// -------------------------------------------------------------------------

static vec3f cartesian(const float phi,
                        const float sinTheta,
                        const float cosTheta)
{
    float sinPhi = std::sin(phi);
    float cosPhi = std::cos(phi);
    return vec3f(cosPhi * sinTheta, sinPhi * sinTheta, cosTheta);
}

static vec3f uniformSampleSphere(const float radius, const vec2f &s)
{
    const float phi      = 2.f * M_PI * s.x;
    const float cosTheta = radius * (1.f - 2.f * s.y);
    const float sinTheta = 2.f * radius * std::sqrt(s.y * (1.f - s.y));
    return cartesian(phi, sinTheta, cosTheta);
}

// -------------------------------------------------------------------------

void 
Pathtracer::init() {
}

vec4f 
Pathtracer::renderPixel(Ray& ray) 
{
    vec4f rgba {0.f};

    int maxScatterIndex = 0;
    vec3f color {0.f};
    float alpha = 0.0f;
    for( int i = 0; i < spp; i++) {
        RNG rng(i, pixel_count);
        maxScatterIndex = 0;
        color += integrate(rng, ray, 0, maxScatterIndex);
        alpha += maxScatterIndex > 0 ? 1.0f : 0.0f;
    }

    rgba.x = color.x;
    rgba.y = color.y;
    rgba.z = color.z;
    rgba.w = alpha;

    pixel_count += 1;

    return rgba / (float)spp;
}

vec3f 
Pathtracer::integrate(RNG &rng, 
                        Ray& ray, 
                        int scatter_index, 
                        int& max_scatter_index) {

    vec3f Le        = vec3f(0.f);
    max_scatter_index = std::max<int>(scatter_index, max_scatter_index);

    ray.t = intersectRayBox(ray.org, ray.dir, volume->volume_bbox);

    if (!ray.t.empty()) {
        float t             = 0.f;
        vec4f albedo        = 0.f;
        float transmittance = 0.f;
        const bool haveEvent = sampleWoodcock(rng, ray, ray.t, t, albedo, transmittance);

        if (!haveEvent) {
            if (scatter_index > 0) {
                Le += transmittance * 50.0f; //* vec3f(params->ambientLightIntensity);
            }
        } else if (scatter_index < max_num_scatter) {
            const rkcommon::math::vec3f p = ray.org + t * ray.dir;

            Ray scatteringRay;
            scatteringRay.t   = range1f(0.f, infty());
            scatteringRay.org = p;
            scatteringRay.setDir(uniformSampleSphere(1.f, rng.getFloats()));

            const vec3f inscatteredLe =
                integrate(rng, scatteringRay, scatter_index + 1, max_scatter_index);

            // const vec4f sampleColorAndOpacity = sampleTransferFunction(sample);
            const vec3f sigmaSSample = sigma_s_scale * vec3f(albedo);
            Le = Le + sigmaSSample * inscatteredLe;
        }
    }

    return Le;
}

bool 
Pathtracer::sampleWoodcock(RNG& rng, 
                            const Ray& ray, 
                            const range1f& hits, 
                            float& t, 
                            vec4f& albedo, 
                            float& transmittance) 
{
    t = hits.lower;
    const float sigmaMax = sigma_t_scale;

    if (sigmaMax <= 0.f) {
        transmittance = 1.f;
        return false;
    }

    while (true) {
        vec2f randomNumbers  = rng.getFloats();
        vec2f randomNumbers2 = rng.getFloats();

        t = t + -std::log(1.f - randomNumbers.x) / sigmaMax;

        if (t > hits.upper) {
            transmittance = 1.f;
            return false;
        }

        const rkcommon::math::vec3f c = ray.org + t * ray.dir;
        float sample = vklComputeSample(volume->sampler, (const vkl_vec3f *)&c);

        albedo = sampleTransferFunction(sample);

        // sigmaT must be mono-chromatic for Woodcock sampling
        const float sigmaTSample = sigmaMax * albedo.w;

        if (randomNumbers.y < sigmaTSample / sigmaMax)
            break;
    }

    transmittance = 0.f;
    return true;
}

} // namespace ovr::openvkl::integrators