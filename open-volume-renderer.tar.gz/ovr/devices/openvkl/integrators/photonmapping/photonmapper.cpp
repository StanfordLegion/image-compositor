#include "photonmapper.h"

#include <vector>
#include <set>
#include <ctime>
#include <chrono>
#include <fstream>

#include <rkcommon/tasking/parallel_for.h>

namespace ovr::openvkl::integrators {

using rkcommon::tasking::parallel_for;

// -------------------------------------------------------------------------

static vec3f cartesian(const float phi,
                        const float sinTheta,
                        const float cosTheta)
{
    float sinPhi = std::sin(phi);
    float cosPhi = std::cos(phi);
    return vec3f(cosPhi * sinTheta, sinPhi * sinTheta, cosTheta);
}

static vec3f uniformSampleSphere(const float radius, const vec2f &s)
{
    const float phi      = 2.f * M_PI * s.x;
    const float cosTheta = radius * (1.f - 2.f * s.y);
    const float sinTheta = 2.f * radius * std::sqrt(s.y * (1.f - s.y));
    return cartesian(phi, sinTheta, cosTheta);
}

// -------------------------------------------------------------------------

bool 
PhotonMapper::sampleWoodcock(RNG& rng, 
                    const Ray& ray, 
                    const range1f& hits, 
                    float& t, 
                    float& sample, 
                    float& transmittance)
{
    t = hits.lower;
    const float sigmaMax = sigma_t_scale;

    if (sigmaMax <= 0.f) {
        transmittance = 1.f;
        return false;
    }

    while (true) {
        vec2f randomNumbers  = rng.getFloats();
        vec2f randomNumbers2 = rng.getFloats();

        t = t + -std::log(1.f - randomNumbers.x) / sigmaMax;

        if (t > hits.upper) {
            transmittance = 1.f;
            return false;
        }

        const rkcommon::math::vec3f c = ray.org + t * ray.dir;
        sample = vklComputeSample(volume->sampler, (const vkl_vec3f *)&c);

        vec4f sampleColorAndOpacity = sampleTransferFunction(sample);

        // sigmaT must be mono-chromatic for Woodcock sampling
        const float sigmaTSample = sigmaMax * sampleColorAndOpacity.w;

        if (randomNumbers.y < sigmaTSample / sigmaMax)
            break;
    }

    transmittance = 0.f;
    return true;
}

void 
PhotonMapper::tracePhoton(RNG &rng, 
                Ray& ray,
                Photon& photon,
                int& num_photons)
{
    int scatter_count = 0;
    float throughput = 1.f;
    //Photon photon;
    // TODO: This only works for vorts1, use light PDF and scene scale instead

    while (scatter_count < max_num_scatter) {
        ray.t = intersectRayBox(ray.org, ray.dir, volume->volume_bbox);
        if (ray.t.empty())
            break;

        float t             = 0.f;
        float sample        = 0.f;
        float transmittance = 0.f;
        const bool haveEvent = sampleWoodcock(rng, ray, ray.t, t, sample, transmittance);

        if (!haveEvent) {
            // Photon left the volume
            break;
        }

        const rkcommon::math::vec3f p = ray.org + t * ray.dir;

        ray.t   = range1f(0.f, infty());
        ray.org = p;
        ray.setDir(uniformSampleSphere(1.f, rng.getFloats()));


        const vec4f sampleColorAndOpacity = sampleTransferFunction(sample);
        const vec3f sigmaSSample = sigma_s_scale *
                                    vec3f(sampleColorAndOpacity); // *
                                    //sampleColorAndOpacity.w;

        // photon.direction = { ray.dir.x, ray.dir.y, ray.dir.z };
        photon.position = { ray.org.x, ray.org.y, ray.org.z };
        photon.intensity *= (sigmaSSample * throughput) / num_photons_traced;
        throughput *= (1.f - sampleColorAndOpacity.w);


        mutex.lock();
        pm->addPhoton(photon);

        if (++num_photons % (num_photons_traced / 10) == 0)
            std::cout << std::round((100.f * num_photons) / num_photons_traced) << "%..." << std::flush;

        scatter_count++;
        mutex.unlock();


        // float russian_roulette_prob = std::min(
        //         std::max(photon.intensity[0],
        //                  std::max(photon.intensity[1], photon.intensity[2])),
        //         1.0f);

        if (rng.getFloat() >= throughput) /* Russian Roulette termination */
            break;
    }

}

void 
PhotonMapper::init() 
{
    // std::ifstream inmap("photonmap.bin", std::ifstream::in | std::ios::binary);
    // pm->deserialize(inmap);
    // std::cout << "[vkl->pm] Loaded precomputed photom map" << std::endl;
    // return;
    // TODO: Hard-coded for now
    vec3f light_position {150.f, 200.f, 0.f};
    vec3f light_position2 {-150.f, -200.f, 0.f};

    int num_photons = 0;

    std::cout << "[vkl->pm] Tracing photons [n = " << num_photons_traced << "]" << std::endl;
    auto start = std::chrono::high_resolution_clock::now();

    int itercnt = 0;
    while (num_photons < num_photons_traced) {
        parallel_for((size_t)num_photons_traced, [&](size_t taskidx){
            if (num_photons >= num_photons_traced) return;

            RNG rng(itercnt, taskidx);

            Photon photon;
            Ray ray;
            ray.t = {0.f, infty()};
            if (rng.getFloat() < 1.5f) {
                ray.setOrg(light_position);
                photon.intensity = {0.1f, 1.f, 1.f};
                photon.intensity *= 300000.f;
            } else {
                ray.setOrg(light_position2);
                photon.intensity = {1.f, 0.f, 0.f};
                photon.intensity *= 100000.f;
            }
            ray.setDir(uniformSampleSphere(1.f, rng.getFloats()));

        

            tracePhoton(rng, ray, photon, num_photons);
        });
        itercnt++;
    }
    std::cout << "\n";
    auto end = std::chrono::high_resolution_clock::now();
    auto diff = std::chrono::duration_cast<std::chrono::seconds>(end - start);
    std::cout << "[vkl->pm] Tracing time = " << diff.count() << "s [n = " << pm->getNPhotons() << "]" << std::endl;   
    std::cout << "[vkl->pm] Itercnt = " << itercnt << std::endl; 
    std::ofstream stream("photonmap.bin", std::ofstream::out | std::ios::binary);
    pm->serialize(stream);
    stream.close();
    if (trace_only) return;

    std::cout << "[vkl->pm] Building photon map" << std::endl;
    pm->build();
    std::cout << "[vkl->pm] Photonmapper done initializing" << std::endl;

    vec3f avg {0};
    vec3f max {0};
    vec3f min {1};
    for (int i = 0; i < pm->getNPhotons(); ++i) {
        avg += pm->getIthPhoton(i).intensity;
        if (max < pm->getIthPhoton(i).intensity)
            max = pm->getIthPhoton(i).intensity;
        if (pm->getIthPhoton(i).intensity < min)
            min = pm->getIthPhoton(i).intensity;
    }
    avg /= pm->getNPhotons();
    std::cout << "Avg. Intensity = " << avg << std::endl;
    std::cout << "Max. Intensity = " << max << std::endl;
    std::cout << "Min. Intensity = " << min << std::endl;
}

vec4f 
PhotonMapper::renderPixel(Ray& ray) 
{
    if (trace_only) return {0.f};

    vec3f raydir = { ray.dir.x, ray.dir.y, ray.dir.z };
    ray.t = intersectRayBox(ray.org, ray.dir, volume->volume_bbox);

    vec3f color {0.0f};
    float transmittance = 1.0f;
    if (!ray.t.empty()) {

        if (estimator_type == EstimatorType::Beam || estimator_type == EstimatorType::BeamVK) {

            std::vector<float> transmittance_map;
            float t_lower = ray.t.lower;
            float t_upper = ray.t.upper;
            float t_len = abs(ray.t.upper - ray.t.lower);

            while (ray.t.lower < ray.t.upper) {
                // if (transmittance <= 0.01f) break;
                ray.t.lower += sample_rate;

                auto po = ray.org + ray.t.lower * ray.dir;

                vec4f sample = sampleTransferFunction(vklComputeSample(volume->sampler, (vkl_vec3f*)&po));
                transmittance = clamp( transmittance - sample.w * sample_rate, 0.f, 1.f);

                float previous = transmittance_map.size() > 0 ? transmittance_map[transmittance_map.size() - 1] : 1.f;
                transmittance_map.push_back(transmittance);
            }

            auto kernel = [&](Ray& ray, const Photon& photon) {
                float distance = length(cross(ray.getOVRDir(), (photon.position - ray.getOVROrg())));
                if (distance < 0 || distance > photon.radius) return 0.f;

                float x = distance / photon.radius;
                return (float)((1.f / pow(photon.radius, 2)) * (( 3.f * pow(1.f - pow(x,2),2) ) / M_PI ));
            };

            auto Tr = [&](Ray& ray, const Photon& photon) {
                float t = dot(ray.getOVRDir(), (photon.position - ray.getOVROrg()));

                float pos = (transmittance_map.size() - 1) * ((t - t_lower) / t_len);
                int idx = (int)pos;
                float mix = pos - (float)idx;
                
                // int idx = (transmittance_map.size() - 1) * ((t - t_lower) / t_len);
                if (pos < 0) return transmittance_map[0];
                if (pos >= transmittance_map.size()) return transmittance_map[transmittance_map.size() - 1];

                return mix * transmittance_map[idx] + (1.f - mix) * transmittance_map[idx+1];
            };

            std::vector<int> pis = pm->queryPhotonsAlongRay(ray);

            for (auto& pi : pis) {
                const Photon& photon = pm->getIthPhoton(pi);
                color += kernel(ray, photon) * Tr(ray, photon) * photon.intensity;
                // color += kernel(ray, photon) * photon.throughput;
                // color += Tr(ray,photon);
            }
            // color /= pis.size();

        } else {
            // TODO: Use VKLIntervals for performance
            while (ray.t.lower < ray.t.upper) {
                if (transmittance <= 0.01f) break;
            
                ray.t.lower += sample_rate;
                
                auto po = ray.org + ray.t.lower * ray.dir;
                vec3f p {
                    po.x, po.y, po.z
                };
                vkl_vec3f pt{
                    po.x, po.y, po.z
                };

                vec4f sample = sampleTransferFunction(vklComputeSample(volume->sampler, &pt));
                transmittance *= (1.f - sample.w);// * sample_rate;


                if (estimator_type == EstimatorType::KNN) {
                    float max_dist2;
                    std::vector<int> pis = pm->queryKNearestPhotons(p, num_photons_estimated, max_dist2);

                    vec3f estimated_radiance = 0.0f;
                    for (auto& pi : pis) {
                        const Photon& photon = pm->getIthPhoton(pi);

                        estimated_radiance += photon.intensity;
                    }
                    float div = (3.f/4.f) * (float)M_PI * pow(sqrt(max_dist2), 3);
                    color += (estimated_radiance / div) * sample_rate * transmittance;
                } else if (estimator_type == EstimatorType::FixedRadius) {

                    vec3f estimated_radiance {0.0f};
                    float r = .75f;
                    std::vector<int> pis = pm->queryPhotonsInRange(p, r);
                    float div = (3.f/4.f) * (float)M_PI * (r*r*r);
                    for (auto& pi : pis) {
                        const Photon& photon = pm->getIthPhoton(pi);

                        estimated_radiance += photon.intensity/ div;
                    }
                    
                    color += estimated_radiance * sample_rate * transmittance;
                }
            }
        }
    }

    return {
        color.x, color.y, color.z, 1.0f
    };
}

} // namespace ovr::openvkl::integrators