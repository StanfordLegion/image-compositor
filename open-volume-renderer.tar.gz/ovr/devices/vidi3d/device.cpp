#include "device.h"
#include "dictionary.h"

#include <v3d/Data/DataUtil.h>
#include <v3d/Renderer/FramebufferGL.h>
#include <v3d/Serializer/TransferFunctionSerializer.h>
#include <v3d/Util/GLConfig.h>

#include <Engine/ParameterAPI.h>
#include <Engine/PipelineAPI.h>
#include <Engine/RegularGrid/RegularGridEngine.h>
#include <Util/DXGL.h>

#include <vidiSerializable.h>

#include <string>
#include <thread>

using v3d::glPrintErrors;

namespace ovr::vidi3d {

// ------------------------------------------------------------------
// ------------------------------------------------------------------

const std::string json_template = R"({
  "dataSource" : [],
  "snapshot" : [],
  "view" : {
    "backgroundColor" : { "a" : 1, "b" : 0, "g" : 0, "r" : 0 },
    "camera" : {
      "center" : {},
      "eye" : {},
      "up" : {},
      "fovy" : 60,
      "projectionMode" : "PERSPECTIVE",
      "zFar" : 10000,
      "zNear" : 0.1
    },
    "globalAmbient" : { "a" : 0, "b" : 0, "g" : 0, "r" : 0 },
    "globalLighting" : true,
    "lightSource" : {
      "ambient"  : { "a" : 1, "b" : 1, "g" : 1, "r" : 1 },
      "diffuse"  : { "a" : 1, "b" : 1, "g" : 1, "r" : 1 },
      "position" : { "w" : 0.0, "x" : 0.0, "y" : 0.0, "z" : 1.0 },
      "specular" : { "a" : 1, "b" : 1, "g" : 1, "r" : 1 },
      "type" : "DIRECTIONAL_LIGHT"
    },
    "lighting" : true,
    "lightingSide" : "BACK_SIDE",
    "method" : "",
    "tfPreIntegration" : true,
    "volume" : {
      "dataId" : 0,
      "boundingBox" : {},
      "clippingBox" : {},
      "textureBox" : {},
      "scalarMappingRange" : {},
      "scalarMappingRangeUnnormalized" : {},
      "sampleDistance" : 0.25,
      "boundingBoxColor" : { "a" : 1, "b" : 0.5, "g" : 0.5, "r" : 0.5 },
      "boundingBoxVisible" : true,
      "interpolationType" : "LINEAR_INTERPOLATION",
      "material" : { "ambient" : 0.5, "diffuse" : 0.8, "shininess" : 16, "specular" : 0 },
      "opacityUnitDistance" : 1,
      "slice" : {
        "x" : { "position" : 0, "visible" : false },
        "y" : { "position" : 0, "visible" : false },
        "z" : { "position" : 0, "visible" : false }
      },
      "transferFunction" : {},
      "transferFunctionType" : "TRANSFER_FUNCTION",
      "visible" : true
    }
  }
})";

static void
wrap_transfer_function(json& jsroot, scene::TransferFunction tfn)
{
  using namespace v3d::serializer;

  const vec4f* color_table = (const vec4f*)tfn.color->data();
  const float* alpha_table = (const float*)tfn.opacity->data();

  const int resolution = 1024;
  v3d::TransferFunction tmp(resolution);
  {
    float* alpha = tmp.alphaArray();
    for (int i = 0; i < resolution; ++i) {
      alpha[i] = (float)i / (resolution - 1);
    }

    tmp.clearColorControls();
    int count = tfn.color->dims.v;

    for (int i = 0; i < count; ++i) {
      v3d::TransferFunction::ColorControl colorControl;
      colorControl.position = (float)i / (count - 1);
      colorControl.color.r = color_table[i].x;
      colorControl.color.g = color_table[i].y;
      colorControl.color.b = color_table[i].z;
      tmp.addColorControl(colorControl);
    }

    tmp.updateColorMap();
  }

  jsroot[VIEW][VOLUME][TRANSFER_FUNCTION] = to_default_json(v3d::serializer::toJson(tmp));

  jsroot[VIEW][VOLUME][SCALAR_MAPPING_RANGE_UNNORMALIZED][MINIMUM] = tfn.value_range.x;
  jsroot[VIEW][VOLUME][SCALAR_MAPPING_RANGE_UNNORMALIZED][MAXIMUM] = tfn.value_range.y;
}

static void
wrap_transfer_function(json& jsroot, const MainRenderer::TransferFunctionData& tfn)
{
  using namespace v3d::serializer;

  // const vec4f* color_table = (const vec4f*)tfn.color->data();
  // const float* alpha_table = (const float*)tfn.opacity->data();

  // const int resolution = 1024;
  // v3d::TransferFunction tmp(resolution);
  // {
  //   float* alpha = tmp.alphaArray();
  //   for (int i = 0; i < resolution; ++i) {
  //     alpha[i] = (float)i / (resolution - 1);
  //   }

  //   tmp.clearColorControls();
  //   int count = tfn.color->dims.v;
  //   for (int i = 0; i < count; ++i) {
  //     v3d::TransferFunction::ColorControl colorControl;
  //     colorControl.position = (float)i / (count - 1);
  //     colorControl.color.r = color_table[i].x;
  //     colorControl.color.g = color_table[i].y;
  //     colorControl.color.b = color_table[i].z;
  //     tmp.addColorControl(colorControl);
  //   }
  //   tmp.updateColorMap();
  // }

  // jsroot[VIEW][VOLUME][TRANSFER_FUNCTION] = to_default_json(v3d::serializer::toJson(tmp));

  // jsroot[VIEW][VOLUME][SCALAR_MAPPING_RANGE_UNNORMALIZED][MINIMUM] = tfn.value_range.x;
  // jsroot[VIEW][VOLUME][SCALAR_MAPPING_RANGE_UNNORMALIZED][MAXIMUM] = tfn.value_range.y;
}

static void
wrap_volume(json& jsroot, scene::Volume _volume, vec2f value_range)
{
  using namespace v3d::serializer;

  vec3f bbox_lower;
  vec3f bbox_upper;

  vec3f tex_lower;
  vec3f tex_upper;

  json jsdata;

  ValueType type;

  if (_volume.type == scene::Volume::STRUCTURED_REGULAR_VOLUME) {
    const auto& volume = _volume.structured_regular;

    type = volume.data->type;

    jsdata[URL] = "memory://" + vidi::serializable::castPtrToStr(volume.data->data());
    jsdata[DIMENSIONS] = scalar_to_json(volume.data->dims);
    jsdata[TYPE] = scalar_to_json(volume.data->type);
    jsdata[FORMAT] = REGULAR_GRID_POINTER;

    // jsdata[URL] = "disk://volume/3.900E-04_H2O2.raw";
    // jsdata[DIMENSIONS] = scalar_to_json(volume.data->dims);
    // jsdata[TYPE] = scalar_to_json(volume.data->type);
    // jsdata[FORMAT] = REGULAR_GRID_RAW_BINARY;
    // jsdata[FILE_UPPER_LEFT] = false;
    // jsdata[OFFSET] = 0;
    // jsdata[ENDIAN] = "LITTLE_ENDIAN";

    bbox_lower = volume.grid_origin;
    bbox_upper = volume.grid_spacing * vec3f(volume.data->dims) + volume.grid_origin;

    tex_lower = bbox_lower - volume.grid_spacing * 0.5f;
    tex_upper = bbox_upper + volume.grid_spacing * 0.5f;

    jsroot[VIEW][METHOD_] = "REGULAR_GRID_VOLUME_RAY_CASTING";
  }
  else {
    throw std::runtime_error("data type unimplemented");
  }

  jsdata[ID] = 1;
  jsroot[DATA_SOURCE].push_back(jsdata);

  jsroot[VIEW][VOLUME][DATA_ID] = 1;
  jsroot[VIEW][VOLUME][DATA_ID] = scalar_to_json(bbox_lower);

  jsroot[VIEW][VOLUME][BOUNDING_BOX][MAXIMUM] = scalar_to_json(bbox_upper);
  jsroot[VIEW][VOLUME][BOUNDING_BOX][MINIMUM] = scalar_to_json(bbox_lower);

  jsroot[VIEW][VOLUME][CLIPPING_BOX][MAXIMUM] = scalar_to_json(bbox_upper);
  jsroot[VIEW][VOLUME][CLIPPING_BOX][MINIMUM] = scalar_to_json(bbox_lower);

  jsroot[VIEW][VOLUME][TEXTURE_BOX][MAXIMUM] = scalar_to_json(tex_upper);
  jsroot[VIEW][VOLUME][TEXTURE_BOX][MINIMUM] = scalar_to_json(tex_lower);

  vec2f normalized_range;
  switch (type) {
  case VALUE_TYPE_UINT8: {
    normalized_range.x = v3d::intNormalize<float, uint8_t>((uint8_t)value_range.x);
    normalized_range.y = v3d::intNormalize<float, uint8_t>((uint8_t)value_range.y);
    break;
  }
  case VALUE_TYPE_UINT16: {
    normalized_range.x = v3d::intNormalize<float, uint16_t>((uint16_t)value_range.x);
    normalized_range.y = v3d::intNormalize<float, uint16_t>((uint16_t)value_range.y);
    break;
  }
  case VALUE_TYPE_UINT32: {
    normalized_range.x = v3d::intNormalize<float, uint32_t>((uint32_t)value_range.x);
    normalized_range.y = v3d::intNormalize<float, uint32_t>((uint32_t)value_range.y);
    break;
  }
  case VALUE_TYPE_INT8: {
    normalized_range.x = v3d::intNormalize<float, int8_t>((int8_t)value_range.x);
    normalized_range.y = v3d::intNormalize<float, int8_t>((int8_t)value_range.y);
    break;
  }
  case VALUE_TYPE_INT16: {
    normalized_range.x = v3d::intNormalize<float, int16_t>((int16_t)value_range.x);
    normalized_range.y = v3d::intNormalize<float, int16_t>((int16_t)value_range.y);
    break;
  }
  case VALUE_TYPE_INT32: {
    normalized_range.x = v3d::intNormalize<float, int32_t>((int32_t)value_range.x);
    normalized_range.y = v3d::intNormalize<float, int32_t>((int32_t)value_range.y);
    break;
  }
  case VALUE_TYPE_FLOAT: normalized_range = value_range; break;
  case VALUE_TYPE_DOUBLE: normalized_range = value_range; break;
  default: assert(false);
  }

  jsroot[VIEW][VOLUME][SCALAR_MAPPING_RANGE][MINIMUM] = normalized_range.x;
  jsroot[VIEW][VOLUME][SCALAR_MAPPING_RANGE][MAXIMUM] = normalized_range.y;
}

static void
wrap_camera(json& jsroot, const Camera& camera)
{
  using namespace v3d::serializer;
  jsroot[VIEW][CAMERA][CENTER] = scalar_to_json(camera.at);
  jsroot[VIEW][CAMERA][EYE] = scalar_to_json(camera.from);
  jsroot[VIEW][CAMERA][UP] = scalar_to_json(camera.up);
}

// ------------------------------------------------------------------
// ------------------------------------------------------------------

struct DeviceVidi3d::Impl {
  DeviceVidi3d* parent{ nullptr };

  struct Worker {
  private:
    std::shared_ptr<v3d::PipelineAPI> m_engine;
    json m_config;
    vec2i m_fbsize;

    std::thread::id m_thread_id;

  public:
    void initialize_context()
    {
      m_thread_id = std::this_thread::get_id();

      static int ac = 1;
      static char* av[] = { "vidi3d" };

      v3d::DXGL_init(ac, av);
    }

    void init(Scene& scene)
    {
      assert_worker_thread();

      /* create scene */
      auto& model = scene.instances[0].models[0].volume_model;

      m_config = json::parse(json_template);
      wrap_volume(m_config, model.volume, model.transfer_function.value_range);
      wrap_transfer_function(m_config, model.transfer_function);

      /* create render engine */
      m_engine = std::make_shared<v3d::PipelineAPI>();
      m_engine->configureFromJson(to_v3d_json(m_config));

      V3D_GL_PRINT_ERRORS();
      m_engine->loadCPU();
      V3D_GL_PRINT_ERRORS();
      m_engine->commitDataCPU();
      V3D_GL_PRINT_ERRORS();
      m_engine->loadGPU();
      V3D_GL_PRINT_ERRORS();
      m_engine->commitDataGPU();
      V3D_GL_PRINT_ERRORS();
      m_engine->commitViewCPU();
      V3D_GL_PRINT_ERRORS();
      m_engine->commitViewGPU();
      V3D_GL_PRINT_ERRORS();
    }

    void update()
    {
      assert_worker_thread();

      if (m_fbsize.long_product() > 0) {
        const auto js = v3d::JsonParser().parse(m_config.dump());
        m_engine->configureFromJson(js);

        V3D_GL_PRINT_ERRORS();
        m_engine->commitViewCPU();
        V3D_GL_PRINT_ERRORS();
        m_engine->commitViewGPU();
        V3D_GL_PRINT_ERRORS();
      }
    }

    void render(v3d::PipelineAPI::ImageVec4f& output)
    {
      assert_worker_thread();

      if (m_fbsize.long_product() > 0) {
        V3D_GL_PRINT_ERRORS();
        m_engine->render();
        m_engine->getFrameAsBufferVec4f(output, false, false);
        V3D_GL_PRINT_ERRORS();
      }
    }

    void resize(vec2i size)
    {
      assert_worker_thread();

      m_fbsize = size;
      m_engine->resize(m_fbsize.x, m_fbsize.y);
    }

    void commit_camera(const Camera& camera)
    {
      wrap_camera(m_config, camera);
    }

    void commit_transfer_function(const TransferFunctionData& tfn)
    {
      wrap_transfer_function(m_config, tfn);
    }

    void release()
    {
      V3D_GL_PRINT_ERRORS();
      m_engine->unloadGPU();
      m_engine->unloadCPU();
      V3D_GL_PRINT_ERRORS();
    }

    void assert_worker_thread() const
    {
      if (!is_worker_thread())
        throw std::runtime_error("worker function not being called in a worker thread");
    }

    bool is_worker_thread() const
    {
      thread_local auto id = std::this_thread::get_id();
      return id == m_thread_id;
    }

  } worker;
  bool worker_initialized = false;

  v3d::PipelineAPI::ImageVec4f buffers[2];
  int buffer_index = 0;

public:
  ~Impl()
  {
    worker.release();
  }

  Impl()
  {
    /* load modules, load all shaders */
    v3d::DXGL_create();
  }

  void init(int argc, const char** argv, DeviceVidi3d* p)
  {
    if (parent)
      throw std::runtime_error("[vidi3d] device already initialized!");
    parent = p;
  }

  void swap()
  {
    buffer_index = (buffer_index + 1) % 2;
  }

  void commit()
  {
    /* define worker thread */
    if (!worker_initialized) {
      worker.initialize_context();
      worker.init(parent->current_scene);
      worker_initialized = true;
    }

    /* everything must happen in the worker thread */
    if (!worker.is_worker_thread()) {
      std::cerr << "[vidi3d] not in the worker thread" << std::endl;
      return;
    }

    bool commit = false;
    if (parent->params.fbsize.update()) {
      worker.resize(parent->params.fbsize.ref());
      buffers[0].resize(parent->params.fbsize.ref().long_product() * 4);
      buffers[1].resize(parent->params.fbsize.ref().long_product() * 4);
      commit = true;
    }

    if (parent->params.camera.update()) {
      worker.commit_camera(parent->params.camera.ref());
      commit = true;
    }

    if (parent->params.tfn.update()) {
      worker.commit_transfer_function(parent->params.tfn.ref());
      commit = true;
    }

    if (commit) {
      worker.update();
    }
  }

  void render()
  {
    if (!worker.is_worker_thread()) {
      std::cerr << "[vidi3d] not in the worker thread" << std::endl;
      return;
    }

    worker.render(buffers[buffer_index]);
  }

  void mapframe(FrameBufferData* fb)
  {
    fb->rgba->set_data(buffers[buffer_index], CrossDeviceBuffer::DEVICE_CPU);
  }
};

DeviceVidi3d::~DeviceVidi3d()
{
  pimpl.reset();
}

DeviceVidi3d::DeviceVidi3d() : MainRenderer(), pimpl(new Impl()) {}

void
DeviceVidi3d::init(int argc, const char** argv)
{
  pimpl->init(argc, argv, this);
}

void
DeviceVidi3d::swap()
{
  pimpl->swap();
}

void
DeviceVidi3d::commit()
{
  pimpl->commit();
}

void
DeviceVidi3d::render()
{
  pimpl->render();
}

void
DeviceVidi3d::mapframe(FrameBufferData* fb)
{
  return pimpl->mapframe(fb);
}

} // namespace ovr::vidi3d
