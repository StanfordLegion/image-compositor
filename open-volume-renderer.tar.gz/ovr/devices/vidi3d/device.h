#pragma once
#ifndef OVR_VIDI3D_DEVICE_H
#define OVR_VIDI3D_DEVICE_H

#include "ovr/renderer.h"
#include <memory>

namespace ovr::vidi3d {

class DeviceVidi3d : public MainRenderer {
public:
  ~DeviceVidi3d() override;
  DeviceVidi3d();
  DeviceVidi3d(const DeviceVidi3d& other) = delete;
  DeviceVidi3d(DeviceVidi3d&& other) = delete;
  DeviceVidi3d& operator=(const DeviceVidi3d& other) = delete;
  DeviceVidi3d& operator=(DeviceVidi3d&& other) = delete;

  /*! constructor - performs all setup, including initializing ospray, creates scene graph, etc. */
  void init(int argc, const char** argv) override;

  /*! render one frame */
  void swap() override;
  void commit() override;
  void render() override;
  void mapframe(FrameBufferData* fb) override;

private:
  struct Impl;
  std::unique_ptr<Impl> pimpl; // pointer to the internal implementation
};

} // namespace ovr::vidi3d

#endif // OVR_VIDI3D_DEVICE_H
