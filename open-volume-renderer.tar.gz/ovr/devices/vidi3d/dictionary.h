#pragma once
#ifndef OVR_VIDI3D_DICTIONARY_H
#define OVR_VIDI3D_DICTIONARY_H

#include <v3d/Serializer/Dictionary.h>
#include <v3d/Util/JsonParser.h>

#include <3rdparty/json.hpp>

// ------------------------------------------------------------------
// ------------------------------------------------------------------

namespace v3d::serializer {

// from JsonSerializer.h
const char* const BLOCKS = "blocks";
const char* const CAMERA = "camera";
const char* const CAPTION = "caption";
const char* const CELL_COUNT = "cellCount";
const char* const CELLS_OFFSET = "cellsOffset";
const char* const DATA_FILE_NAME = "dataFileName";
const char* const DATA_ID = "dataId";
const char* const DATA_SOURCE = "dataSource";
const char* const DIMENSIONS = "dimensions";
const char* const ENDIAN = "endian";
const char* const FILE_NAME = "fileName";
const char* const FILE_UPPER_LEFT = "fileUpperLeft";
const char* const FORMAT = "format";
const char* const GRID_FILE_NAME = "gridFileName";
const char* const ID = "id";
const char* const IMAGE = "image";
const char* const METHOD_ = "method";
const char* const NAME = "name";
const char* const OFFSET = "offset";
const char* const POINT_COUNT = "pointCount";
const char* const POINT_DATA_OFFSET = "pointDataOffset";
const char* const POINTS_OFFSET = "pointsOffset";
const char* const SECONDARY_DATA_ID = "secondaryDataId";
const char* const SNAPSHOT = "snapshot";
const char* const SOLUTION_FILE_NAME = "solutionFileName";
const char* const TRANSFER_FUNCTION = "transferFunction";
const char* const OCCLUSION_TRANSFER_FUNCTION = "occlusionTransferFunction";
const char* const VARIABLE_TYPE = "variableType";
const char* const VIEW = "view";
const char* const VOLUME = "volume";

// from DataSourceModel.h
const char* const MULTI_BLOCKS = "MULTI_BLOCKS";
const char* const FOLDER = "FOLDER";
const char* const MULTIVARIATE = "MULTIVARIATE";
#ifdef V3D_USE_PVM
const char* const REGULAR_GRID_PVM = "REGULAR_GRID_PVM";
#endif
const char* const REGULAR_GRID_RAW_BINARY = "REGULAR_GRID_RAW_BINARY";
const char* const REGULAR_GRID_POINTER = "REGULAR_GRID_POINTER";
const char* const TETRAHEDRAL_GRID_FAST = "TETRAHEDRAL_GRID_FAST";
const char* const TETRAHEDRAL_GRID_RAW_BINARY = "TETRAHEDRAL_GRID_RAW_BINARY";
const char* const TETRAHEDRAL_HO_MESH = "TETRAHEDRAL_HO_MESH";
const char* const TIME_VARYING = "TIME_VARYING";
const char* const GHOST_REGIONS = "ghostRegions";
const char* const LOGIC_BOUNDS = "logicBounds";
const char* const GHOST_BOUNDS = "ghostBounds";
const char* const GLOBAL_DIMENSIONS = "globalDimensions";
const char* const URL = "url";
const char* const FILE_LOCATION = "fileLocation";
const char* const SCALAR_MAPPING_RANGE_UNNORMALIZED = "scalarMappingRangeUnnormalized";

} // namespace v3d::serializer

// ------------------------------------------------------------------
// ------------------------------------------------------------------

namespace ovr {

using json = nlohmann::json;

NLOHMANN_JSON_SERIALIZE_ENUM(ValueType,
                             {
                               { ValueType::VALUE_TYPE_VOID, "VOID" },
                               { ValueType::VALUE_TYPE_INT8, "BYTE" },
                               { ValueType::VALUE_TYPE_UINT8, "UNSIGNED_BYTE" },
                               { ValueType::VALUE_TYPE_INT16, "SHORT" },
                               { ValueType::VALUE_TYPE_UINT16, "UNSIGNED_SHORT" },
                               { ValueType::VALUE_TYPE_INT32, "INT" },
                               { ValueType::VALUE_TYPE_UINT32, "UNSIGNED_INT" },
                               { ValueType::VALUE_TYPE_FLOAT, "FLOAT" },
                               { ValueType::VALUE_TYPE_DOUBLE, "DOUBLE" },
                             });

#define define_vector_serialization(T)                  \
  NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(vec2##T, x, y);    \
  NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(vec3##T, x, y, z); \
  NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(vec4##T, x, y, z, w);
define_vector_serialization(i);
define_vector_serialization(f);
#undef define_vector_serialization

} // namespace ovr

// ------------------------------------------------------------------
// ------------------------------------------------------------------

namespace ovr::vidi3d {

inline v3d::JsonValue
to_v3d_json(const json& in)
{
  auto str = in.dump();
  return v3d::JsonParser().parse(str);
}

inline json
to_default_json(const v3d::JsonValue& in)
{
  auto str = v3d::JsonParser().stringify(in);
  return json::parse(str, nullptr, true, true);
}

template<typename ScalarT>
inline ScalarT
scalar_from_json(const json& in)
{
  ScalarT v;
  from_json(in, v);
  return v;
}

template<typename ScalarT>
inline json
scalar_to_json(const ScalarT& in)
{
  json v;
  to_json(v, in);
  return v;
}

} // namespace ovr::vidi3d

#endif // OVR_VIDI3D_DICTIONARY_H
