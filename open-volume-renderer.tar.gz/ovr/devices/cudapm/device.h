#pragma once
#ifndef OVR_CUDAPM_DEVICE_H
#define OVR_CUDAPM_DEVICE_H

#include "ovr/renderer.h"
#include <memory>

namespace ovr::cudapm {

class DeviceCudapm : public MainRenderer {
public:
  ~DeviceCudapm() override;
  DeviceCudapm();
  DeviceCudapm(const DeviceCudapm& other) = delete;
  DeviceCudapm(DeviceCudapm&& other) = delete;
  DeviceCudapm& operator=(const DeviceCudapm& other) = delete;
  DeviceCudapm& operator=(DeviceCudapm&& other) = delete;

  /*! constructor - performs all setup, including initializing ospray, creates scene graph, etc. */
  void init(int argc, const char** argv) override;


  /*! render one frame */
  void swap() override;
  void commit() override;
  void render() override;
  void mapframe(FrameBufferData* fb) override;

private:
  struct Impl;
  std::unique_ptr<Impl> pimpl; // pointer to the internal implementation
};

} // namespace ovr::cudapm

#endif // OVR_CUDAPM_DEVICE_H
