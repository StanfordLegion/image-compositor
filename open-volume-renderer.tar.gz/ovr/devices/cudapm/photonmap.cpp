//. ======================================================================== //
//. Copyright 2019-2023 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "photonmap.h"

namespace ovr::cudapm {

// ------------------------------------------------------------------
//
// ------------------------------------------------------------------

void
HostPhotonMap::commit(cudaStream_t stream)
{
    photons_buffer.alloc_and_upload<Photon>(photons); /* Transfer photon data */
    nodes_buffer.alloc(photons.size() * sizeof(BBHNode)); /* Allocate a node for each photon */

    self.size = photons.size();
    self.photons = (Photon*)photons_buffer.d_pointer();
    self.nodes = (BBHNode*)nodes_buffer.d_pointer();

    self_buffer.alloc_and_upload<DevicePhotonMap>(&self, 1);
}

} // namespace ovr::cudapm
