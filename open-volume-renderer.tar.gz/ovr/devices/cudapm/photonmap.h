//. ======================================================================== //
//. Copyright 2019-2022 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //
/**
 * Source: https://github.com/yumcyaWiz/photon_mapping/blob/main/include/photon_map.h
 * 
 * Modified and adapted by David Bauer
 * 
*/

#pragma once

#include "ovr/common/math.h"
#include "ovr/common/cuda_buffer.h"

#include <numeric>
#include <queue>
#include <vector>
#include <iostream>
#include <fstream>


namespace ovr::cudapm {

// ------------------------------------------------------------------
// Photonmap Definition
// ------------------------------------------------------------------
struct Photon {
    vec3f position;
    vec3f intensity;
    float radius;
};

struct BBHNode {
  struct {
    vec3f upper;
    vec3f lower;
  } bbox;
};

struct DevicePhotonMap
{
  int size;
  Photon* photons;
  BBHNode* nodes;
};

// ------------------------------------------------------------------
//
// Host Functions
//
// ------------------------------------------------------------------



#if defined(__cplusplus)

class HostPhotonMap {

 protected:
  std::vector<Photon> photons;
  CUDABuffer photons_buffer;
  CUDABuffer nodes_buffer;

  DevicePhotonMap self;
  CUDABuffer self_buffer;

 public:
  HostPhotonMap() {};

  void commit(cudaStream_t stream);
  const DevicePhotonMap& device_photonmap() { return self; }
  void* photonmap_device_pointer() { return (void*)self_buffer.d_pointer(); }
  void* photons_device_pointer() { return (void*)photons_buffer.d_pointer(); };
  void* nodes_device_pointer() { return (void*)nodes_buffer.d_pointer(); };

  void load_from_file() {
    std::ifstream inmap("photonmap.bin", std::ifstream::in | std::ios::binary);
    deserialize(inmap);
  };

  const int getNPhotons() const { return photons.size(); }

  virtual void deserialize(std::istream& stream) {
    int size;
    stream.read(reinterpret_cast<char*>(&size), sizeof(int));
    photons.resize(size);
    stream.read(reinterpret_cast<char*>(&photons[0]), photons.size()*sizeof(Photon));
  }
};

#endif

} // namespace ovr::cudapm