#pragma once

#include "ovr/common/cuda_buffer.h"
#include "ovr/common/math.h"

#include "ovr/devices/optix7/volume.h"
#include "photonmap.h"

namespace ovr {
namespace cudapm {

using optix7::Array1DFloat4Optix7;
using optix7::Array1DScalarOptix7;
using optix7::Array3DScalarOptix7;
using optix7::ArrayOptix7;

using DeviceVolume = optix7::DeviceStructuredRegularVolume;

struct LaunchParams;

class PhotonMappingRenderer;

struct Ray {
  vec3f org{};
  vec3f dir{};
  float tnear{};
  float tfar{};
};

struct PhotonMappingPayload {
  float alpha = 0.f;
  vec3f color = 0.f;
  void* rng = nullptr;
};

struct LaunchParams { // shared global data
  enum {
    KNN,
    BeamVK
  } estimator_type;

  struct DeviceFrameBuffer {
    vec4f* rgba;
    vec2i size;
  } frame;
  int32_t frame_index{ 0 };

  struct DeviceCamera {
    vec3f position;
    vec3f direction;
    vec3f horizontal;
    vec3f vertical;
  } camera;

  affine3f transform;
};

struct PhotonPointInterface
{
  typedef Photon point_t;
  inline static __device__
  float get(const Photon& p, int dim) { 
    return p.position[dim];
  }
  inline static __device__
  float3 get(const Photon& p) {
    return {p.position.x, p.position.y, p.position.z};
  } 
};

// ------------------------------------------------------------------
// device function declarations
// ------------------------------------------------------------------
void 
do_build_photonmap(cudaStream_t stream, const DevicePhotonMap& photonmap);
void
do_photonmapping(cudaStream_t stream, void* launch_params_ptr, void* volume_ptr, void* photonmap_ptr, int2 fbsize);


// ------------------------------------------------------------------
// renderer
// ------------------------------------------------------------------
class PhotonMappingRenderer {
public:
  void commit(cudaStream_t stream, const DevicePhotonMap& photonmap);
  void render(cudaStream_t stream, LaunchParams& params, void* volume, void* photonmap, bool reset_accumulation);

private:
  CUDABuffer params_buffer;
};

inline void
PhotonMappingRenderer::commit(cudaStream_t stream, const DevicePhotonMap& photonmap)
{
  do_build_photonmap(stream, photonmap);
}

inline void
PhotonMappingRenderer::render(cudaStream_t stream, LaunchParams& params, void* volume, void* photonmap, bool reset_accumulation)
{
  params_buffer.resize(sizeof(params));
  params_buffer.upload_async(&params, 1, stream);
  
  do_photonmapping(stream, (void*)params_buffer.d_pointer(), volume, photonmap, (const int2&)params.frame.size);
}

} // namespace cudapm
} // namespace ovr
