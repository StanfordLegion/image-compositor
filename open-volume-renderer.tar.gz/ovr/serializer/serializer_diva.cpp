#include "serializer.h"

namespace ovr::scene {

Scene
create_json_scene_diva(json root, std::string workdir)
{
  throw std::runtime_error("unimplemented by now");
}

} // namespace ovr::scene
