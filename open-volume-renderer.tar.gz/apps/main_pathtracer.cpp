//. ======================================================================== //
//. Copyright 2019-2020 Qi Wu                                                //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

// clang-format off
#include "glfwapp/GLFWApp.h"
#include <glad/glad.h>
#ifdef __APPLE__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif
// clang-format on

#include "common/cross_device_buffer.h"
#include "common/vidi_async_loop.h"
#include "common/vidi_fps_counter.h"
#include "common/vidi_transactional_value.h"
#include "renderer.h"

namespace tfn {
typedef ovr::math::vec2f vec2f;
typedef ovr::math::vec2i vec2i;
typedef ovr::math::vec3f vec3f;
typedef ovr::math::vec3i vec3i;
typedef ovr::math::vec4f vec4f;
typedef ovr::math::vec4i vec4i;
} // namespace tfn
#define TFN_MODULE_EXTERNAL_VECTOR_TYPES
#include <tfn/widget.h>
using tfn::TransferFunctionWidget;

#include <atomic>
#include <cassert>
#include <chrono>
#include <condition_variable>
#include <fstream>
#include <functional>
#include <future>
#include <iomanip>
#include <mutex>
#include <thread>

using namespace ovr::math;
using ovr::Camera;
using ovr::MainRenderer;
using ovr::Scene;

using ovr::CrossDeviceBuffer;

using vidi::AsyncLoop;
using vidi::FPSCounter;
using vidi::TransactionalValue;

struct MainWindow : public glfwapp::GLFCameraWindow {
public:
  enum FrameLayers {
    FRAME_LAYER_RGBA_CUDA_PATH_TRACING,
    FRAME_LAYER_RGBA_OPTIX7_RAY_MARCHING,
    FRAME_LAYER_RGBA_OPTIX7_PATH_TRACING,
  };

  const char* frame_layers = "RGBA CUDA   (Path Tracing)\0"
                             "RGBA OptiX7 (Ray Marching)\0"
                             "RGBA OptiX7 (Path Tracing)\0";

  struct FrameOutputs {
    vec2i size{ 0 };
    vec4f* rgba{ nullptr };
    vec3f* grad{ nullptr };
    vec3f* network{ nullptr };
  };
  TransactionalValue<FrameOutputs> frame_outputs; /* wrote by BG, consumed by GUI */
  TransactionalValue<FrameOutputs> frame_ref_outputs; /* wrote by BG, consumed by GUI */

  std::atomic<int> frame_layer_index{ 0 };          /* not critical */
  GLuint frame_texture{ 0 };                        /* local to GUI thread */
  GLuint frame_ref_texture{ 0 };
  vec2i frame_size_local{ 0 };                      /* local to GUI thread */
  TransactionalValue<vec2i> frame_size_shared{ 0 }; /* wrote by GUI, consumed by BG */

  /* local to GUI thread */
  struct {
    vec2f focus{ 0.5f, 0.5f };
    float focus_scale{ 0.05f };
    float base_noise{ 0.1f };
    bool sparse_sampling{ false };
    bool path_tracing{ false };
    bool frame_accumulation{ true };
    int spp{ 1 };
  } config;

  Scene scene;

  std::shared_ptr<MainRenderer> renderer;
  MainRenderer::FrameBufferData renderer_output;
  std::string renderer_name = "cudapt";

  std::shared_ptr<MainRenderer> renderer_ref;
  MainRenderer::FrameBufferData renderer_ref_output;
  std::string renderer_ref_name = "ospray";

  std::atomic<float> variance{ 0 }; /* not critical */
  std::atomic<float> variance_ref{ 0 }; /* not critical */

  bool async_enabled{ true }; /* local to GUI thread */
  AsyncLoop async_rendering_loop;

  TransferFunctionWidget widget;
  FPSCounter background_fps, foreground_fps; /* thread safe */

  int m_ac;
  const char** m_av;

public:
  MainWindow(const int ac,
             const char** av,
             const std::string& device,
             const std::string& title,
             const Camera& camera,
             const float worldScale)
    : GLFCameraWindow(title, camera.from, camera.at, camera.up, worldScale, 1600, 800)
    , async_rendering_loop(std::bind(&MainWindow::render_background, this))
    , widget(std::bind(&MainWindow::set_transfer_function,
                       this,
                       std::placeholders::_1,
                       std::placeholders::_2,
                       std::placeholders::_3))
    , m_ac(ac)
    , m_av(av)
  {
    std::string usd_file = std::string(av[1]);
    scene = ovr::scene::create_scene(usd_file);
    cameraFrame.setOrientation( scene.camera.from,
                                scene.camera.at,
                                scene.camera.up );
    renderer = create_renderer(renderer_name);
    renderer->init(ac, av, scene, camera);

    /* over write initial values defined internally by devices */
    renderer->set_focus(config.focus, config.focus_scale, config.base_noise);
    renderer->set_sparse_sampling(config.sparse_sampling);
    renderer->set_frame_accumulation(config.frame_accumulation);
    renderer->set_path_tracing(config.path_tracing);

    //ospray
    renderer_ref = create_renderer(renderer_ref_name);
    renderer_ref->init(ac, av, scene, camera);

    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glGenTextures(1, &frame_texture);
    glGenTextures(1, &frame_ref_texture);

    /* initialize transfer function */
    const auto& tfn = renderer->unsafe_get_tfn();
    if (!tfn.tfn_colors.empty()) {
      std::vector<vec4f> color_controls;
      for (int i = 0; i < tfn.tfn_colors.size() / 3; ++i) {
        color_controls.push_back(vec4f(i / float(tfn.tfn_colors.size() / 3 - 1), /* control point position */
                                       tfn.tfn_colors.at(3 * i),                 //
                                       tfn.tfn_colors.at(3 * i + 1),             //
                                       tfn.tfn_colors.at(3 * i + 2)));           //
      }
      assert(!tfn.tfn_alphas.empty());
      std::vector<vec2f> alpha_controls;
      for (int i = 0; i < tfn.tfn_alphas.size() / 2; ++i) {
        alpha_controls.push_back(vec2f(tfn.tfn_alphas.at(2 * i), tfn.tfn_alphas.at(2 * i + 1)));
      }
      widget.add_tfn(color_controls, alpha_controls, "builtin");
    }
    if (tfn.tfn_value_range.y >= tfn.tfn_value_range.x) {
      widget.set_default_value_range(tfn.tfn_value_range.x, tfn.tfn_value_range.y);
    }

    resize(vec2i(0, 0));

    if (async_enabled) {
      render_background();
      async_rendering_loop.start();
    }
  }

  void render_reset(std::string name)
  {
    if (renderer_name == name)
      return;
    renderer_name = name;

    async_rendering_loop.stop();

    Camera camera = { cameraFrame.get_position(), cameraFrame.get_poi(), cameraFrame.get_accurate_up() };

    renderer = create_renderer(renderer_name);
    renderer->init(m_ac, m_av, scene, camera);
    renderer->set_focus(config.focus, config.focus_scale, config.base_noise);
    renderer->set_fbsize(frame_size_shared.ref());

    const auto& tfn = renderer_ref->unsafe_get_tfn();
    renderer->set_transfer_function(tfn.tfn_colors, tfn.tfn_alphas, tfn.tfn_value_range);

    async_rendering_loop.start();
  }

  /* background thread */
  void render_background()
  {
    int idx = frame_layer_index;

    if (frame_size_shared.update()) {
      frame_outputs.assign([&](FrameOutputs& d) { d.size = vec2i(0, 0); });
      frame_ref_outputs.assign([&](FrameOutputs& d) { d.size = vec2i(0, 0); });
      renderer->set_fbsize(frame_size_shared.ref());
      renderer_ref->set_fbsize(frame_size_shared.ref());
    }

    if (frame_size_shared.ref().long_product() == 0)
      return;

    renderer->commit();
    renderer_ref->commit();
    
    renderer->mapframe(&renderer_output);
    renderer_ref->mapframe(&renderer_ref_output);

    FrameOutputs output;
    {
      output.rgba = (vec4f*)renderer_output.rgba->to_cpu()->data();
      output.size = frame_size_shared.get();
    }
    frame_outputs = output;

    FrameOutputs output_ref;
    {
      output_ref.rgba = (vec4f*)renderer_ref_output.rgba->to_cpu()->data();
      output_ref.size = frame_size_shared.get();
    }
    frame_ref_outputs = output_ref;

    renderer->swap();
    variance = renderer->unsafe_get_variance();
    renderer->render();

    if (scene.parallel_view) {
      renderer_ref->swap();
      variance_ref = renderer_ref->unsafe_get_variance();
      renderer_ref->render();
    }

    background_fps.count();
  }

  /* GUI thread */
  void render() override
  {
    if (cameraFrame.modified) {
      renderer->set_camera(cameraFrame.get_position(), cameraFrame.get_poi(), cameraFrame.get_accurate_up());
      renderer_ref->set_camera(cameraFrame.get_position(), cameraFrame.get_poi(), cameraFrame.get_accurate_up());
      cameraFrame.modified = false;
    }

    if (!async_enabled) {
      render_background();
    }
  }

  /* GUI thread */
  void set_transfer_function(const std::vector<vec3f>& c, const std::vector<vec2f>& o, const vec2f& r)
  {
    std::vector<float> cc(c.size() * 3);
    for (int i = 0; i < c.size(); ++i) {
      cc[3 * i + 0] = c[i].x;
      cc[3 * i + 1] = c[i].y;
      cc[3 * i + 2] = c[i].z;
    }
    std::vector<float> oo(o.size() * 2);
    for (int i = 0; i < o.size(); ++i) {
      oo[2 * i + 0] = o[i].x;
      oo[2 * i + 1] = o[i].y;
    }
    renderer->set_transfer_function(cc, oo, r);
    renderer_ref->set_transfer_function(cc, oo, r);
  }

  // void collect_data(vec4f* &plot) override
  // {
  //   plot = (vec4f*)renderer_output.rgba->to_cpu()->data();
  // }

  // void collect_two_data(vec4f* &plot_a, vec4f* &plot_b) override
  // {
  //   plot_a = (vec4f*)renderer_output.rgba->to_cpu()->data();
  //   plot_b = (vec4f*)renderer_ref_output.rgba->to_cpu()->data();
  // }

  static void view_draw(vec2i size, GLuint& texture)
  {
    glBindTexture(GL_TEXTURE_2D, texture);

    glColor3f(1, 1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.f, (float)size.x, 0.f, (float)size.y, -1.f, 1.f);
    glBegin(GL_QUADS);
    {
      glTexCoord2f(0.f, 0.f);
      glVertex3f(0.f, 0.f, 0.f);
      glTexCoord2f(0.f, 1.f);
      glVertex3f(0.f, (float)size.y, 0.f);
      glTexCoord2f(1.f, 1.f);
      glVertex3f((float)size.x, (float)size.y, 0.f);
      glTexCoord2f(1.f, 0.f);
      glVertex3f((float)size.x, 0.f, 0.f);
    }
    glEnd();
  }

  static void view_update(const FrameOutputs& out, GLuint& texture)
  {
    glBindTexture(GL_TEXTURE_2D, texture);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, out.size.x, out.size.y, 0, GL_RGBA, GL_FLOAT, out.rgba);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  }

  /* GUI thread */
  void draw() override
  {
    const auto& size = frame_size_local;
    
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_TEXTURE_2D);
    glDisable(GL_DEPTH_TEST);
    
    glViewport(0, 0, size.x, size.y);
    frame_outputs.update([&](const FrameOutputs& out) { view_update(out, frame_texture); });
    view_draw(size, frame_texture);

    glViewport(size.x, 0, size.x, size.y);
    frame_ref_outputs.update([&](const FrameOutputs& out) { view_update(out, frame_ref_texture); });
    view_draw(size, frame_ref_texture);

    ImGui::SetNextWindowSizeConstraints(ImVec2(600, 300), ImVec2(FLT_MAX, FLT_MAX));
    if (ImGui::Begin("Control Panel", NULL)) {

      static int index = frame_layer_index;
      if (ImGui::Combo(" Output Framebuffer", &index, frame_layers, IM_ARRAYSIZE(frame_layers))) {
        frame_layer_index = index;

        switch (index) {
        case (FRAME_LAYER_RGBA_OPTIX7_RAY_MARCHING):
          render_reset("optix7");
          renderer->set_path_tracing(false);
          break;
        case (FRAME_LAYER_RGBA_OPTIX7_PATH_TRACING):
          render_reset("optix7");
          renderer->set_path_tracing(true);
          break;
        case (FRAME_LAYER_RGBA_CUDA_PATH_TRACING):
          render_reset("cudapt");
          renderer->set_path_tracing(false);
          break;
        default: break;
        }
      }

      static int spp = config.spp;
      if (ImGui::SliderInt(" Sample Per Pixel", &spp, 1, 32)) {
        config.spp = spp;
        renderer->set_sample_per_pixel(config.spp);
        renderer_ref->set_sample_per_pixel(config.spp);
      }

      widget.build_gui();
    }
    ImGui::End();
    widget.render();

    if (foreground_fps.count()) {
      std::stringstream title;
      title << std::fixed << std::setprecision(3) << " fg = " << foreground_fps.fps << " fps,";
      title << std::fixed << std::setprecision(3) << " bg = " << background_fps.fps << " fps,";
      title << std::fixed << std::setprecision(3) << " var = " << variance << ".";
      title << std::fixed << std::setprecision(3) << " ref_var = " << variance_ref << ".";
      glfwSetWindowTitle(handle, title.str().c_str());
    }
  }

  /* GUI thread */
  void resize(const vec2i& size) override
  {
    frame_size_local.x = size.x / 2;
    frame_size_local.y = size.y;
    frame_size_shared = frame_size_local;
  }

  /* GUI thread */
  void close() override
  {
    if (async_enabled)
      async_rendering_loop.stop();

    glDeleteTextures(1, &frame_texture);
    glDeleteTextures(1, &frame_ref_texture);
  }
};

/*! main entry point to this example - initially optix, print hello world, then exit */
extern "C" int
main(int ac, const char** av)
{
  // -------------------------------------------------------
  // initialize camera
  // -------------------------------------------------------
  Camera camera = { /*from*/ vec3f(0.f, 0.f, -1200.f),
                    /* at */ vec3f(0.f, 0.f, 0.f),
                    /* up */ vec3f(0.f, 1.f, 0.f) };
  // Camera camera = { /*from*/ vec3f(-4.50488, 1.47628, -4.94709),
  //                   /* at */ vec3f(0.f, 0.f, 0.f),
  //                   /* up */ vec3f(0.f, 1.f, 0.f) };
  // (C)urrent camera:
  // - from :(0.190742,0.182741,0.964468)
  // - poi  :(0,0,0)
  // - upVec:(0,1,0)
  // - frame:{
  //     vx = (0.980999,0,-0.194012),
  //     vy = (-0.0354544,0.983161,-0.179271),
  //     vz = (0.190742,0.182741,0.964468)
  //   }
  // something approximating the scale of the world, so the
  // camera knows how much to move for any given user interaction:
  const float worldScale = 100.f;

  // -------------------------------------------------------
  // initialize opengl window
  // -------------------------------------------------------
  MainWindow* window;
  if (ac < 2)
    window = new MainWindow(ac, av, "optix7", "Optix7 Renderer", camera, worldScale);
  else
    window = new MainWindow(ac, av, av[1], "OSPRay Renderer", camera, worldScale);

  // window = new MainWindow(ac, av, "CUDA", "CUDA Renderer", camera, worldScale);

  window->run();
  window->close();

  return 0;
}
