//. ======================================================================== //
//. Copyright 2021-2022 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#pragma once
#ifndef OVR_COMMON_EYEMOVEMENT_H
#define OVR_COMMON_EYEMOVEMENT_H

#include <fstream>
#include <string>
#include <vector>
#include <chrono>

#include "common/math.h"
#include "common/vidi_fps_counter.h"

using namespace ovr::math;

namespace vidi {

struct EyeMovement {   
    public:
        EyeMovement(int update_every = 120, float padding = 0.15) : update_every(update_every), padding(padding) {
            
            target_index = 0;
            targets = {
                {0.2,0.3},
                {0.8,0.8},
                {0.75,0.2},
                {0.4,0.5}
            };
        }

        void
        update(HistoryFPSCounter& fps_counter, vec2f& focus) {
            int index = fps_counter.frame % update_every;
            if (index == 0)
                update_target(focus);

            float t = (float)index/(update_every-1);
            focus.x = ease(origin.x, target.x, t);
            focus.y = ease(origin.y, target.y, t);
        }

    private:
        int update_every;
        float padding;
        vec2f target, origin;

        int target_index;
        std::vector<vec2f> targets;

        void update_target(vec2f current) {
            origin = current;
            //target = vec2f((float)rand() / RAND_MAX, (float)rand() / RAND_MAX);
            //target.x = padding + (1.0f-2*padding) * target.x;
            //target.y = padding + (1.0f-2*padding) * target.y;

            target = targets[target_index];
            target_index = (++target_index) % targets.size();

            std::cout << "gaze target = " << target << std::endl;
        }

        float ease(float a, float b, float t) {
            t = bezier(t);
            return (1.0f - t) * a + t * b;
        }

        float bezier(float t) {
            return t * t * (3.0f - 2.0f * t);
        }
};

}

#endif