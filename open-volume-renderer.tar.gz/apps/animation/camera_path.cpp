//. ======================================================================== //
//. Copyright 2021-2022 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "camera_path.h"
#include "common/math.h"

using namespace ovr::math;

namespace ovr
{

void
AutomatedCameraPath::step()
{
    step_count = (step_count + 1) % cycle_length;
    float zoom = step_count > (cycle_length/2) ? (1.0f + (0.001f * speed)) : (1.0f - (0.001f * speed));

    const vec3f poi = camera_frame.get_poi();
    
    vec2f curr = {0.005f * speed, 0};//0.01f * speed};
    vec2f prev = {0.0f, 0.0f};

    camera_frame.rotate_frame(curr, prev, 1.0f);
    camera_frame.set_focal_length(camera_frame.get_focal_length() * zoom);
    camera_frame.set_position(poi + camera_frame.get_focal_length() * camera_frame.get_frame_z());
    camera_frame.modified = true;
}

} // namespace ovr
