#pragma once

#include "glfwapp/camera_frame.h"


namespace ovr {

struct CameraPath {

    glfwapp::CameraFrame& camera_frame;
    float speed;

    CameraPath(glfwapp::CameraFrame& camera_frame, float speed = 1.0f) : camera_frame(camera_frame), speed(speed) {};
    virtual void step() = 0;

    void set_speed(const float speed) {
        this->speed = speed;
    }
};

struct AutomatedCameraPath : public CameraPath {

    int step_count;
    int cycle_length;

    AutomatedCameraPath(glfwapp::CameraFrame& camera_frame, int cycle_length, float speed = 1.0f) : CameraPath(camera_frame, speed),cycle_length(cycle_length), step_count(0) {};

    virtual void step() override;
};

struct KeyframeCameraPath : public CameraPath {
    // TODO: Implement
};

}