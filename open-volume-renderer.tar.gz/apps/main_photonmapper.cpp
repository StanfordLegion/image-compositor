//. ======================================================================== //
//. Copyright 2019-2020 David Bauer                                          //
//.                                                                          //
//. Licensed under the Apache License, Version 2.0 (the "License");          //
//. you may not use this file except in compliance with the License.         //
//. You may obtain a copy of the License at                                  //
//.                                                                          //
//.     http://www.apache.org/licenses/LICENSE-2.0                           //
//.                                                                          //
//. Unless required by applicable law or agreed to in writing, software      //
//. distributed under the License is distributed on an "AS IS" BASIS,        //
//. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. //
//. See the License for the specific language governing permissions and      //
//. limitations under the License.                                           //
//. ======================================================================== //

#include "common/imageio.h"
#include "common/vidi_fps_counter.h"
#include "renderer.h"

#include <3rdparty/json.hpp>
#include <glfwapp/camera_frame.h>

#include <colormap.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <fstream>
#include <iostream>
#include <random>
#include <string>

using namespace ovr::math;
using ovr::Camera;
using ovr::MainRenderer;

using vidi::FPSCounter;

ovr::Scene
create_vorts_scene()
{
    std::cout << "[pm] Loading default scene vorts1" << std::endl;
    using namespace ovr;

    static std::random_device rng_device;  // Will be used to obtain a seed for the random number engine
    static std::mt19937 rng(rng_device()); // Standard mersenne_twister_engine seeded with rng()
    static std::uniform_int_distribution<> index(0, colormap::name.size() - 1ULL);

    scene::TransferFunction tfn;

    /* 0.0070086f, 12.1394f */
    scene::Volume volume;
    volume.type = scene::Volume::STRUCTURED_REGULAR_VOLUME;
    volume.structured_regular.data = CreateArray3DScalarFromFile(
        std::string("../../data/data/vorts1.data"), vec3i(128, 128, 128), VALUE_TYPE_FLOAT, 0, false);
    volume.structured_regular.grid_origin = -vec3f(64.f,64.f,64.f); //-vec3i(128, 128, 128) * 2.f;
    volume.structured_regular.grid_spacing = 1.f;
    tfn.value_range = vec2f(0.0, 12.0);
    tfn.color = CreateColorMap("diverging/seismic");
    tfn.opacity = CreateArray1DScalar(std::vector<float>{0.01f, 0.0f, 0.01f, 0.05f, 0.01f, 0.2f, 0.f});

    scene::Model model;
    model.type = scene::Model::VOLUMETRIC_MODEL;
    model.volume_model.volume = volume;
    model.volume_model.transfer_function = tfn;

    scene::Instance instance;
    instance.models.push_back(model);
    instance.transform = affine3f::translate(vec3f(0));

    Camera camera = {/*from*/ vec3f(0.f, 0.f, 180.f),
                    /* at */ vec3f(0.f, 0.f, 0.f),
                    /* up */ vec3f(0.f, 1.f, 0.f)};

    scene::Scene scene;
    scene.instances.push_back(instance);
    scene.camera = camera;

    return scene;
}

void render_a_frame(std::shared_ptr<MainRenderer> ren_openvkl,
                    vec2i frame_size,
                    int frame_index,
                    int max_spp)
{
    MainRenderer::FrameBufferData pixels;
    float variance;

    ren_openvkl->commit();
    ren_openvkl->render();
    ren_openvkl->mapframe(&pixels);

    std::cout << "[pm] Saving rendered output" << std::endl;
    ovr::save_image("output" + std::to_string(frame_index) + ".png",
                    (vec4f *)pixels.rgba->to_cpu()->data(), frame_size.x, frame_size.y);
}

/*! main entry point to this example - initially optix, print hello world, then exit */
int
main(int ac, const char **av)
{
    std::cout << "[pm] Started app" << std::endl;
    int max_num_frames = 1;
    int max_spp = 1;

    std::string scene_name;
    std::string device;

    ovr::Scene scene;
    bool scene_created = false;

    int ai = 1;
    while (ai < ac)
    {
        std::string arg(av[ai++]);

        if (arg == "--device")
        {
            if (ac < ai + 1)
            {
                throw std::runtime_error("improper --device arguments");
            }
            device = std::string(av[ai++]);
        }

        if (arg == "--max-num-frames")
        {
            if (ac < ai + 1)
            {
                throw std::runtime_error("improper --max-num-frames arguments");
            }
            max_num_frames = std::stoi(av[ai++]);
        }

        else if (arg == "--max-spp")
        {
            if (ac < ai + 1)
            {
                throw std::runtime_error("improper --max-spp arguments");
            }
            max_spp = std::stoi(av[ai++]);
        }

        else if (arg == "--scene-vorts")
        {
            scene = create_vorts_scene();
            scene_created = true;
        }

        else if (arg == "--scene-vidi3d")
        {
            if (ac < ai + 1)
            {
                throw std::runtime_error("improper --scene-vidi3d arguments");
            }
            scene = ovr::scene::create_json_scene(std::string(av[ai++]));
            scene_created = true;
        }
    }

    Camera camera = {/*from*/ vec3f(0.f, 0.f, -800.f),
                     /* at */ vec3f(0.f, 0.f, 0.f),
                     /* up */ vec3f(0.f, 1.f, 0.f)};

    if (!scene_created)
    {
        scene = create_example_scene();
    }
    else
    {
        camera = scene.camera;
    }

    vec2i fbsize(1280, 720);

    auto camera_frame = glfwapp::CameraFrame(100.f);
    camera_frame.setOrientation(camera.from, camera.at, camera.up);

    std::cout << "[pm] Creating renderer" << std::endl;
    auto ren = create_renderer(device);
    ren->set_photonmapping(true);
    ren->set_fbsize(fbsize);
    ren->set_frame_accumulation(false);
    ren->set_path_tracing(false);
    ren->init(ac, av, scene, camera);
    ren->commit();


    float dist = length(camera.from - camera.at);
    for (int i = 0; i < max_num_frames; i++) {

        std::cout << "[pm] Rendering a frame" << std::endl;
        render_a_frame(ren, fbsize, i, max_spp);

        ren->current_scene.camera.from.x = camera.at.x + sin(i*6.f * M_PI / 180.0f) * dist;
        ren->current_scene.camera.from.z = camera.at.z + cos(i*6.f * M_PI / 180.0f) * dist;
        ren->set_camera(ren->current_scene.camera);
    }


    return 0;
}
